-- CareLink schema
-- Run in the Supabase SQL editor (or `supabase db push`). Safe to run once on a fresh project.

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------
do $$ begin
  create type user_role as enum ('admin', 'support_manager', 'support_agent');
exception when duplicate_object then null; end $$;

do $$ begin
  create type channel_type as enum ('web_chat', 'email', 'whatsapp', 'instagram', 'messenger');
exception when duplicate_object then null; end $$;

do $$ begin
  create type conversation_status as enum ('open', 'pending', 'resolved', 'escalated');
exception when duplicate_object then null; end $$;

do $$ begin
  create type priority_level as enum ('low', 'medium', 'high', 'urgent');
exception when duplicate_object then null; end $$;

do $$ begin
  create type ticket_status as enum ('open', 'in_progress', 'pending', 'resolved', 'escalated');
exception when duplicate_object then null; end $$;

do $$ begin
  create type sender_type as enum ('customer', 'ai', 'human', 'system');
exception when duplicate_object then null; end $$;

-- ---------------------------------------------------------------
-- Organizations (tenant boundary for every other table)
-- ---------------------------------------------------------------
create table if not exists organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  settings jsonb not null default jsonb_build_object(
    'confidence_threshold', 0.6,
    'tone', 'friendly and professional',
    'auto_escalate_negative', true,
    'company_description', ''
  ),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- 1. profiles
-- ---------------------------------------------------------------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  organization_id uuid not null references organizations(id) on delete cascade,
  full_name text not null default '',
  email text not null,
  role user_role not null default 'support_agent',
  avatar_url text,
  notification_prefs jsonb not null default jsonb_build_object(
    'email_escalations', true, 'new_tickets', true, 'daily_digest', false
  ),
  theme text not null default 'dark',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists profiles_org_idx on profiles(organization_id);

-- ---------------------------------------------------------------
-- 9. team_members (human support staff + pending invites)
-- ---------------------------------------------------------------
create table if not exists team_members (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  profile_id uuid references profiles(id) on delete set null,
  name text not null,
  email text not null,
  role user_role not null default 'support_agent',
  availability text not null default 'available' check (availability in ('available', 'busy', 'away', 'offline')),
  invite_status text not null default 'active' check (invite_status in ('invited', 'active')),
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, email)
);
create index if not exists team_members_org_idx on team_members(organization_id);
create index if not exists team_members_email_idx on team_members(lower(email));

-- ---------------------------------------------------------------
-- 2. customers
-- ---------------------------------------------------------------
create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  name text not null,
  email text,
  phone text,
  primary_channel channel_type not null default 'web_chat',
  sentiment text not null default 'neutral',
  notes text,
  is_demo boolean not null default false,
  last_interaction_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists customers_org_idx on customers(organization_id);
create unique index if not exists customers_org_email_idx on customers(organization_id, lower(email)) where email is not null;

-- ---------------------------------------------------------------
-- 3. conversations
-- ---------------------------------------------------------------
create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  customer_id uuid not null references customers(id) on delete cascade,
  channel channel_type not null default 'web_chat',
  subject text,
  status conversation_status not null default 'open',
  priority priority_level not null default 'medium',
  sentiment text,
  intent text,
  category text,
  current_agent text,
  assigned_to uuid references team_members(id) on delete set null,
  ai_resolved boolean not null default false,
  escalated boolean not null default false,
  handoff_summary text,
  csat smallint check (csat between 1 and 5),
  public_token uuid not null default gen_random_uuid(),
  first_response_at timestamptz,
  resolved_at timestamptz,
  last_message_at timestamptz not null default now(),
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists conversations_org_idx on conversations(organization_id, last_message_at desc);
create index if not exists conversations_customer_idx on conversations(customer_id);
create index if not exists conversations_status_idx on conversations(organization_id, status);

-- ---------------------------------------------------------------
-- 4. messages
-- ---------------------------------------------------------------
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  conversation_id uuid not null references conversations(id) on delete cascade,
  sender sender_type not null,
  agent_key text,
  author_name text,
  content text not null,
  metadata jsonb not null default '{}'::jsonb,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists messages_conversation_idx on messages(conversation_id, created_at);
create index if not exists messages_org_idx on messages(organization_id, created_at desc);

-- ---------------------------------------------------------------
-- 5. tickets
-- ---------------------------------------------------------------
create sequence if not exists ticket_number_seq start 1001;

create table if not exists tickets (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  ticket_number text not null default ('CL-' || nextval('ticket_number_seq')::text),
  customer_id uuid references customers(id) on delete set null,
  conversation_id uuid references conversations(id) on delete set null,
  title text not null,
  description text not null default '',
  category text not null default 'general',
  priority priority_level not null default 'medium',
  status ticket_status not null default 'open',
  assigned_to uuid references team_members(id) on delete set null,
  created_by uuid references profiles(id) on delete set null,
  is_demo boolean not null default false,
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists tickets_number_idx on tickets(ticket_number);
create index if not exists tickets_org_idx on tickets(organization_id, created_at desc);
create index if not exists tickets_status_idx on tickets(organization_id, status);

-- ---------------------------------------------------------------
-- 6. ai_agents (per-organization agent configuration)
-- ---------------------------------------------------------------
create table if not exists ai_agents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  key text not null check (key in ('understanding', 'routing', 'support', 'technical', 'billing', 'sentiment', 'handoff')),
  name text not null,
  description text not null,
  enabled boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, key)
);

-- ---------------------------------------------------------------
-- 7. agent_logs (one row per agent execution)
-- ---------------------------------------------------------------
create table if not exists agent_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  conversation_id uuid references conversations(id) on delete cascade,
  message_id uuid references messages(id) on delete set null,
  run_id uuid not null,
  agent_key text not null,
  step smallint not null,
  status text not null check (status in ('success', 'error', 'skipped')),
  input jsonb not null default '{}'::jsonb,
  output jsonb not null default '{}'::jsonb,
  confidence numeric(4, 3),
  latency_ms integer,
  model text,
  error text,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists agent_logs_org_idx on agent_logs(organization_id, created_at desc);
create index if not exists agent_logs_agent_idx on agent_logs(organization_id, agent_key);
create index if not exists agent_logs_run_idx on agent_logs(run_id);

-- ---------------------------------------------------------------
-- 8. knowledge_articles
-- ---------------------------------------------------------------
create table if not exists knowledge_articles (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  title text not null,
  content text not null default '',
  category text not null default 'general',
  type text not null default 'faq' check (type in ('faq', 'document')),
  tags text[] not null default '{}',
  file_path text,
  file_name text,
  file_size integer,
  created_by uuid references profiles(id) on delete set null,
  is_demo boolean not null default false,
  search tsvector generated always as (
    setweight(to_tsvector('english', coalesce(title, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(category, '')), 'B') ||
    setweight(to_tsvector('english', coalesce(content, '')), 'C')
  ) stored,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists knowledge_org_idx on knowledge_articles(organization_id);
create index if not exists knowledge_search_idx on knowledge_articles using gin(search);

-- ---------------------------------------------------------------
-- 10. channel_integrations
-- ---------------------------------------------------------------
create table if not exists channel_integrations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete cascade,
  channel channel_type not null,
  status text not null default 'not_configured' check (status in ('not_configured', 'pending_verification', 'connected', 'error')),
  enabled boolean not null default false,
  -- Non-secret settings only (e.g. phone number id, page id). Secrets belong in server env vars.
  config jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique (organization_id, channel)
);

-- ---------------------------------------------------------------
-- updated_at trigger
-- ---------------------------------------------------------------
create or replace function set_updated_at() returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

do $$
declare t text;
begin
  foreach t in array array['organizations','profiles','team_members','customers','conversations','tickets','ai_agents','knowledge_articles','channel_integrations']
  loop
    execute format('drop trigger if exists %I_updated_at on %I', t, t);
    execute format('create trigger %I_updated_at before update on %I for each row execute function set_updated_at()', t, t);
  end loop;
end $$;

-- ---------------------------------------------------------------
-- Helper functions used by RLS
-- ---------------------------------------------------------------
create or replace function current_org_id() returns uuid
language sql stable security definer set search_path = public as $$
  select organization_id from profiles where id = auth.uid()
$$;

create or replace function current_user_role() returns user_role
language sql stable security definer set search_path = public as $$
  select role from profiles where id = auth.uid()
$$;

-- ---------------------------------------------------------------
-- Seed per-organization defaults (agents + channels)
-- ---------------------------------------------------------------
create or replace function seed_org_defaults(org uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  insert into ai_agents (organization_id, key, name, description) values
    (org, 'understanding', 'Query Understanding Agent', 'Reads each customer message, identifies intent and category, extracts key details and detects urgency.'),
    (org, 'sentiment', 'Sentiment Analysis Agent', 'Measures customer emotion and frustration, assigns priority and recommends escalation.'),
    (org, 'routing', 'Routing Agent', 'Chooses the specialist agent for each query and flags high-risk cases for escalation.'),
    (org, 'support', 'Customer Support Agent', 'Answers general questions and FAQs using the knowledge base.'),
    (org, 'technical', 'Technical Support Agent', 'Diagnoses technical, login and account problems with step-by-step troubleshooting.'),
    (org, 'billing', 'Billing Agent', 'Explains payments, invoices and refund policy. Never processes payments or refunds itself.'),
    (org, 'handoff', 'Human Handoff Agent', 'Summarises conversations the AI cannot resolve and hands them to an available human.')
  on conflict (organization_id, key) do nothing;

  insert into channel_integrations (organization_id, channel, status, enabled) values
    (org, 'web_chat', 'connected', true),
    (org, 'email', 'not_configured', false),
    (org, 'whatsapp', 'not_configured', false),
    (org, 'instagram', 'not_configured', false),
    (org, 'messenger', 'not_configured', false)
  on conflict (organization_id, channel) do nothing;
end $$;

-- ---------------------------------------------------------------
-- New user signup: join an org they were invited to, or create a new org (as admin)
-- ---------------------------------------------------------------
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  invite team_members%rowtype;
  org_id uuid;
  org_name text;
  base_slug text;
  full_name text;
begin
  full_name := coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1));

  select * into invite from team_members
   where lower(email) = lower(new.email) and invite_status = 'invited'
   order by created_at limit 1;

  if found then
    insert into profiles (id, organization_id, full_name, email, role)
    values (new.id, invite.organization_id, full_name, new.email, invite.role);
    update team_members set profile_id = new.id, invite_status = 'active', name = full_name
     where id = invite.id;
  else
    org_name := coalesce(nullif(new.raw_user_meta_data->>'organization_name', ''), full_name || '''s Workspace');
    base_slug := regexp_replace(lower(org_name), '[^a-z0-9]+', '-', 'g');
    base_slug := trim(both '-' from base_slug);
    if base_slug = '' then base_slug := 'org'; end if;

    insert into organizations (name, slug)
    values (org_name, base_slug || '-' || substr(replace(gen_random_uuid()::text, '-', ''), 1, 6))
    returning id into org_id;

    insert into profiles (id, organization_id, full_name, email, role)
    values (new.id, org_id, full_name, new.email, 'admin');

    insert into team_members (organization_id, profile_id, name, email, role, invite_status)
    values (org_id, new.id, full_name, new.email, 'admin', 'active');

    perform seed_org_defaults(org_id);
  end if;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function handle_new_user();

-- ---------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------
alter table organizations enable row level security;
alter table profiles enable row level security;
alter table team_members enable row level security;
alter table customers enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table tickets enable row level security;
alter table ai_agents enable row level security;
alter table agent_logs enable row level security;
alter table knowledge_articles enable row level security;
alter table channel_integrations enable row level security;

-- organizations
drop policy if exists org_select on organizations;
create policy org_select on organizations for select using (id = current_org_id());
drop policy if exists org_update on organizations;
create policy org_update on organizations for update using (id = current_org_id() and current_user_role() = 'admin');

-- profiles: see colleagues, edit self; admins can change roles in their org
drop policy if exists profiles_select on profiles;
create policy profiles_select on profiles for select using (organization_id = current_org_id());
drop policy if exists profiles_update_self on profiles;
create policy profiles_update_self on profiles for update using (id = auth.uid())
  with check (id = auth.uid() and organization_id = current_org_id() and role = current_user_role());
drop policy if exists profiles_update_admin on profiles;
create policy profiles_update_admin on profiles for update using (organization_id = current_org_id() and current_user_role() = 'admin');

-- Generic org-scoped tables: every member can read and write
do $$
declare t text;
begin
  foreach t in array array['customers','conversations','messages','tickets','agent_logs']
  loop
    execute format('drop policy if exists %I_select on %I', t, t);
    execute format('create policy %I_select on %I for select using (organization_id = current_org_id())', t, t);
    execute format('drop policy if exists %I_insert on %I', t, t);
    execute format('create policy %I_insert on %I for insert with check (organization_id = current_org_id())', t, t);
    execute format('drop policy if exists %I_update on %I', t, t);
    execute format('create policy %I_update on %I for update using (organization_id = current_org_id()) with check (organization_id = current_org_id())', t, t);
  end loop;
end $$;

-- Deletes limited to admins and managers
drop policy if exists tickets_delete on tickets;
create policy tickets_delete on tickets for delete using (organization_id = current_org_id() and current_user_role() in ('admin', 'support_manager'));
drop policy if exists customers_delete on customers;
create policy customers_delete on customers for delete using (organization_id = current_org_id() and current_user_role() in ('admin', 'support_manager'));
drop policy if exists conversations_delete on conversations;
create policy conversations_delete on conversations for delete using (organization_id = current_org_id() and current_user_role() in ('admin', 'support_manager'));

-- team_members: read for all, manage for admins
drop policy if exists team_select on team_members;
create policy team_select on team_members for select using (organization_id = current_org_id());
drop policy if exists team_write on team_members;
create policy team_write on team_members for all using (organization_id = current_org_id() and current_user_role() = 'admin')
  with check (organization_id = current_org_id() and current_user_role() = 'admin');
drop policy if exists team_self_availability on team_members;
create policy team_self_availability on team_members for update using (organization_id = current_org_id() and profile_id = auth.uid())
  with check (organization_id = current_org_id() and profile_id = auth.uid());

-- ai_agents: read for all, toggle for admins
drop policy if exists agents_select on ai_agents;
create policy agents_select on ai_agents for select using (organization_id = current_org_id());
drop policy if exists agents_update on ai_agents;
create policy agents_update on ai_agents for update using (organization_id = current_org_id() and current_user_role() = 'admin');

-- knowledge base: read for all, write for admins and managers
drop policy if exists kb_select on knowledge_articles;
create policy kb_select on knowledge_articles for select using (organization_id = current_org_id());
drop policy if exists kb_write on knowledge_articles;
create policy kb_write on knowledge_articles for all using (organization_id = current_org_id() and current_user_role() in ('admin', 'support_manager'))
  with check (organization_id = current_org_id() and current_user_role() in ('admin', 'support_manager'));

-- channel integrations: read for all, manage for admins
drop policy if exists channels_select on channel_integrations;
create policy channels_select on channel_integrations for select using (organization_id = current_org_id());
drop policy if exists channels_write on channel_integrations;
create policy channels_write on channel_integrations for update using (organization_id = current_org_id() and current_user_role() = 'admin');

-- ---------------------------------------------------------------
-- Knowledge base search (used by the retrieval layer)
-- ---------------------------------------------------------------
create or replace function search_knowledge(org uuid, query text, match_count int default 4)
returns table (id uuid, title text, category text, content text, type text, rank real)
language sql stable set search_path = public as $$
  select k.id, k.title, k.category, k.content, k.type,
         ts_rank(k.search, websearch_to_tsquery('english', query)) as rank
    from knowledge_articles k
   where k.organization_id = org
     and k.search @@ websearch_to_tsquery('english', query)
   order by rank desc
   limit match_count
$$;

-- OR-based variant: matches any keyword, used when the strict query finds nothing
create or replace function search_knowledge_any(org uuid, words text[], match_count int default 4)
returns table (id uuid, title text, category text, content text, type text, rank real)
language sql stable set search_path = public as $$
  select k.id, k.title, k.category, k.content, k.type,
         ts_rank(k.search, to_tsquery('english', array_to_string(words, ' | '))) as rank
    from knowledge_articles k
   where k.organization_id = org
     and cardinality(words) > 0
     and k.search @@ to_tsquery('english', array_to_string(words, ' | '))
   order by rank desc
   limit match_count
$$;

-- ---------------------------------------------------------------
-- Storage bucket for knowledge-base uploads (private)
-- Files are stored under <organization_id>/<filename>
-- ---------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('knowledge-base', 'knowledge-base', false)
on conflict (id) do nothing;

drop policy if exists kb_files_read on storage.objects;
create policy kb_files_read on storage.objects for select
  using (bucket_id = 'knowledge-base' and (storage.foldername(name))[1] = current_org_id()::text);
drop policy if exists kb_files_write on storage.objects;
create policy kb_files_write on storage.objects for insert
  with check (bucket_id = 'knowledge-base' and (storage.foldername(name))[1] = current_org_id()::text
              and current_user_role() in ('admin', 'support_manager'));
drop policy if exists kb_files_delete on storage.objects;
create policy kb_files_delete on storage.objects for delete
  using (bucket_id = 'knowledge-base' and (storage.foldername(name))[1] = current_org_id()::text
         and current_user_role() in ('admin', 'support_manager'));

-- ---------------------------------------------------------------
-- Realtime: dashboard and inbox refresh live on these tables
-- ---------------------------------------------------------------
do $$ begin
  alter publication supabase_realtime add table messages;
exception when others then null; end $$;
do $$ begin
  alter publication supabase_realtime add table conversations;
exception when others then null; end $$;
do $$ begin
  alter publication supabase_realtime add table tickets;
exception when others then null; end $$;
