# CareLink

**One Platform. Every Conversation. Intelligent Support.**

CareLink is an omnichannel customer support platform where seven Claude-powered agents work together on each customer message. One agent works out what the customer wants, one reads their mood, one routes the message, three specialists (support, technical, billing) write the answer from your knowledge base, and one hands the conversation to a human when the AI shouldn't handle it alone.

Built with Next.js 15 (App Router), TypeScript, Tailwind, Supabase (Postgres, Auth, Storage, Realtime) and the Anthropic API.

---

## Contents

1. [What's included](#whats-included)
2. [Setup (about 15 minutes)](#setup)
3. [Demo walkthrough for evaluators](#demo-walkthrough-for-evaluators)
4. [How the agents work](#how-the-agents-work)
5. [Project structure](#project-structure)
6. [Security](#security)
7. [Connecting email, WhatsApp, Instagram and Messenger](#connecting-external-channels)
8. [Testing](#testing)
9. [Deploying](#deploying-to-vercel)
10. [Known limitations](#known-limitations)

---

## What's included

| Area | What works |
|---|---|
| Auth | Register, log in, log out, protected routes, profile editing, three roles (Admin, Support Manager, Support Agent) |
| Overview | Live stats from the database, activity chart, ticket status donut, AI agent performance, recent conversations and tickets, team availability. Refreshes in real time through Supabase Realtime |
| Agent Workflow | Live AI chat. Every message runs through the agents, and a 10-step visual shows the active agent, status, JSON output, confidence and escalation for each step |
| Omnichannel Inbox | Unified conversation list with search and filters (status, priority, channel), chat history, customer panel, AI analysis, assign, resolve, escalate, human replies, create ticket |
| Website chat | A public chat widget at `/widget/<your-slug>` that you can embed on any site. Visitors' messages go through the same agents and land in the inbox |
| Tickets | Create, edit, assign, change priority and status inline, delete with confirmation, search and filter. Escalated conversations create tickets automatically |
| Customers | Directory with conversation count, open tickets, sentiment, last interaction, and a detail page with full interaction history |
| Knowledge Base | FAQ create/edit/delete, PDF/TXT/MD/CSV upload to Supabase Storage with text extraction, categories, search (the same search the agents use) |
| Analytics | Date-range filter, conversations, AI-resolved vs escalated, first response time, resolution time, CSAT, top issues, channels, daily and weekly trends, per-agent and per-human performance |
| AI Agents | All seven agents with status, tasks handled, success rate, average processing time, last activity. Admins can enable or disable each one. Execution logs with filters |
| Team | Add members by email with a role, change roles, set availability, remove members |
| Settings | Profile, team, AI configuration (tone, confidence threshold, auto-escalation, company description), API configuration and widget embed code, notification preferences, channel integrations, theme, demo mode |
| Demo mode | One click loads sample customers, conversations, tickets, team members, KB articles and agent logs. Every sample record is tagged **Demo** and can be removed in one click |

---

## Setup

You need: **Node.js 20+**, a free **Supabase** account, and an **Anthropic API key** (console.anthropic.com).

### 1. Install

```bash
cd carelink
npm install
```

### 2. Create the Supabase project

1. Go to [supabase.com](https://supabase.com), create a new project and wait for it to finish provisioning.
2. Open **SQL Editor → New query**, paste the whole of `supabase/migrations/0001_schema.sql`, and click **Run**. This creates all tables, Row Level Security policies, the signup trigger, the search functions, the `knowledge-base` storage bucket and the realtime publication. Running it twice is safe.
3. For a quick demo, turn off email confirmation: in **Authentication**, open the **Email** provider settings and switch off **Confirm email** (Supabase moves this menu around occasionally). (If you leave it on, new users must click the link in their email before they can log in. In that case also add `http://localhost:3000/auth/callback` under **Authentication → URL Configuration → Redirect URLs**.)

### 3. Environment variables

```bash
cp .env.example .env.local
```

Fill in `.env.local`:

| Variable | Where to find it |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Project Settings → API → Project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Same page, `anon` `public` key |
| `SUPABASE_SERVICE_ROLE_KEY` | Same page, `service_role` key. **Server only.** Used by the public chat widget and channel webhooks |
| `ANTHROPIC_API_KEY` | console.anthropic.com → API Keys |
| `ANTHROPIC_MODEL` | Optional. Default `claude-sonnet-5-5` (writes replies) |
| `ANTHROPIC_FAST_MODEL` | Optional. Default `claude-haiku-5-5` (classification agents) |
| `NEXT_PUBLIC_APP_URL` | `http://localhost:3000` locally, your real URL in production |

The channel variables at the bottom of `.env.example` are optional. Leave them empty for now.

### 4. Run

```bash
npm run dev
```

Open http://localhost:3000. If anything required is missing you'll land on `/setup`, which shows which variables are set.

### 5. First login

1. Click **Create a workspace**, enter your name, an organization name, email and password. The first account in a workspace becomes **Admin**.
2. On the Overview page click **Load demo data** to fill the app with sample records, or skip it and start chatting.

---

## Demo walkthrough for evaluators

This covers every step in the project brief, in about five minutes.

1. **Log in** at `/login`.
2. **Dashboard**: the Overview page. If it's empty, click **Load demo data** (Admin only).
3. **Send a customer message**: open **Agent Workflow** and click one of the sample messages, e.g. *"My payment was deducted but my order failed."*
4. **Watch the workflow**: the right panel lights up step by step: Understanding → Sentiment → Routing → Knowledge retrieval → Billing Agent → Confidence check → Save → Response. Click any step to see the agent's raw JSON.
5. **AI answer**: the reply appears in the chat, labelled with the agent name, confidence and knowledge-base sources.
6. **View the conversation**: click **Inbox** in the chat header. The conversation is there with the AI's intent, sentiment and priority.
7. **Create and manage a ticket**: click **Create ticket**, then open **Tickets** and change its status, priority or assignee inline. Delete asks for confirmation.
8. **Analytics**: open **Analytics** and switch the date range.
9. **Escalate**: back in the chat, click **Request human**, or send *"I have been waiting for a response for two days."* The Handoff Agent writes a summary, assigns the least-busy available team member and opens an escalated ticket. Reply as that human from the inbox.

Try the other sample messages too: *"I cannot log into my account"* goes to the Technical agent, *"How can I change my password?"* usually gets resolved straight away, and *"I want to request a refund"* goes to Billing, which explains the policy but never claims to have issued a refund.

To see the public channel, go to **Settings → API configuration → Open widget**, which opens the customer-facing chat in a new tab. Messages you send there appear in the inbox.

---

## How the agents work

All agent logic lives in `src/lib/agents/`:

- `prompts.ts`: the system prompt and output schema (zod) for each agent.
- `claude.ts`: the Anthropic client. Calls Claude, extracts the JSON, validates it, and retries once with the validation error if the reply is malformed.
- `orchestrator.ts`: the shared orchestration service that runs the workflow below, writes every step to `agent_logs`, and streams progress events to the UI.

```
 1  Customer message saved
 2  Query Understanding Agent  → intent, category, sentiment, priority, confidence, summary, entities
 3  Sentiment Analysis Agent   → emotion, frustration score, priority, escalation recommendation
 4  Routing Agent              → billing | technical | support | handoff
 5  Knowledge retrieval        → Postgres full-text search over FAQs and documents
 6  Specialist agent           → reply, confidence, resolved?, needs human?, sources used
 7  Escalation check           → low confidence, needs_human, routing flag, angry customer, explicit request
 8  Human Handoff Agent        → summary for the rep, message to the customer, ticket title; assigns the least-busy available human
 9  Save                       → messages, agent_logs, conversation status, customer sentiment, escalation ticket
10  Response delivered
```

The classification agents (2, 3, 4) use the faster model. The writing agents (6, 8) use the main model.

What happens when something goes wrong:

- **An agent is disabled** by an admin: it's skipped and logged as `skipped`. If Routing is off, simple rules route by intent. If a specialist is off, Support takes over.
- **An agent call fails**: the error is logged and the workflow continues. If the specialist fails, the conversation goes to a human.
- **No API key**: no AI reply is invented. The customer gets an honest "a team member will reply" message and the conversation is escalated.
- **A human has taken over** (status escalated): new customer messages are stored but the AI stays quiet until someone clicks **Back to AI**.

The retrieval layer (`src/lib/kb/retriever.ts`) sits behind a `KnowledgeRetriever` interface. To add embeddings later, write a pgvector implementation of the same interface and return it from `getRetriever()`. Nothing else needs to change.

---

## Project structure

```
supabase/migrations/0001_schema.sql   Tables, RLS, triggers, search functions, storage bucket
src/
  middleware.ts                       Session refresh and route protection
  app/
    (auth)/login, register            Auth pages
    (dashboard)/                      Protected app: overview, inbox, agents, workflow, tickets,
                                      customers, knowledge, analytics, team, settings, search
    widget/[slug]/                    Public website chat
    api/
      chat/                           Dashboard live chat (streams workflow events as NDJSON)
      widget/{start,message,messages} Public chat endpoints (token-protected, rate-limited)
      conversations/[id]/...          Update, human reply, manual handoff
      tickets/, customers/, knowledge/, agents/, team/, settings/, demo/
      webhooks/[channel]/             Inbound email, WhatsApp, Instagram, Messenger
  lib/
    agents/                           Prompts, Claude client, orchestrator
    kb/retriever.ts                   Knowledge retrieval
    channels/                         Channel requirements and API adapters
    supabase/                         Browser, server, admin and middleware clients
    metrics.ts                        Dashboard and analytics calculations
    demo.ts                           Demo data seeding and removal
    validation.ts                     zod schemas for every API input
    rate-limit.ts                     Request rate limiting
  components/                         UI, layout, chat, inbox, tickets, knowledge, settings...
tests/orchestrator.test.ts            Agent workflow tests (mock Claude server, no API cost)
```

### Database tables

`organizations`, `profiles`, `team_members`, `customers`, `conversations`, `messages`, `tickets`, `ai_agents`, `agent_logs`, `knowledge_articles`, `channel_integrations`.

All use UUID primary keys, timestamps, foreign keys and indexes. Every table carries an `organization_id`, and RLS policies make sure users only read and write their own organization's rows. Demo rows have `is_demo = true`.

### Roles

| | Admin | Support Manager | Support Agent |
|---|:-:|:-:|:-:|
| Conversations, replies, tickets | ✓ | ✓ | ✓ |
| Delete tickets and customers | ✓ | ✓ | |
| Edit knowledge base | ✓ | ✓ | |
| Team, roles, AI agents, AI settings, channels, demo data | ✓ | | |

These rules are enforced in Postgres (RLS) and again in the API routes.

---

## Security

- **API keys stay on the server.** Only `NEXT_PUBLIC_*` values reach the browser, and those are safe to expose because RLS protects the data.
- **Row Level Security** on every table, scoped by organization and role.
- **Input validation** with zod on every API route. Control characters are stripped from text.
- **Rate limiting** on chat, the widget, uploads, handoffs, webhooks and demo seeding.
- **Prompt injection:** customer messages, history and KB content are wrapped in tags. Agents are told to treat them as data, and customers can't close those tags to escape.
- **No unauthorized actions.** The Billing agent is instructed never to claim a refund was issued. No agent can change accounts or move money; they can only explain and escalate.
- **Webhooks** verify Meta's `X-Hub-Signature-256` HMAC, or a shared secret for email.
- **Widget conversations** can only be read with their random per-conversation token.
- The knowledge-base storage bucket is private. Downloads use 60-second signed URLs.

---

## Connecting external channels

Website chat works out of the box. The other channels have real adapters (`src/lib/channels/adapters.ts`) and a webhook endpoint, but CareLink never shows them as connected until their credentials exist. **Settings → Channel integrations** shows exactly which variables are missing and gives you the webhook URL.

| Channel | You need | Webhook URL |
|---|---|---|
| WhatsApp | Meta developer app with WhatsApp Cloud API; `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_VERIFY_TOKEN`, `META_APP_SECRET`; the phone number ID in Settings | `/api/webhooks/whatsapp` |
| Messenger | Facebook Page + Meta app; `META_PAGE_ACCESS_TOKEN`, `META_VERIFY_TOKEN`, `META_APP_SECRET`; Page ID in Settings | `/api/webhooks/messenger` |
| Instagram | Instagram professional account linked to a Page, Instagram Messaging permission (needs Meta app review); same Meta variables; account ID in Settings | `/api/webhooks/instagram` |
| Email | An inbound-parse provider that POSTs JSON `{to, from, subject, text}` with header `x-carelink-secret`; `EMAIL_INBOUND_SECRET`, `RESEND_API_KEY`, `EMAIL_FROM`; support address in Settings | `/api/webhooks/email` |

Webhooks need a public HTTPS URL, so deploy first or use a tunnel such as `ngrok http 3000` while testing.

---

## Testing

```bash
npm run typecheck     # TypeScript
npm run lint          # ESLint
npm run test:agents   # Orchestrator tests against a mock Claude server (no API key or cost)
npm run build         # Production build
```

`test:agents` covers ten scenarios: billing and technical routing, KB use, escalation of frustrated customers, low-confidence escalation, retrying invalid JSON, disabled agents, API failures, manual handoff, prompt-injection tags, and running with no API key.

Before handing this over, the full app was also run end to end in a browser against a local Postgres with this migration applied: register, load demo data, live chat, workflow view, request human, create/update/delete tickets, inbox reply, KB FAQ and file upload, agent toggles, analytics filters, public widget, mobile layout and logout. Everything completed with no console errors and no failed API calls. RLS was checked separately, including cross-organization access and role restrictions.

---

## Deploying to Vercel

1. Push the project to GitHub and import it in Vercel.
2. Add the same environment variables in **Project → Settings → Environment Variables**. Set `NEXT_PUBLIC_APP_URL` to your Vercel URL.
3. In Supabase → Authentication → URL Configuration, set the Site URL to your Vercel URL and add `https://<your-app>.vercel.app/auth/callback` to Redirect URLs.
4. Deploy. The AI routes allow up to 60 seconds per request. A normal run makes four Claude calls one after another, which fits comfortably inside that.

---

## Known limitations

- The rate limiter keeps counts in memory, which is fine for one server. With several serverless instances, switch it to Redis (e.g. Upstash); the interface in `src/lib/rate-limit.ts` stays the same.
- Scanned PDFs (images with no text layer) need OCR before upload.
- Knowledge search is keyword-based Postgres full-text search, not semantic search. See "How the agents work" for adding embeddings.
- Inviting a team member doesn't send an email. Share the `/register` link with them and they join your workspace when they sign up with that email.
- The external channel adapters follow the official Meta and Resend API formats but have not been tested against live accounts, since that needs real business credentials.
- Live updates depend on Supabase Realtime. The migration adds the tables to the realtime publication; if your project has Realtime turned off, pages still work but you'll need to refresh to see new data.
