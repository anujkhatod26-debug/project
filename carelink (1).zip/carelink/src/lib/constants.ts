import type { AgentKey, Channel, Priority, TicketStatus, ConversationStatus, UserRole } from "@/types";

export const APP_NAME = "CareLink";
export const TAGLINE = "One Platform. Every Conversation. Intelligent Support.";

export const AGENT_META: Record<AgentKey, { name: string; short: string; color: string; step: number }> = {
  understanding: { name: "Query Understanding Agent", short: "Understanding", color: "#60a5fa", step: 2 },
  sentiment: { name: "Sentiment Analysis Agent", short: "Sentiment", color: "#f472b6", step: 3 },
  routing: { name: "Routing Agent", short: "Routing", color: "#a78bfa", step: 4 },
  support: { name: "Customer Support Agent", short: "Support", color: "#34d399", step: 6 },
  technical: { name: "Technical Support Agent", short: "Technical", color: "#22d3ee", step: 6 },
  billing: { name: "Billing Agent", short: "Billing", color: "#fbbf24", step: 6 },
  handoff: { name: "Human Handoff Agent", short: "Handoff", color: "#fb7185", step: 8 },
};

export const AGENT_ORDER: AgentKey[] = [
  "understanding",
  "sentiment",
  "routing",
  "support",
  "technical",
  "billing",
  "handoff",
];

export const CHANNEL_META: Record<Channel, { label: string; color: string }> = {
  web_chat: { label: "Website Chat", color: "#3b82f6" },
  email: { label: "Email", color: "#94a3b8" },
  whatsapp: { label: "WhatsApp", color: "#22c55e" },
  instagram: { label: "Instagram", color: "#ec4899" },
  messenger: { label: "Messenger", color: "#8b5cf6" },
};

export const PRIORITIES: Priority[] = ["low", "medium", "high", "urgent"];
export const TICKET_STATUSES: TicketStatus[] = ["open", "in_progress", "pending", "resolved", "escalated"];
export const CONVERSATION_STATUSES: ConversationStatus[] = ["open", "pending", "resolved", "escalated"];
export const ROLES: UserRole[] = ["admin", "support_manager", "support_agent"];

export const ROLE_LABEL: Record<UserRole, string> = {
  admin: "Admin",
  support_manager: "Support Manager",
  support_agent: "Support Agent",
};

export const SAMPLE_MESSAGES = [
  "My payment was deducted but my order failed.",
  "I cannot log into my account.",
  "I want to request a refund.",
  "How can I change my password?",
  "I have been waiting for a response for two days.",
];
