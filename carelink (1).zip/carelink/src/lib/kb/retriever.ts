import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";

export interface KnowledgeHit {
  id: string;
  title: string;
  category: string;
  type: string;
  excerpt: string;
  score: number;
}

/**
 * Retrieval interface. The default implementation uses Postgres full-text search.
 * To add embeddings later, implement this interface with pgvector (e.g. a
 * `match_knowledge_embeddings` RPC) and swap it in `getRetriever()`.
 */
export interface KnowledgeRetriever {
  search(orgId: string, query: string, limit?: number): Promise<KnowledgeHit[]>;
}

const STOPWORDS = new Set(
  "a an and are as at be but by can could did do does for from had has have how i if in into is it its me my no not of on or our so than that the their them then there these they this to too us was we were what when where which who why will with would you your am been being been just about after again any all also more most some such only own same very hello hi please thanks thank want need".split(
    " "
  )
);

export function keywords(text: string, max = 12) {
  const words = text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length >= 3 && !STOPWORDS.has(w));
  return Array.from(new Set(words)).slice(0, max);
}

/** Split long documents into paragraphs and keep the chunks that share the most keywords with the query. */
export function bestExcerpt(content: string, words: string[], maxChars = 1800) {
  if (content.length <= maxChars) return content;
  const chunks: string[] = [];
  let buf = "";
  for (const para of content.split(/\n{2,}/)) {
    if ((buf + "\n\n" + para).length > 900 && buf) {
      chunks.push(buf);
      buf = para;
    } else {
      buf = buf ? `${buf}\n\n${para}` : para;
    }
  }
  if (buf) chunks.push(buf);

  const scored = chunks
    .map((c, i) => {
      const lc = c.toLowerCase();
      const score = words.reduce((s, w) => s + (lc.includes(w) ? 1 : 0), 0);
      return { c, i, score };
    })
    .sort((a, b) => b.score - a.score || a.i - b.i);

  const picked: typeof scored = [];
  let total = 0;
  for (const s of scored) {
    if (total + s.c.length > maxChars) continue;
    picked.push(s);
    total += s.c.length;
  }
  return picked
    .sort((a, b) => a.i - b.i)
    .map((p) => p.c)
    .join("\n...\n")
    .slice(0, maxChars);
}

type Row = { id: string; title: string; category: string; content: string; type: string; rank: number };

export class FullTextRetriever implements KnowledgeRetriever {
  constructor(private db: SupabaseClient) {}

  async search(orgId: string, query: string, limit = 4): Promise<KnowledgeHit[]> {
    const words = keywords(query);
    if (words.length === 0) return [];

    // 1. Strict: every keyword should match (websearch syntax)
    let rows: Row[] = [];
    const strict = await this.db.rpc("search_knowledge", {
      org: orgId,
      query: words.join(" "),
      match_count: limit,
    });
    if (!strict.error && strict.data) rows = strict.data as Row[];

    // 2. Loose: any keyword matches
    if (rows.length < limit) {
      const loose = await this.db.rpc("search_knowledge_any", {
        org: orgId,
        words,
        match_count: limit,
      });
      if (!loose.error && loose.data) {
        const seen = new Set(rows.map((r) => r.id));
        for (const r of loose.data as Row[]) if (!seen.has(r.id)) rows.push(r);
      }
    }

    // 3. Last resort: simple title match (helps with very short articles)
    if (rows.length === 0) {
      const { data } = await this.db
        .from("knowledge_articles")
        .select("id,title,category,content,type")
        .eq("organization_id", orgId)
        .or(words.slice(0, 5).map((w) => `title.ilike.%${w}%`).join(","))
        .limit(limit);
      rows = ((data ?? []) as Omit<Row, "rank">[]).map((r) => ({ ...r, rank: 0.01 }));
    }

    return rows.slice(0, limit).map((r) => ({
      id: r.id,
      title: r.title,
      category: r.category,
      type: r.type,
      excerpt: bestExcerpt(r.content, words),
      score: Number(r.rank) || 0,
    }));
  }
}

export function getRetriever(db: SupabaseClient): KnowledgeRetriever {
  return new FullTextRetriever(db);
}
