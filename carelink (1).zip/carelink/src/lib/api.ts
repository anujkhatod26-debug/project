import "server-only";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { HttpError } from "@/lib/auth";
import { RateLimitError } from "@/lib/rate-limit";

export function ok<T>(data: T, status = 200) {
  return NextResponse.json(data, { status });
}

export function handleError(err: unknown) {
  if (err instanceof HttpError) {
    return NextResponse.json({ error: err.message }, { status: err.status });
  }
  if (err instanceof RateLimitError) {
    return NextResponse.json(
      { error: "Too many requests. Please wait a moment and try again." },
      { status: 429, headers: { "Retry-After": String(err.retryAfter) } }
    );
  }
  if (err instanceof ZodError) {
    return NextResponse.json(
      { error: "Invalid input", details: err.issues.map((i) => `${i.path.join(".")}: ${i.message}`) },
      { status: 400 }
    );
  }
  console.error("[api]", err);
  const message = err instanceof Error ? err.message : "Unexpected server error";
  return NextResponse.json({ error: message }, { status: 500 });
}

/** Supabase returns { error } instead of throwing; this turns it into an exception. */
/* eslint-disable @typescript-eslint/no-explicit-any */
export function must(res: { data: any; error: { message: string } | null }, what = "Database error"): any {
  if (res.error) throw new HttpError(400, `${what}: ${res.error.message}`);
  if (res.data == null) throw new HttpError(404, `${what}: not found`);
  return res.data;
}
/* eslint-enable @typescript-eslint/no-explicit-any */

/** For writes where no row is returned (delete). */
export function check(res: { error: { message: string } | null }, what = "Database error") {
  if (res.error) throw new HttpError(400, `${what}: ${res.error.message}`);
}
