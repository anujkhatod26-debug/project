import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Channel } from "@/types";

/** Finds a customer by email (or creates one) for an organization. */
export async function findOrCreateCustomer(
  db: SupabaseClient,
  orgId: string,
  c: { name: string; email?: string | null; channel?: Channel }
) {
  if (c.email) {
    const { data: existing } = await db
      .from("customers")
      .select("id, name")
      .eq("organization_id", orgId)
      .ilike("email", c.email)
      .maybeSingle();
    if (existing) return existing as { id: string; name: string };
  }
  const { data, error } = await db
    .from("customers")
    .insert({
      organization_id: orgId,
      name: c.name,
      email: c.email ?? null,
      primary_channel: c.channel ?? "web_chat",
      last_interaction_at: new Date().toISOString(),
    })
    .select("id, name")
    .single();
  if (error) throw new Error(`Could not create customer: ${error.message}`);
  return data as { id: string; name: string };
}

export async function createConversation(
  db: SupabaseClient,
  orgId: string,
  customerId: string,
  channel: Channel = "web_chat"
) {
  const { data, error } = await db
    .from("conversations")
    .insert({ organization_id: orgId, customer_id: customerId, channel, status: "open" })
    .select("id, public_token")
    .single();
  if (error) throw new Error(`Could not create conversation: ${error.message}`);
  return data as { id: string; public_token: string };
}

export async function addCustomerMessage(db: SupabaseClient, orgId: string, conversationId: string, content: string, authorName: string) {
  const now = new Date().toISOString();
  const { data, error } = await db
    .from("messages")
    .insert({
      organization_id: orgId,
      conversation_id: conversationId,
      sender: "customer",
      author_name: authorName,
      content,
    })
    .select("id, created_at")
    .single();
  if (error) throw new Error(`Could not save message: ${error.message}`);
  await db.from("conversations").update({ last_message_at: now }).eq("id", conversationId);
  return data as { id: string; created_at: string };
}

/** NDJSON streaming helper for workflow events. */
export function ndjsonStream(run: (send: (obj: unknown) => void) => Promise<void>) {
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) => controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
      try {
        await run(send);
      } catch (err) {
        send({ type: "error", message: err instanceof Error ? err.message : "Workflow failed" });
      } finally {
        controller.close();
      }
    },
  });
  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
