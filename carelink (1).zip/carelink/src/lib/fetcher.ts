"use client";

/** Small JSON helper for calling our API routes from client components. */
export async function api<T = unknown>(url: string, init?: RequestInit & { json?: unknown }): Promise<T> {
  const { json, ...rest } = init ?? {};
  const res = await fetch(url, {
    ...rest,
    headers: json !== undefined ? { "Content-Type": "application/json", ...(rest.headers ?? {}) } : rest.headers,
    body: json !== undefined ? JSON.stringify(json) : rest.body,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = (data as { error?: string; details?: string[] }).error ?? `Request failed (${res.status})`;
    const details = (data as { details?: string[] }).details;
    throw new Error(details?.length ? `${msg}: ${details.join(", ")}` : msg);
  }
  return data as T;
}
