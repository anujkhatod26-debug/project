import "server-only";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Organization, Profile, UserRole } from "@/types";

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

/** For server components: returns the signed-in user's profile and org or redirects to /login. */
export async function getSession() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single<Profile>();
  if (!profile) redirect("/login?error=no_profile");

  const { data: org } = await supabase
    .from("organizations")
    .select("*")
    .eq("id", profile.organization_id)
    .single<Organization>();

  return { supabase, user, profile, org: org! };
}

/** For API routes: returns the session or throws an HttpError (401 / 403). */
export async function requireApiUser(roles?: UserRole[]) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new HttpError(401, "Not signed in");

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single<Profile>();
  if (!profile) throw new HttpError(403, "No profile found for this user");
  if (roles && !roles.includes(profile.role)) {
    throw new HttpError(403, "Your role does not allow this action");
  }
  return { supabase, user, profile };
}

export function canManage(role: UserRole) {
  return role === "admin" || role === "support_manager";
}
