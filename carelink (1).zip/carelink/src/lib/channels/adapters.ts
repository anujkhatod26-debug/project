import "server-only";
import { createHmac, timingSafeEqual } from "crypto";
import type { Channel } from "@/types";
import { missingEnv } from "./requirements";

export interface InboundMessage {
  accountId: string; // which business account / page / inbox received it
  externalUserId: string; // sender id (phone number, PSID, IGSID, email)
  name: string;
  text: string;
  email?: string;
  phone?: string;
}

const GRAPH = "https://graph.facebook.com/v21.0";

export function verifyMetaSignature(raw: string, header: string | null) {
  const secret = process.env.META_APP_SECRET;
  if (!secret || !header?.startsWith("sha256=")) return false;
  const expected = createHmac("sha256", secret).update(raw).digest("hex");
  const got = header.slice(7);
  return expected.length === got.length && timingSafeEqual(Buffer.from(expected), Buffer.from(got));
}

export function verifyEmailSecret(header: string | null) {
  const secret = process.env.EMAIL_INBOUND_SECRET;
  if (!secret || !header) return false;
  return secret.length === header.length && timingSafeEqual(Buffer.from(secret), Buffer.from(header));
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export function parseInbound(channel: Channel, body: any): InboundMessage[] {
  const out: InboundMessage[] = [];
  if (channel === "whatsapp") {
    for (const entry of body?.entry ?? []) {
      for (const change of entry?.changes ?? []) {
        const v = change?.value;
        const contacts = v?.contacts ?? [];
        for (const m of v?.messages ?? []) {
          if (m?.type !== "text") continue;
          const contact = contacts.find((c: any) => c?.wa_id === m.from);
          out.push({
            accountId: String(v?.metadata?.phone_number_id ?? ""),
            externalUserId: String(m.from),
            phone: String(m.from),
            name: contact?.profile?.name ?? `+${m.from}`,
            text: String(m.text?.body ?? ""),
          });
        }
      }
    }
  } else if (channel === "messenger" || channel === "instagram") {
    for (const entry of body?.entry ?? []) {
      for (const ev of entry?.messaging ?? []) {
        if (!ev?.message?.text || ev?.message?.is_echo) continue;
        out.push({
          accountId: String(entry?.id ?? ""),
          externalUserId: String(ev.sender?.id ?? ""),
          name: channel === "instagram" ? "Instagram user" : "Messenger user",
          text: String(ev.message.text),
        });
      }
    }
  } else if (channel === "email") {
    // Generic inbound-parse shape: { to, from, from_name?, subject, text }
    const from = String(body?.from ?? "");
    const email = from.match(/<([^>]+)>/)?.[1] ?? from;
    if (email && body?.text) {
      out.push({
        accountId: String(body?.to ?? ""),
        externalUserId: email.toLowerCase(),
        email: email.toLowerCase(),
        name: body?.from_name ?? from.replace(/<[^>]+>/, "").trim() ?? email,
        text: `${body?.subject ? `Subject: ${body.subject}\n\n` : ""}${String(body.text).slice(0, 4000)}`,
      });
    }
  }
  return out.filter((m) => m.text.trim() && m.externalUserId);
}

/** Sends a reply through the channel's real API. Throws if credentials are missing. */
export async function sendOutbound(
  channel: Channel,
  opts: { config: Record<string, string>; to: string; text: string; subject?: string }
) {
  if (channel === "web_chat") return; // widget polls the database
  const missing = missingEnv(channel);
  if (missing.length) throw new Error(`${channel} is not connected (missing ${missing.join(", ")})`);

  let res: Response;
  if (channel === "whatsapp") {
    res = await fetch(`${GRAPH}/${opts.config.phone_number_id}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", to: opts.to, type: "text", text: { body: opts.text.slice(0, 4000) } }),
    });
  } else if (channel === "messenger" || channel === "instagram") {
    res = await fetch(`${GRAPH}/me/messages?access_token=${encodeURIComponent(process.env.META_PAGE_ACCESS_TOKEN!)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ recipient: { id: opts.to }, messaging_type: "RESPONSE", message: { text: opts.text.slice(0, 1900) } }),
    });
  } else {
    res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: process.env.EMAIL_FROM, to: [opts.to], subject: opts.subject ?? "Re: your support request", text: opts.text }),
    });
  }
  if (!res.ok) throw new Error(`${channel} API error ${res.status}: ${(await res.text()).slice(0, 200)}`);
}
/* eslint-enable @typescript-eslint/no-explicit-any */
