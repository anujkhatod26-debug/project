import type { Channel } from "@/types";

/** What each channel needs before it can be switched on. Secrets are env vars; ids are stored per org. */
export const CHANNEL_REQUIREMENTS: Record<
  Channel,
  { env: string[]; fields: { key: string; label: string; placeholder?: string }[]; webhook: boolean; docs: string }
> = {
  web_chat: {
    env: [],
    fields: [],
    webhook: false,
    docs: "Built in and live. Share the widget link from Settings → API configuration, or embed it on your website.",
  },
  email: {
    env: ["EMAIL_INBOUND_SECRET", "RESEND_API_KEY", "EMAIL_FROM"],
    fields: [{ key: "support_address", label: "Support address customers write to", placeholder: "support@yourcompany.com" }],
    webhook: true,
    docs: "Inbound: point your email provider's inbound-parse webhook at the URL below with header x-carelink-secret. Outbound replies are sent through the Resend API.",
  },
  whatsapp: {
    env: ["WHATSAPP_ACCESS_TOKEN", "WHATSAPP_VERIFY_TOKEN", "META_APP_SECRET"],
    fields: [{ key: "phone_number_id", label: "WhatsApp phone number ID", placeholder: "from Meta → WhatsApp → API setup" }],
    webhook: true,
    docs: "Uses the WhatsApp Cloud API. Create a Meta app, add WhatsApp, subscribe the webhook below to 'messages' and use WHATSAPP_VERIFY_TOKEN as the verify token.",
  },
  instagram: {
    env: ["META_PAGE_ACCESS_TOKEN", "META_VERIFY_TOKEN", "META_APP_SECRET"],
    fields: [{ key: "account_id", label: "Instagram business account ID" }],
    webhook: true,
    docs: "Uses the Instagram Messaging API (Meta Graph). Requires an Instagram professional account linked to a Facebook Page and app review for messaging permissions.",
  },
  messenger: {
    env: ["META_PAGE_ACCESS_TOKEN", "META_VERIFY_TOKEN", "META_APP_SECRET"],
    fields: [{ key: "page_id", label: "Facebook Page ID" }],
    webhook: true,
    docs: "Uses the Messenger Platform. Subscribe the Page to the webhook below with the 'messages' field.",
  },
};

export function missingEnv(channel: Channel) {
  return CHANNEL_REQUIREMENTS[channel].env.filter((k) => !process.env[k]);
}
