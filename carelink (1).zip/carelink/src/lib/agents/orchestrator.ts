import "server-only";
import { randomUUID } from "crypto";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { AgentKey, OrgSettings, Priority } from "@/types";
import { AGENT_META } from "@/lib/constants";
import { AIUnavailableError, MODELS, callAgentJSON } from "./claude";
import {
  handoffPrompt,
  handoffSchema,
  routingPrompt,
  routingSchema,
  sentimentPrompt,
  sentimentSchema,
  specialistPrompt,
  specialistSchema,
  understandingPrompt,
  understandingSchema,
  type HandoffOutput,
  type Routing,
  type Sentiment,
  type SpecialistOutput,
  type Understanding,
} from "./prompts";
import { getRetriever, type KnowledgeHit } from "@/lib/kb/retriever";

// ------------------------------------------------------------------ Types

export type StepKey = AgentKey | "receive" | "knowledge" | "check" | "save" | "respond";

export interface WorkflowEvent {
  type: "run_started" | "step" | "final" | "error";
  runId: string;
  step?: number;
  key?: StepKey;
  title?: string;
  status?: "running" | "success" | "error" | "skipped";
  detail?: string;
  output?: unknown;
  confidence?: number | null;
  latencyMs?: number;
  final?: FinalResult;
  message?: string;
}

export interface FinalResult {
  conversationId: string;
  messageId: string | null;
  reply: string;
  agent: AgentKey | "system";
  agentName: string;
  confidence: number | null;
  escalated: boolean;
  escalationReasons: string[];
  assignedTo: { id: string; name: string } | null;
  ticketId: string | null;
  intent: string | null;
  priority: Priority;
  sentiment: string | null;
}

interface RunInput {
  db: SupabaseClient;
  orgId: string;
  conversationId: string;
  customerMessageId: string;
  customerName: string;
  onEvent?: (e: WorkflowEvent) => void;
}

type Specialist = "support" | "technical" | "billing";

const PRIORITY_RANK: Record<Priority, number> = { low: 0, medium: 1, high: 2, urgent: 3 };
const maxPriority = (...ps: Priority[]) =>
  ps.reduce((a, b) => (PRIORITY_RANK[b] > PRIORITY_RANK[a] ? b : a), "low" as Priority);

const DEFAULT_SETTINGS: OrgSettings = {
  confidence_threshold: 0.6,
  tone: "friendly and professional",
  auto_escalate_negative: true,
  company_description: "",
};

// ------------------------------------------------------------------ Helpers

function escapeTags(s: string) {
  // Prevent customer text from closing our wrapper tags.
  return s.replace(/<\/?(customer_message|history|knowledge|analysis)[^>]*>/gi, "[tag removed]");
}

function formatHistory(rows: { sender: string; content: string; agent_key: string | null }[]) {
  if (rows.length === 0) return "(no earlier messages)";
  return rows
    .map((m) => {
      const who = m.sender === "customer" ? "Customer" : m.sender === "ai" ? `AI (${m.agent_key ?? "agent"})` : m.sender === "human" ? "Human rep" : "System";
      return `${who}: ${escapeTags(m.content).slice(0, 800)}`;
    })
    .join("\n");
}

function formatKnowledge(hits: KnowledgeHit[]) {
  if (hits.length === 0) return "(no matching knowledge-base articles were found)";
  return hits
    .map((h) => `[article id="${h.id}" title="${h.title.replace(/"/g, "'")}" category="${h.category}"]\n${escapeTags(h.excerpt)}\n[/article]`)
    .join("\n\n");
}

function routeFallback(intent: string | undefined, enabled: Set<AgentKey>): Specialist | "handoff" {
  const map: Record<string, Specialist> = {
    billing: "billing",
    refund: "billing",
    technical: "technical",
    account: "technical",
  };
  const want = (intent && map[intent]) || "support";
  if (enabled.has(want)) return want;
  if (enabled.has("support")) return "support";
  return "handoff";
}

// ------------------------------------------------------------------ Orchestrator

export async function runAgentWorkflow(input: RunInput): Promise<FinalResult> {
  const { db, orgId, conversationId, customerMessageId, customerName } = input;
  const runId = randomUUID();
  const emit = (e: Omit<WorkflowEvent, "runId">) => input.onEvent?.({ ...e, runId });
  const isDemo = false;

  // ---------- Load context
  const [{ data: org }, { data: agents }, { data: historyRows }, { data: convo }] = await Promise.all([
    db.from("organizations").select("name, settings").eq("id", orgId).single(),
    db.from("ai_agents").select("key, enabled").eq("organization_id", orgId),
    db
      .from("messages")
      .select("id, sender, content, agent_key, created_at")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: false })
      .limit(13),
    db.from("conversations").select("*").eq("id", conversationId).single(),
  ]);

  const settings: OrgSettings = { ...DEFAULT_SETTINGS, ...((org?.settings as Partial<OrgSettings>) ?? {}) };
  const companyName = (org?.name as string) ?? "our company";
  const enabled = new Set<AgentKey>(
    (agents ?? []).filter((a) => a.enabled).map((a) => a.key as AgentKey)
  );
  if (!agents || agents.length === 0) {
    // Org was created before agents were seeded: treat all as enabled.
    (Object.keys(AGENT_META) as AgentKey[]).forEach((k) => enabled.add(k));
  }

  const ordered = (historyRows ?? []).slice().reverse();
  const current = ordered.find((m) => m.id === customerMessageId);
  const latestText = current?.content ?? ordered.filter((m) => m.sender === "customer").at(-1)?.content ?? "";
  const history = ordered.filter((m) => m.id !== customerMessageId).slice(-12);

  const contextBlock = `Customer name: ${customerName}
Channel: ${convo?.channel ?? "web_chat"}

<history>
${formatHistory(history)}
</history>

<customer_message>
${escapeTags(latestText)}
</customer_message>`;

  emit({ type: "run_started" });

  // ---------- Log helper
  const logs: Record<string, unknown>[] = [];
  const log = (
    agent: AgentKey,
    step: number,
    status: "success" | "error" | "skipped",
    extra: { input?: unknown; output?: unknown; confidence?: number | null; latencyMs?: number; model?: string; error?: string }
  ) => {
    logs.push({
      organization_id: orgId,
      conversation_id: conversationId,
      message_id: customerMessageId,
      run_id: runId,
      agent_key: agent,
      step,
      status,
      input: extra.input ?? {},
      output: extra.output ?? {},
      confidence: extra.confidence ?? null,
      latency_ms: extra.latencyMs ?? null,
      model: extra.model ?? null,
      error: extra.error ?? null,
      is_demo: isDemo,
    });
  };

  let aiAvailable = true;
  const markAIError = (err: unknown) => {
    if (err instanceof AIUnavailableError) aiAvailable = false;
    const msg = err instanceof Error ? err.message : String(err);
    if (/api[_ ]?key|authentication|401|invalid x-api-key/i.test(msg)) aiAvailable = false;
    return msg;
  };

  emit({ type: "step", step: 1, key: "receive", title: "Customer message received", status: "success", detail: latestText.slice(0, 160) });

  // ---------- STEP 2: Query Understanding Agent
  let understanding: Understanding | null = null;
  if (enabled.has("understanding")) {
    emit({ type: "step", step: 2, key: "understanding", title: AGENT_META.understanding.name, status: "running" });
    try {
      const r = await callAgentJSON({
        model: MODELS.fast(),
        system: understandingPrompt(),
        user: contextBlock,
        schema: understandingSchema,
        maxTokens: 600,
      });
      understanding = r.data;
      log("understanding", 2, "success", { input: { message: latestText }, output: r.data, confidence: r.data.confidence, latencyMs: r.latencyMs, model: r.model });
      emit({ type: "step", step: 2, key: "understanding", title: AGENT_META.understanding.name, status: "success", output: r.data, confidence: r.data.confidence, latencyMs: r.latencyMs });
    } catch (err) {
      const msg = markAIError(err);
      log("understanding", 2, "error", { input: { message: latestText }, error: msg });
      emit({ type: "step", step: 2, key: "understanding", title: AGENT_META.understanding.name, status: "error", detail: msg });
    }
  } else {
    log("understanding", 2, "skipped", { output: { reason: "Agent disabled" } });
    emit({ type: "step", step: 2, key: "understanding", title: AGENT_META.understanding.name, status: "skipped", detail: "Disabled by admin" });
  }

  // ---------- STEP 3: Sentiment Analysis Agent
  let sentiment: Sentiment | null = null;
  if (enabled.has("sentiment") && aiAvailable) {
    emit({ type: "step", step: 3, key: "sentiment", title: AGENT_META.sentiment.name, status: "running" });
    try {
      const r = await callAgentJSON({
        model: MODELS.fast(),
        system: sentimentPrompt(),
        user: contextBlock,
        schema: sentimentSchema,
        maxTokens: 400,
      });
      sentiment = r.data;
      log("sentiment", 3, "success", { input: { message: latestText }, output: r.data, confidence: r.data.confidence, latencyMs: r.latencyMs, model: r.model });
      emit({ type: "step", step: 3, key: "sentiment", title: AGENT_META.sentiment.name, status: "success", output: r.data, confidence: r.data.confidence, latencyMs: r.latencyMs });
    } catch (err) {
      const msg = markAIError(err);
      log("sentiment", 3, "error", { error: msg });
      emit({ type: "step", step: 3, key: "sentiment", title: AGENT_META.sentiment.name, status: "error", detail: msg });
    }
  } else {
    log("sentiment", 3, "skipped", { output: { reason: aiAvailable ? "Agent disabled" : "AI unavailable" } });
    emit({ type: "step", step: 3, key: "sentiment", title: AGENT_META.sentiment.name, status: "skipped", detail: aiAvailable ? "Disabled by admin" : "AI unavailable" });
  }

  const priority: Priority = maxPriority(
    understanding?.priority ?? "medium",
    sentiment?.priority ?? "low",
    (convo?.priority as Priority) ?? "low"
  );

  // ---------- STEP 4: Routing Agent
  const specialistsEnabled = (["support", "technical", "billing"] as Specialist[]).filter((k) => enabled.has(k));
  let routing: Routing | null = null;
  let target: Specialist | "handoff";

  if (enabled.has("routing") && aiAvailable) {
    emit({ type: "step", step: 4, key: "routing", title: AGENT_META.routing.name, status: "running" });
    try {
      const r = await callAgentJSON({
        model: MODELS.fast(),
        system: routingPrompt(specialistsEnabled),
        user: `<analysis>
Understanding: ${JSON.stringify(understanding ?? { note: "unavailable" })}
Sentiment: ${JSON.stringify(sentiment ?? { note: "unavailable" })}
</analysis>

<customer_message>
${escapeTags(latestText)}
</customer_message>`,
        schema: routingSchema,
        maxTokens: 300,
      });
      routing = r.data;
      log("routing", 4, "success", { input: { understanding, sentiment }, output: r.data, confidence: r.data.confidence, latencyMs: r.latencyMs, model: r.model });
      emit({ type: "step", step: 4, key: "routing", title: AGENT_META.routing.name, status: "success", output: r.data, confidence: r.data.confidence, latencyMs: r.latencyMs });
    } catch (err) {
      const msg = markAIError(err);
      log("routing", 4, "error", { error: msg });
      emit({ type: "step", step: 4, key: "routing", title: AGENT_META.routing.name, status: "error", detail: `${msg}. Falling back to rule-based routing.` });
    }
  } else {
    log("routing", 4, "skipped", { output: { reason: aiAvailable ? "Agent disabled; rule-based routing used" : "AI unavailable" } });
    emit({ type: "step", step: 4, key: "routing", title: AGENT_META.routing.name, status: "skipped", detail: aiAvailable ? "Disabled: using rule-based routing" : "AI unavailable" });
  }

  if (routing) {
    target = routing.target === "handoff" || enabled.has(routing.target) ? routing.target : routeFallback(understanding?.intent, enabled);
  } else {
    target = routeFallback(understanding?.intent, enabled);
  }
  if (understanding?.intent === "human_request") target = "handoff";
  if (!aiAvailable) target = "handoff";

  // ---------- STEP 5 + 6: Knowledge retrieval and specialist response
  let specialistOut: SpecialistOutput | null = null;
  let hits: KnowledgeHit[] = [];

  if (target !== "handoff") {
    emit({ type: "step", step: 5, key: "knowledge", title: "Knowledge base retrieval", status: "running" });
    try {
      const query = [latestText, understanding?.summary, understanding?.category?.replace(/_/g, " ")].filter(Boolean).join(" ");
      hits = await getRetriever(db).search(orgId, query, 4);
      emit({
        type: "step",
        step: 5,
        key: "knowledge",
        title: "Knowledge base retrieval",
        status: "success",
        detail: hits.length ? `${hits.length} article(s) found` : "No matching articles",
        output: hits.map((h) => ({ id: h.id, title: h.title, category: h.category })),
      });
    } catch (err) {
      emit({ type: "step", step: 5, key: "knowledge", title: "Knowledge base retrieval", status: "error", detail: String(err) });
    }

    emit({ type: "step", step: 6, key: target, title: AGENT_META[target].name, status: "running" });
    try {
      const r = await callAgentJSON({
        model: MODELS.main(),
        system: specialistPrompt(target, {
          company: companyName,
          companyDescription: settings.company_description,
          tone: settings.tone,
        }),
        user: `${contextBlock}

<analysis>
Intent: ${understanding?.intent ?? "unknown"}; category: ${understanding?.category ?? "unknown"}; summary: ${understanding?.summary ?? "n/a"}
Customer emotion: ${sentiment?.emotion ?? "unknown"} (frustration ${sentiment?.frustration_score ?? "n/a"})
Extracted details: ${JSON.stringify(understanding?.entities ?? {})}
</analysis>

<knowledge>
${formatKnowledge(hits)}
</knowledge>`,
        schema: specialistSchema,
        maxTokens: 1200,
      });
      specialistOut = r.data;
      const validIds = new Set(hits.map((h) => h.id));
      specialistOut.used_article_ids = specialistOut.used_article_ids.filter((id) => validIds.has(id));
      log(target, 6, "success", {
        input: { intent: understanding?.intent, knowledge: hits.map((h) => h.id) },
        output: specialistOut,
        confidence: specialistOut.confidence,
        latencyMs: r.latencyMs,
        model: r.model,
      });
      emit({ type: "step", step: 6, key: target, title: AGENT_META[target].name, status: "success", output: specialistOut, confidence: specialistOut.confidence, latencyMs: r.latencyMs });
    } catch (err) {
      const msg = markAIError(err);
      log(target, 6, "error", { error: msg });
      emit({ type: "step", step: 6, key: target, title: AGENT_META[target].name, status: "error", detail: msg });
    }
  }

  // ---------- STEP 7: Confidence and escalation check
  const reasons: string[] = [];
  if (!aiAvailable) reasons.push("AI service unavailable");
  if (target === "handoff") reasons.push(understanding?.intent === "human_request" ? "Customer asked for a human" : "Routed directly to a human");
  if (routing?.escalate) reasons.push(`Routing agent flagged: ${routing.reason || "high risk"}`);
  if (target !== "handoff" && !specialistOut) reasons.push("Specialist agent failed to respond");
  if (specialistOut?.needs_human) reasons.push(`Specialist needs a human: ${specialistOut.reason || "verification required"}`);
  if (specialistOut && specialistOut.confidence < settings.confidence_threshold)
    reasons.push(`Low confidence (${specialistOut.confidence.toFixed(2)} < ${settings.confidence_threshold})`);
  if (settings.auto_escalate_negative && sentiment?.escalation_recommended)
    reasons.push(`Sentiment agent recommends escalation: ${sentiment.reason || sentiment.emotion}`);

  const escalate = reasons.length > 0;
  emit({
    type: "step",
    step: 7,
    key: "check",
    title: "Confidence & escalation check",
    status: "success",
    detail: escalate ? reasons.join(" • ") : `Confidence ${specialistOut?.confidence.toFixed(2)} meets threshold ${settings.confidence_threshold}`,
    output: { escalate, reasons, threshold: settings.confidence_threshold },
    confidence: specialistOut?.confidence ?? null,
  });

  // ---------- STEP 8: Human handoff
  let handoff: HandoffOutput | null = null;
  let assignee: { id: string; name: string } | null = null;
  let ticketId: string | null = null;

  if (escalate) {
    assignee = await pickAvailableHuman(db, orgId, (convo?.assigned_to as string | null) ?? null);
    if (enabled.has("handoff") && aiAvailable) {
      emit({ type: "step", step: 8, key: "handoff", title: AGENT_META.handoff.name, status: "running" });
      try {
        const r = await callAgentJSON({
          model: MODELS.main(),
          system: handoffPrompt({ assigneeName: assignee?.name ?? null, tone: settings.tone }),
          user: `${contextBlock}

<analysis>
Understanding: ${JSON.stringify(understanding ?? {})}
Sentiment: ${JSON.stringify(sentiment ?? {})}
Escalation reasons: ${reasons.join("; ")}
Draft AI reply (may be incomplete): ${specialistOut?.reply ?? "(none)"}
</analysis>`,
          schema: handoffSchema,
          maxTokens: 900,
        });
        handoff = r.data;
        log("handoff", 8, "success", { input: { reasons }, output: { ...r.data, assigned_to: assignee }, confidence: null, latencyMs: r.latencyMs, model: r.model });
        emit({ type: "step", step: 8, key: "handoff", title: AGENT_META.handoff.name, status: "success", output: { ...r.data, assigned_to: assignee?.name ?? "Unassigned (no one available)" }, latencyMs: r.latencyMs });
      } catch (err) {
        const msg = markAIError(err);
        log("handoff", 8, "error", { error: msg });
        emit({ type: "step", step: 8, key: "handoff", title: AGENT_META.handoff.name, status: "error", detail: msg });
      }
    } else {
      log("handoff", 8, "skipped", { output: { reason: aiAvailable ? "Agent disabled" : "AI unavailable", reasons } });
      emit({ type: "step", step: 8, key: "handoff", title: AGENT_META.handoff.name, status: "skipped", detail: "Conversation flagged for a human without an AI summary" });
    }
  }

  // ---------- Decide what the customer sees
  let replyText: string;
  let replyAgent: AgentKey | "system";
  if (escalate) {
    const parts: string[] = [];
    // If the specialist gave a useful partial answer, keep it and add the handoff note.
    if (specialistOut && !specialistOut.needs_human && specialistOut.confidence >= 0.4) parts.push(specialistOut.reply);
    else if (specialistOut?.needs_human) parts.push(specialistOut.reply);
    if (handoff) parts.push(handoff.customer_message);
    else if (!specialistOut)
      parts.push(
        aiAvailable
          ? "Thanks for your message. I'm passing this to a member of our support team, who will reply here."
          : "Thanks for your message. Our AI assistant is unavailable right now, so a member of our support team will reply here."
      );
    replyText = Array.from(new Set(parts)).join("\n\n");
    replyAgent = handoff ? "handoff" : specialistOut ? (target as AgentKey) : "system";
  } else {
    replyText = specialistOut!.reply;
    replyAgent = target as AgentKey;
  }

  // ---------- STEP 9: Persist everything
  emit({ type: "step", step: 9, key: "save", title: "Saving conversation & agent activity", status: "running" });

  const now = new Date().toISOString();
  const { data: replyMsg } = await db
    .from("messages")
    .insert({
      organization_id: orgId,
      conversation_id: conversationId,
      sender: replyAgent === "system" ? "system" : "ai",
      agent_key: replyAgent === "system" ? null : replyAgent,
      author_name: replyAgent === "system" ? "CareLink" : AGENT_META[replyAgent].name,
      content: replyText,
      metadata: {
        run_id: runId,
        confidence: specialistOut?.confidence ?? null,
        escalated: escalate,
        sources: hits.filter((h) => specialistOut?.used_article_ids.includes(h.id)).map((h) => ({ id: h.id, title: h.title })),
      },
    })
    .select("id")
    .single();

  if (logs.length) {
    for (const l of logs) l.message_id = customerMessageId;
    await db.from("agent_logs").insert(logs, { defaultToNull: false });
  }

  const finalPriority = handoff ? maxPriority(priority, handoff.priority) : priority;
  const convoUpdate: Record<string, unknown> = {
    intent: understanding?.intent ?? convo?.intent ?? null,
    category: understanding?.category ?? convo?.category ?? null,
    sentiment: sentiment?.sentiment ?? understanding?.sentiment ?? convo?.sentiment ?? null,
    priority: finalPriority,
    current_agent: replyAgent === "system" ? null : replyAgent,
    last_message_at: now,
    first_response_at: convo?.first_response_at ?? now,
  };
  if (!convo?.subject && understanding?.summary) convoUpdate.subject = understanding.summary.slice(0, 160);
  if (escalate) {
    convoUpdate.status = "escalated";
    convoUpdate.escalated = true;
    convoUpdate.ai_resolved = false;
    convoUpdate.handoff_summary = handoff?.summary ?? `Escalated: ${reasons.join("; ")}`;
    if (assignee) convoUpdate.assigned_to = assignee.id;
  } else {
    convoUpdate.status = specialistOut?.resolved ? "resolved" : "open";
    convoUpdate.ai_resolved = Boolean(specialistOut?.resolved) && !convo?.escalated;
    if (specialistOut?.resolved) convoUpdate.resolved_at = now;
  }
  await db.from("conversations").update(convoUpdate).eq("id", conversationId);

  if (convo?.customer_id && (sentiment?.sentiment || understanding?.sentiment)) {
    await db
      .from("customers")
      .update({ sentiment: sentiment?.sentiment ?? understanding?.sentiment, last_interaction_at: now })
      .eq("id", convo.customer_id);
  }

  if (escalate) {
    ticketId = await upsertEscalationTicket(db, {
      orgId,
      conversationId,
      customerId: (convo?.customer_id as string) ?? null,
      title: handoff?.ticket_title ?? understanding?.summary?.slice(0, 120) ?? "Customer needs human assistance",
      description: [
        handoff?.summary ?? `Escalation reasons: ${reasons.join("; ")}`,
        handoff?.suggested_next_steps?.length ? `\nSuggested next steps:\n- ${handoff.suggested_next_steps.join("\n- ")}` : "",
        `\nCustomer's message: "${latestText.slice(0, 500)}"`,
      ].join("\n"),
      category: understanding?.category ?? "general",
      priority: finalPriority,
      assignedTo: assignee?.id ?? null,
    });
  }

  emit({ type: "step", step: 9, key: "save", title: "Saving conversation & agent activity", status: "success", detail: `${logs.length} agent log(s) saved${ticketId ? ", escalation ticket created" : ""}` });

  const final: FinalResult = {
    conversationId,
    messageId: replyMsg?.id ?? null,
    reply: replyText,
    agent: replyAgent,
    agentName: replyAgent === "system" ? "CareLink" : AGENT_META[replyAgent].name,
    confidence: specialistOut?.confidence ?? null,
    escalated: escalate,
    escalationReasons: reasons,
    assignedTo: assignee,
    ticketId,
    intent: understanding?.intent ?? null,
    priority: finalPriority,
    sentiment: sentiment?.sentiment ?? understanding?.sentiment ?? null,
  };

  // ---------- STEP 10: response delivered
  emit({ type: "step", step: 10, key: "respond", title: "Response delivered to customer", status: "success", detail: final.agentName });
  emit({ type: "final", final });
  return final;
}

// ------------------------------------------------------------------ Manual handoff ("Request human support")

export async function runManualHandoff(opts: {
  db: SupabaseClient;
  orgId: string;
  conversationId: string;
  requestedBy: string;
}): Promise<FinalResult> {
  const { db, orgId, conversationId } = opts;
  const runId = randomUUID();
  const { data: convo } = await db.from("conversations").select("*, customers(name)").eq("id", conversationId).single();
  if (!convo) throw new Error("Conversation not found");
  const { data: org } = await db.from("organizations").select("settings").eq("id", orgId).single();
  const settings: OrgSettings = { ...DEFAULT_SETTINGS, ...((org?.settings as Partial<OrgSettings>) ?? {}) };
  const { data: agentRow } = await db.from("ai_agents").select("enabled").eq("organization_id", orgId).eq("key", "handoff").maybeSingle();
  const { data: rows } = await db
    .from("messages")
    .select("sender, content, agent_key")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: false })
    .limit(15);

  const assignee = await pickAvailableHuman(db, orgId, convo.assigned_to);
  let handoff: HandoffOutput | null = null;
  const reason = `Human support requested by ${opts.requestedBy}`;

  if (agentRow?.enabled !== false) {
    try {
      const r = await callAgentJSON({
        model: MODELS.main(),
        system: handoffPrompt({ assigneeName: assignee?.name ?? null, tone: settings.tone }),
        user: `Customer name: ${(convo.customers as { name: string } | null)?.name ?? "Customer"}

<history>
${formatHistory((rows ?? []).slice().reverse())}
</history>

<analysis>
Escalation reason: ${reason}
</analysis>`,
        schema: handoffSchema,
        maxTokens: 900,
      });
      handoff = r.data;
      await db.from("agent_logs").insert({
        organization_id: orgId,
        conversation_id: conversationId,
        run_id: runId,
        agent_key: "handoff",
        step: 8,
        status: "success",
        input: { reason },
        output: { ...r.data, assigned_to: assignee },
        latency_ms: r.latencyMs,
        model: r.model,
      });
    } catch (err) {
      await db.from("agent_logs").insert({
        organization_id: orgId,
        conversation_id: conversationId,
        run_id: runId,
        agent_key: "handoff",
        step: 8,
        status: "error",
        input: { reason },
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  const reply =
    handoff?.customer_message ??
    `I've passed your conversation to ${assignee ? assignee.name + " from " : ""}our support team. They will reply here.`;

  const { data: msg } = await db
    .from("messages")
    .insert({
      organization_id: orgId,
      conversation_id: conversationId,
      sender: handoff ? "ai" : "system",
      agent_key: handoff ? "handoff" : null,
      author_name: handoff ? AGENT_META.handoff.name : "CareLink",
      content: reply,
      metadata: { run_id: runId, escalated: true },
    })
    .select("id")
    .single();

  const priority = maxPriority(convo.priority as Priority, handoff?.priority ?? "medium");
  await db
    .from("conversations")
    .update({
      status: "escalated",
      escalated: true,
      ai_resolved: false,
      current_agent: "handoff",
      handoff_summary: handoff?.summary ?? reason,
      assigned_to: assignee?.id ?? convo.assigned_to,
      priority,
      last_message_at: new Date().toISOString(),
    })
    .eq("id", conversationId);

  const ticketId = await upsertEscalationTicket(db, {
    orgId,
    conversationId,
    customerId: convo.customer_id,
    title: handoff?.ticket_title ?? convo.subject ?? "Customer requested human support",
    description: handoff?.summary ?? reason,
    category: convo.category ?? "general",
    priority,
    assignedTo: assignee?.id ?? null,
  });

  return {
    conversationId,
    messageId: msg?.id ?? null,
    reply,
    agent: handoff ? "handoff" : "system",
    agentName: handoff ? AGENT_META.handoff.name : "CareLink",
    confidence: null,
    escalated: true,
    escalationReasons: [reason],
    assignedTo: assignee,
    ticketId,
    intent: convo.intent,
    priority,
    sentiment: convo.sentiment,
  };
}

// ------------------------------------------------------------------ Shared helpers

/** Least-loaded available human. Keeps the current assignee if they are still available. */
async function pickAvailableHuman(db: SupabaseClient, orgId: string, currentId: string | null) {
  const { data: people } = await db
    .from("team_members")
    .select("id, name, availability")
    .eq("organization_id", orgId)
    .eq("invite_status", "active");
  const available = (people ?? []).filter((p) => p.availability === "available");
  if (currentId) {
    const cur = available.find((p) => p.id === currentId);
    if (cur) return { id: cur.id as string, name: cur.name as string };
  }
  if (available.length === 0) return null;

  const { data: load } = await db
    .from("conversations")
    .select("assigned_to")
    .eq("organization_id", orgId)
    .in("status", ["open", "pending", "escalated"])
    .in("assigned_to", available.map((p) => p.id));
  const counts = new Map<string, number>();
  for (const row of load ?? []) counts.set(row.assigned_to as string, (counts.get(row.assigned_to as string) ?? 0) + 1);
  const best = available.sort((a, b) => (counts.get(a.id) ?? 0) - (counts.get(b.id) ?? 0))[0]!;
  return { id: best.id as string, name: best.name as string };
}

async function upsertEscalationTicket(
  db: SupabaseClient,
  t: {
    orgId: string;
    conversationId: string;
    customerId: string | null;
    title: string;
    description: string;
    category: string;
    priority: Priority;
    assignedTo: string | null;
  }
) {
  const { data: existing } = await db
    .from("tickets")
    .select("id")
    .eq("conversation_id", t.conversationId)
    .neq("status", "resolved")
    .limit(1)
    .maybeSingle();

  if (existing) {
    await db
      .from("tickets")
      .update({ status: "escalated", priority: t.priority, assigned_to: t.assignedTo, description: t.description })
      .eq("id", existing.id);
    return existing.id as string;
  }
  const { data } = await db
    .from("tickets")
    .insert({
      organization_id: t.orgId,
      conversation_id: t.conversationId,
      customer_id: t.customerId,
      title: t.title,
      description: t.description,
      category: t.category,
      priority: t.priority,
      status: "escalated",
      assigned_to: t.assignedTo,
    })
    .select("id")
    .single();
  return (data?.id as string) ?? null;
}
