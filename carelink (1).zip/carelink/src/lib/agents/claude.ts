import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import type { z } from "zod";

export class AIUnavailableError extends Error {
  constructor(message = "ANTHROPIC_API_KEY is not configured on the server.") {
    super(message);
  }
}

let client: Anthropic | null = null;

function getClient() {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new AIUnavailableError();
  if (!client) client = new Anthropic({ apiKey, authToken: null, maxRetries: 2, timeout: 60_000 });
  return client;
}

export function isAIConfigured() {
  return Boolean(process.env.ANTHROPIC_API_KEY);
}

export const MODELS = {
  main: () => process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
  fast: () => process.env.ANTHROPIC_FAST_MODEL || "claude-haiku-5-5",
};

/** Pull the first top-level JSON object out of a model reply (tolerates ```json fences). */
export function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenced ? fenced[1]! : text;
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start === -1 || end === -1 || end < start) throw new Error("Model reply did not contain JSON");
  return JSON.parse(candidate.slice(start, end + 1));
}

export interface AgentCallResult<T> {
  data: T;
  latencyMs: number;
  model: string;
  usage: { input_tokens: number; output_tokens: number };
}

/**
 * Calls Claude and validates the reply against a zod schema.
 * If the reply is not valid JSON or fails validation, it retries once and tells the
 * model what went wrong.
 */
export async function callAgentJSON<S extends z.ZodTypeAny>(opts: {
  model: string;
  system: string;
  user: string;
  schema: S;
  maxTokens?: number;
}): Promise<AgentCallResult<z.infer<S>>> {
  const anthropic = getClient();
  const started = Date.now();
  const messages: Anthropic.MessageParam[] = [{ role: "user", content: opts.user }];
  let lastError = "";
  const usage = { input_tokens: 0, output_tokens: 0 };

  for (let attempt = 0; attempt < 2; attempt++) {
    const res = await anthropic.messages.create({
      model: opts.model,
      max_tokens: opts.maxTokens ?? 800,
      system: opts.system,
      messages,
    });
    usage.input_tokens += res.usage?.input_tokens ?? 0;
    usage.output_tokens += res.usage?.output_tokens ?? 0;

    const text = res.content
      .map((b) => (b.type === "text" ? b.text : ""))
      .join("")
      .trim();

    try {
      const parsed = opts.schema.parse(extractJson(text));
      return { data: parsed, latencyMs: Date.now() - started, model: opts.model, usage };
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
      messages.push({ role: "assistant", content: text || "(empty)" });
      messages.push({
        role: "user",
        content: `Your previous reply could not be used (${lastError.slice(0, 300)}). Reply again with only the JSON object that matches the required format.`,
      });
    }
  }
  throw new Error(`Agent returned invalid output: ${lastError}`);
}
