import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { AgentKey } from "@/types";
import { AGENT_ORDER, AGENT_META } from "@/lib/constants";

export interface Metrics {
  range: { from: string; to: string };
  totals: {
    conversations: number;
    aiResolved: number;
    escalated: number;
    openTickets: number;
    resolvedTickets: number;
    pendingTickets: number;
    inProgressTickets: number;
    escalatedTickets: number;
    totalTickets: number;
    aiResolutionRate: number | null;
    avgFirstResponseMs: number | null;
    avgResolutionMs: number | null;
    csat: number | null;
    csatResponses: number;
  };
  daily: { date: string; conversations: number; aiResolved: number; escalated: number }[];
  weekly: { week: string; conversations: number; aiResolved: number; escalated: number }[];
  ticketStatus: { status: string; count: number }[];
  topIssues: { category: string; count: number }[];
  channels: { channel: string; count: number }[];
  agents: {
    key: AgentKey;
    name: string;
    tasks: number;
    successRate: number | null;
    avgLatencyMs: number | null;
    avgConfidence: number | null;
    lastActive: string | null;
  }[];
  hasDemo: boolean;
}

const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);
const dayKey = (d: Date) => d.toISOString().slice(0, 10);

function weekKey(d: Date) {
  const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const day = x.getUTCDay() || 7;
  x.setUTCDate(x.getUTCDate() - day + 1); // Monday
  return x.toISOString().slice(0, 10);
}

export async function computeMetrics(db: SupabaseClient, orgId: string, from: Date, to: Date): Promise<Metrics> {
  const fromIso = from.toISOString();
  const toIso = to.toISOString();

  const [convosRes, ticketsRes, logsRes] = await Promise.all([
    db
      .from("conversations")
      .select("id, channel, status, category, ai_resolved, escalated, csat, created_at, first_response_at, resolved_at, is_demo")
      .eq("organization_id", orgId)
      .gte("created_at", fromIso)
      .lte("created_at", toIso)
      .limit(10000),
    db
      .from("tickets")
      .select("status, category, created_at")
      .eq("organization_id", orgId)
      .gte("created_at", fromIso)
      .lte("created_at", toIso)
      .limit(10000),
    db
      .from("agent_logs")
      .select("agent_key, status, latency_ms, confidence, created_at")
      .eq("organization_id", orgId)
      .gte("created_at", fromIso)
      .lte("created_at", toIso)
      .limit(20000),
  ]);

  const convos = convosRes.data ?? [];
  const tickets = ticketsRes.data ?? [];
  const logs = logsRes.data ?? [];

  const aiResolved = convos.filter((c) => c.ai_resolved).length;
  const escalated = convos.filter((c) => c.escalated).length;
  const firstResp = convos
    .filter((c) => c.first_response_at)
    .map((c) => new Date(c.first_response_at!).getTime() - new Date(c.created_at).getTime())
    .filter((x) => x >= 0);
  const resolution = convos
    .filter((c) => c.resolved_at)
    .map((c) => new Date(c.resolved_at!).getTime() - new Date(c.created_at).getTime())
    .filter((x) => x >= 0);
  const csats = convos.map((c) => c.csat).filter((x): x is number => typeof x === "number");

  // Daily buckets across the whole range (so empty days show as 0)
  const dailyMap = new Map<string, { conversations: number; aiResolved: number; escalated: number }>();
  for (let d = new Date(from); d <= to; d = new Date(d.getTime() + 86400000)) {
    dailyMap.set(dayKey(d), { conversations: 0, aiResolved: 0, escalated: 0 });
  }
  const weeklyMap = new Map<string, { conversations: number; aiResolved: number; escalated: number }>();
  for (const c of convos) {
    const d = new Date(c.created_at);
    const dk = dayKey(d);
    const wk = weekKey(d);
    const day = dailyMap.get(dk) ?? { conversations: 0, aiResolved: 0, escalated: 0 };
    const week = weeklyMap.get(wk) ?? { conversations: 0, aiResolved: 0, escalated: 0 };
    for (const b of [day, week]) {
      b.conversations++;
      if (c.ai_resolved) b.aiResolved++;
      if (c.escalated) b.escalated++;
    }
    dailyMap.set(dk, day);
    weeklyMap.set(wk, week);
  }

  const countBy = <T,>(rows: T[], key: (r: T) => string | null | undefined) => {
    const m = new Map<string, number>();
    for (const r of rows) {
      const k = key(r) || "uncategorised";
      m.set(k, (m.get(k) ?? 0) + 1);
    }
    return m;
  };

  const ticketStatus = countBy(tickets, (t) => t.status);
  const issues = countBy(convos, (c) => c.category);
  const channels = countBy(convos, (c) => c.channel);

  const agents = AGENT_ORDER.map((key) => {
    const rows = logs.filter((l) => l.agent_key === key && l.status !== "skipped");
    const ok = rows.filter((l) => l.status === "success");
    return {
      key,
      name: AGENT_META[key].name,
      tasks: rows.length,
      successRate: rows.length ? ok.length / rows.length : null,
      avgLatencyMs: avg(rows.map((r) => r.latency_ms).filter((x): x is number => typeof x === "number")),
      avgConfidence: avg(ok.map((r) => Number(r.confidence)).filter((x) => !Number.isNaN(x) && x > 0)),
      lastActive: rows.length ? rows.map((r) => r.created_at).sort().at(-1)! : null,
    };
  });

  const ts = (s: string) => ticketStatus.get(s) ?? 0;

  return {
    range: { from: fromIso, to: toIso },
    totals: {
      conversations: convos.length,
      aiResolved,
      escalated,
      openTickets: ts("open"),
      resolvedTickets: ts("resolved"),
      pendingTickets: ts("pending"),
      inProgressTickets: ts("in_progress"),
      escalatedTickets: ts("escalated"),
      totalTickets: tickets.length,
      aiResolutionRate: convos.length ? aiResolved / convos.length : null,
      avgFirstResponseMs: avg(firstResp),
      avgResolutionMs: avg(resolution),
      csat: avg(csats),
      csatResponses: csats.length,
    },
    daily: Array.from(dailyMap.entries()).map(([date, v]) => ({ date, ...v })),
    weekly: Array.from(weeklyMap.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([week, v]) => ({ week, ...v })),
    ticketStatus: ["open", "in_progress", "pending", "resolved", "escalated"].map((s) => ({ status: s, count: ts(s) })),
    topIssues: Array.from(issues.entries())
      .map(([category, count]) => ({ category, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8),
    channels: Array.from(channels.entries()).map(([channel, count]) => ({ channel, count })),
    agents,
    hasDemo: convos.some((c) => c.is_demo),
  };
}

export function parseRange(sp: { from?: string; to?: string; range?: string }) {
  const to = sp.to ? new Date(sp.to + "T23:59:59") : new Date();
  let from: Date;
  if (sp.from) from = new Date(sp.from + "T00:00:00");
  else {
    const days = Number(sp.range ?? 14);
    from = new Date(to.getTime() - (Number.isFinite(days) && days > 0 ? days - 1 : 13) * 86400000);
    from.setHours(0, 0, 0, 0);
  }
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || from > to) {
    const t = new Date();
    return { from: new Date(t.getTime() - 13 * 86400000), to: t };
  }
  return { from, to };
}
