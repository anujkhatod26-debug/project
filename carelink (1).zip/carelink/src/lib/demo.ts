import "server-only";
import { randomUUID } from "crypto";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { AgentKey, Priority } from "@/types";
import { AGENT_META } from "@/lib/constants";

/**
 * DEMO DATA. Everything inserted here has is_demo = true and is labelled "Demo" in the UI.
 * The agent logs below describe historical sample runs; live messages always go through
 * the real Claude-powered orchestrator.
 */

const CUSTOMERS = [
  ["Aarav Sharma", "aarav.sharma@example.com"],
  ["Priya Nair", "priya.nair@example.com"],
  ["Rohan Mehta", "rohan.mehta@example.com"],
  ["Sneha Kulkarni", "sneha.k@example.com"],
  ["Vikram Rao", "vikram.rao@example.com"],
  ["Ananya Iyer", "ananya.iyer@example.com"],
  ["Karthik Reddy", "karthik.r@example.com"],
  ["Meera Joshi", "meera.joshi@example.com"],
  ["Arjun Patil", "arjun.patil@example.com"],
  ["Divya Hegde", "divya.hegde@example.com"],
  ["Rahul Desai", "rahul.desai@example.com"],
  ["Ishita Gupta", "ishita.gupta@example.com"],
] as const;

const TEAM = [
  ["Kavya Menon", "kavya.menon@demo.carelink", "support_manager", "available"],
  ["Nikhil Bhat", "nikhil.bhat@demo.carelink", "support_agent", "available"],
  ["Fatima Shaikh", "fatima.shaikh@demo.carelink", "support_agent", "busy"],
  ["Suresh Gowda", "suresh.gowda@demo.carelink", "support_agent", "away"],
] as const;

type Scenario = {
  intent: string;
  category: string;
  agent: AgentKey;
  sentiment: string;
  priority: Priority;
  customer: string;
  reply: string;
  escalate?: boolean;
  confidence: number;
};

const SCENARIOS: Scenario[] = [
  {
    intent: "billing",
    category: "payment_failure",
    agent: "billing",
    sentiment: "negative",
    priority: "high",
    customer: "My payment was deducted but my order failed.",
    reply:
      "I'm sorry about that. When an order fails after payment, the amount is usually reversed automatically to your original payment method within 5 to 7 business days. Could you share your order ID (not your card details) so our billing team can check the transaction?",
    confidence: 0.82,
  },
  {
    intent: "account",
    category: "login_issue",
    agent: "technical",
    sentiment: "negative",
    priority: "high",
    customer: "I cannot log into my account.",
    reply:
      "Let's sort this out. 1) Check that Caps Lock is off and your email is spelled correctly. 2) Use 'Forgot password' on the login page to get a reset link. 3) If you see an error message, tell me exactly what it says.",
    confidence: 0.86,
  },
  {
    intent: "refund",
    category: "refund_request",
    agent: "billing",
    sentiment: "neutral",
    priority: "medium",
    customer: "I want to request a refund.",
    reply:
      "You can request a refund within 30 days of purchase for unused items. Please share your order ID and the reason for the refund, and our billing team will review it. I can't issue the refund myself, but I'll make sure it reaches the right people.",
    confidence: 0.78,
    escalate: true,
  },
  {
    intent: "account",
    category: "password_reset",
    agent: "technical",
    sentiment: "neutral",
    priority: "low",
    customer: "How can I change my password?",
    reply:
      "Go to Settings → Security → Change password, enter your current password and then your new one twice. If you've forgotten your current password, sign out and use 'Forgot password' on the login page instead.",
    confidence: 0.93,
  },
  {
    intent: "complaint",
    category: "delayed_response",
    agent: "support",
    sentiment: "very_negative",
    priority: "urgent",
    customer: "I have been waiting for a response for two days.",
    reply: "I'm really sorry for the wait. I've passed your conversation to a team member who will pick it up personally.",
    confidence: 0.55,
    escalate: true,
  },
  {
    intent: "general",
    category: "shipping_info",
    agent: "support",
    sentiment: "positive",
    priority: "low",
    customer: "How long does delivery usually take to Bengaluru?",
    reply: "Standard delivery within India takes 3 to 5 business days, and metro cities like Bengaluru are often on the faster side. You'll get a tracking link by email once it ships.",
    confidence: 0.9,
  },
  {
    intent: "billing",
    category: "invoice_request",
    agent: "billing",
    sentiment: "neutral",
    priority: "low",
    customer: "Where can I download the invoice for my last order?",
    reply: "Open Orders, select the order and click 'Download invoice'. Invoices are available as PDF once the order has shipped.",
    confidence: 0.91,
  },
  {
    intent: "technical",
    category: "app_crash",
    agent: "technical",
    sentiment: "negative",
    priority: "medium",
    customer: "The app keeps crashing when I open my cart.",
    reply: "Sorry about that. Please update the app to the latest version, then clear the app cache (Settings → Apps → Cache). If it still crashes, tell me your phone model and OS version and I'll pass it to our tech team.",
    confidence: 0.72,
  },
];

const KB = [
  {
    title: "Refund policy",
    category: "billing",
    tags: ["refund", "returns"],
    content:
      "Customers can request a refund within 30 days of purchase for unused items in original condition. Refunds are reviewed by the billing team and, once approved, are credited to the original payment method within 5 to 7 business days. Digital products and gift cards are not refundable. To start a refund, the customer must share their order ID and reason. Support agents and AI assistants cannot approve or issue refunds themselves.",
  },
  {
    title: "Payment deducted but order failed",
    category: "billing",
    tags: ["payment", "failed order", "deducted"],
    content:
      "If money was deducted but the order shows as failed, the payment gateway normally reverses the amount automatically within 5 to 7 business days. If the amount has not returned after 7 business days, the billing team investigates using the order ID and transaction date. Never ask customers for full card numbers, CVV or OTPs.",
  },
  {
    title: "How to reset or change your password",
    category: "account",
    tags: ["password", "reset", "security"],
    content:
      "To change a password while signed in: Settings → Security → Change password. To reset a forgotten password: on the login page click 'Forgot password', enter the registered email and follow the link (valid for 30 minutes). Check the spam folder if the email does not arrive within 5 minutes.",
  },
  {
    title: "Login troubleshooting",
    category: "technical",
    tags: ["login", "sign in", "account locked"],
    content:
      "Common login fixes: confirm the email address, check Caps Lock, reset the password, clear browser cookies or try another browser. After 5 failed attempts an account is locked for 15 minutes. If the customer still cannot sign in after a reset, a human agent must verify identity before unlocking the account.",
  },
  {
    title: "Support response times",
    category: "general",
    tags: ["response time", "sla", "waiting"],
    content:
      "Live chat is answered instantly by the AI assistant 24/7. Human support is available Monday to Saturday, 9 AM to 7 PM IST. Email tickets get a first human response within 24 hours. Urgent issues (payments, account lockouts) are prioritised.",
  },
  {
    title: "Shipping and delivery",
    category: "orders",
    tags: ["shipping", "delivery", "tracking"],
    content:
      "Standard delivery within India takes 3 to 5 business days. Express delivery (1 to 2 business days) is available in metro cities. A tracking link is emailed once the order ships. Orders above ₹999 ship free.",
  },
];

function daysAgo(d: number, hourJitter = 0) {
  return new Date(Date.now() - d * 86400000 - hourJitter * 3600000);
}

function rand(seed: number) {
  // deterministic pseudo random so demo data looks the same each time
  const x = Math.sin(seed * 9301 + 49297) * 233280;
  return x - Math.floor(x);
}

export async function seedDemoData(db: SupabaseClient, orgId: string) {
  await clearDemoData(db, orgId);

  // Team
  const { data: team, error: teamErr } = await db
    .from("team_members")
    .insert(
      TEAM.map(([name, email, role, availability]) => ({
        organization_id: orgId,
        name,
        email,
        role,
        availability,
        invite_status: "active",
        is_demo: true,
      })),
      { defaultToNull: false }
    )
    .select("id, name");
  if (teamErr) throw new Error(`Demo team: ${teamErr.message}`);

  // Knowledge base
  const { error: kbErr } = await db.from("knowledge_articles").insert(
    KB.map((a) => ({ ...a, organization_id: orgId, type: "faq", is_demo: true })),
    { defaultToNull: false }
  );
  if (kbErr) throw new Error(`Demo knowledge base: ${kbErr.message}`);

  // Customers
  const channels = ["web_chat", "web_chat", "web_chat", "email", "whatsapp", "instagram", "messenger"] as const;
  const { data: customers, error: custErr } = await db
    .from("customers")
    .insert(
      CUSTOMERS.map(([name, email], i) => ({
        organization_id: orgId,
        name,
        email,
        primary_channel: channels[i % channels.length],
        is_demo: true,
        last_interaction_at: daysAgo(i % 6).toISOString(),
      })),
      { defaultToNull: false }
    )
    .select("id, name, primary_channel");
  if (custErr) throw new Error(`Demo customers: ${custErr.message}`);

  // Conversations, messages, logs, tickets
  const conversations: Record<string, unknown>[] = [];
  const messages: Record<string, unknown>[] = [];
  const logs: Record<string, unknown>[] = [];
  const tickets: Record<string, unknown>[] = [];

  for (let i = 0; i < 34; i++) {
    const r = rand(i + 1);
    const s = SCENARIOS[i % SCENARIOS.length]!;
    const customer = customers![i % customers!.length]!;
    const created = daysAgo(Math.floor(r * 14), Math.floor(rand(i + 50) * 20));
    const respondedMs = 1500 + Math.floor(rand(i + 7) * 5000);
    const first = new Date(created.getTime() + respondedMs);
    const escalated = Boolean(s.escalate) || r > 0.88;
    const resolved = !escalated && rand(i + 3) > 0.3;
    const assignee = escalated ? team![i % 2]! : null;
    const id = randomUUID();
    const runId = randomUUID();
    const resolvedAt = resolved ? new Date(created.getTime() + (5 + rand(i + 9) * 90) * 60000) : null;

    conversations.push({
      id,
      organization_id: orgId,
      customer_id: customer.id,
      channel: customer.primary_channel,
      subject: s.customer,
      status: escalated ? (rand(i + 11) > 0.5 ? "escalated" : "resolved") : resolved ? "resolved" : rand(i + 13) > 0.5 ? "open" : "pending",
      priority: s.priority,
      sentiment: s.sentiment,
      intent: s.intent,
      category: s.category,
      current_agent: escalated ? "handoff" : s.agent,
      assigned_to: assignee?.id ?? null,
      ai_resolved: resolved,
      escalated,
      handoff_summary: escalated ? `Demo: ${customer.name} — ${s.category.replace(/_/g, " ")}. AI could not fully resolve; needs human review.` : null,
      csat: resolved ? 3 + Math.round(rand(i + 17) * 2) : null,
      first_response_at: first.toISOString(),
      resolved_at: resolvedAt?.toISOString() ?? null,
      last_message_at: first.toISOString(),
      created_at: created.toISOString(),
      updated_at: first.toISOString(),
      is_demo: true,
    });

    const custMsgId = randomUUID();
    messages.push(
      {
        id: custMsgId,
        organization_id: orgId,
        conversation_id: id,
        sender: "customer",
        author_name: customer.name,
        content: s.customer,
        created_at: created.toISOString(),
        is_demo: true,
      },
      {
        organization_id: orgId,
        conversation_id: id,
        sender: "ai",
        agent_key: escalated ? "handoff" : s.agent,
        author_name: AGENT_META[escalated ? "handoff" : s.agent].name,
        content: escalated ? `${s.reply}\n\nA member of our team (${assignee?.name}) will take it from here.` : s.reply,
        metadata: { demo: true, confidence: s.confidence, escalated },
        created_at: first.toISOString(),
        is_demo: true,
      }
    );

    const steps: [AgentKey, number, number][] = [
      ["understanding", 2, 0.9],
      ["sentiment", 3, 0.85],
      ["routing", 4, 0.88],
      [s.agent, 6, s.confidence],
    ];
    if (escalated) steps.push(["handoff", 8, 0.8]);
    for (const [agent, step, conf] of steps) {
      logs.push({
        organization_id: orgId,
        conversation_id: id,
        message_id: custMsgId,
        run_id: runId,
        agent_key: agent,
        step,
        status: rand(i * 7 + step) > 0.97 ? "error" : "success",
        input: { demo: true },
        output: { demo: true, intent: s.intent, category: s.category, note: "Sample historical run (demo data)" },
        confidence: Math.min(0.99, Math.max(0.3, conf + (rand(i + step) - 0.5) * 0.1)),
        latency_ms: agent === "understanding" || agent === "sentiment" || agent === "routing" ? 400 + Math.floor(rand(i + step * 3) * 900) : 1800 + Math.floor(rand(i + step * 5) * 3500),
        model: "demo",
        created_at: new Date(created.getTime() + step * 300).toISOString(),
        is_demo: true,
      });
    }

    if (escalated || rand(i + 21) > 0.45) {
      tickets.push({
        organization_id: orgId,
        conversation_id: id,
        customer_id: customer.id,
        title: s.customer.replace(/\.$/, ""),
        description: `Demo ticket. ${customer.name} reported: "${s.customer}"`,
        category: s.category,
        priority: s.priority,
        status: escalated
          ? (rand(i + 31) > 0.5 ? "escalated" : "in_progress")
          : resolved
            ? "resolved"
            : (["open", "in_progress", "pending"] as const)[i % 3],
        assigned_to: assignee?.id ?? team![(i + 1) % team!.length]!.id,
        created_at: created.toISOString(),
        updated_at: (resolvedAt ?? first).toISOString(),
        resolved_at: !escalated && resolved ? resolvedAt?.toISOString() ?? null : null,
        is_demo: true,
      });
    }
  }

  for (const [table, rows] of [
    ["conversations", conversations],
    ["messages", messages],
    ["agent_logs", logs],
    ["tickets", tickets],
  ] as const) {
    const { error } = await db.from(table).insert(rows, { defaultToNull: false });
    if (error) throw new Error(`Demo ${table}: ${error.message}`);
  }

  return {
    customers: customers!.length,
    conversations: conversations.length,
    messages: messages.length,
    tickets: tickets.length,
    knowledge_articles: KB.length,
    team_members: team!.length,
  };
}

export async function clearDemoData(db: SupabaseClient, orgId: string) {
  // Order matters because of foreign keys.
  for (const table of ["agent_logs", "messages", "tickets", "conversations", "customers", "knowledge_articles", "team_members"]) {
    const { error } = await db.from(table).delete().eq("organization_id", orgId).eq("is_demo", true);
    if (error && !/policy/i.test(error.message)) throw new Error(`Clear ${table}: ${error.message}`);
  }
}
