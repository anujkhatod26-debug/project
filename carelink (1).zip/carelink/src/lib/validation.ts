import { z } from "zod";

const priority = z.enum(["low", "medium", "high", "urgent"]);
const ticketStatus = z.enum(["open", "in_progress", "pending", "resolved", "escalated"]);
const conversationStatus = z.enum(["open", "pending", "resolved", "escalated"]);
const role = z.enum(["admin", "support_manager", "support_agent"]);

/** Strip control characters (except newline/tab) and trim. Customer text stays data, never markup. */
export const cleanText = (max: number) =>
  z
    .string()
    .transform((s) => s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim())
    .pipe(z.string().min(1, "Required").max(max));

export const chatSchema = z.object({
  conversationId: z.uuid().optional(),
  customerId: z.uuid().optional(),
  customerName: cleanText(120).optional(),
  customerEmail: z.email().max(200).optional(),
  message: cleanText(4000),
});

export const widgetStartSchema = z.object({
  orgSlug: z.string().min(1).max(100),
  name: cleanText(120),
  email: z.email().max(200),
});

export const widgetMessageSchema = z.object({
  conversationId: z.uuid(),
  token: z.uuid(),
  message: cleanText(4000),
});

export const ticketCreateSchema = z.object({
  title: cleanText(200),
  description: z.string().max(10000).default(""),
  category: z.string().max(60).default("general"),
  priority: priority.default("medium"),
  status: ticketStatus.default("open"),
  customer_id: z.uuid().nullable().optional(),
  conversation_id: z.uuid().nullable().optional(),
  assigned_to: z.uuid().nullable().optional(),
});

export const ticketUpdateSchema = ticketCreateSchema.partial();

export const conversationUpdateSchema = z.object({
  status: conversationStatus.optional(),
  priority: priority.optional(),
  assigned_to: z.uuid().nullable().optional(),
  csat: z.number().int().min(1).max(5).nullable().optional(),
});

export const humanReplySchema = z.object({
  content: cleanText(4000),
});

export const articleSchema = z.object({
  title: cleanText(200),
  content: z.string().max(200000).default(""),
  category: z.string().max(60).default("general"),
  tags: z.array(z.string().max(40)).max(20).default([]),
});

export const customerSchema = z.object({
  name: cleanText(120),
  email: z.email().max(200).nullable().optional(),
  phone: z.string().max(40).nullable().optional(),
  notes: z.string().max(4000).nullable().optional(),
});

export const teamInviteSchema = z.object({
  name: cleanText(120),
  email: z.email().max(200),
  role,
});

export const teamUpdateSchema = z.object({
  role: role.optional(),
  availability: z.enum(["available", "busy", "away", "offline"]).optional(),
  name: cleanText(120).optional(),
});

export const profileSchema = z.object({
  full_name: cleanText(120).optional(),
  avatar_url: z.url().max(500).nullable().optional(),
  theme: z.enum(["dark", "midnight"]).optional(),
  notification_prefs: z.record(z.string(), z.boolean()).optional(),
});

export const orgSettingsSchema = z.object({
  name: cleanText(120).optional(),
  settings: z
    .object({
      confidence_threshold: z.number().min(0).max(1),
      tone: z.string().max(200),
      auto_escalate_negative: z.boolean(),
      company_description: z.string().max(2000),
    })
    .partial()
    .optional(),
});

export const channelUpdateSchema = z.object({
  enabled: z.boolean().optional(),
  config: z.record(z.string(), z.string().max(300)).optional(),
});
