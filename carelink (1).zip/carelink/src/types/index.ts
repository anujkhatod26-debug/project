export type UserRole = "admin" | "support_manager" | "support_agent";
export type Channel = "web_chat" | "email" | "whatsapp" | "instagram" | "messenger";
export type ConversationStatus = "open" | "pending" | "resolved" | "escalated";
export type Priority = "low" | "medium" | "high" | "urgent";
export type TicketStatus = "open" | "in_progress" | "pending" | "resolved" | "escalated";
export type Sender = "customer" | "ai" | "human" | "system";
export type AgentKey =
  | "understanding"
  | "sentiment"
  | "routing"
  | "support"
  | "technical"
  | "billing"
  | "handoff";

export interface Organization {
  id: string;
  name: string;
  slug: string;
  settings: OrgSettings;
}

export interface OrgSettings {
  confidence_threshold: number;
  tone: string;
  auto_escalate_negative: boolean;
  company_description: string;
}

export interface Profile {
  id: string;
  organization_id: string;
  full_name: string;
  email: string;
  role: UserRole;
  avatar_url: string | null;
  notification_prefs: Record<string, boolean>;
  theme: string;
}

export interface TeamMember {
  id: string;
  organization_id: string;
  profile_id: string | null;
  name: string;
  email: string;
  role: UserRole;
  availability: "available" | "busy" | "away" | "offline";
  invite_status: "invited" | "active";
  is_demo: boolean;
  created_at: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  primary_channel: Channel;
  sentiment: string;
  notes: string | null;
  is_demo: boolean;
  last_interaction_at: string | null;
  created_at: string;
}

export interface Conversation {
  id: string;
  organization_id: string;
  customer_id: string;
  channel: Channel;
  subject: string | null;
  status: ConversationStatus;
  priority: Priority;
  sentiment: string | null;
  intent: string | null;
  category: string | null;
  current_agent: string | null;
  assigned_to: string | null;
  ai_resolved: boolean;
  escalated: boolean;
  handoff_summary: string | null;
  csat: number | null;
  first_response_at: string | null;
  resolved_at: string | null;
  last_message_at: string;
  is_demo: boolean;
  created_at: string;
  customers?: Pick<Customer, "id" | "name" | "email"> | null;
  team_members?: Pick<TeamMember, "id" | "name"> | null;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender: Sender;
  agent_key: string | null;
  author_name: string | null;
  content: string;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface Ticket {
  id: string;
  ticket_number: string;
  customer_id: string | null;
  conversation_id: string | null;
  title: string;
  description: string;
  category: string;
  priority: Priority;
  status: TicketStatus;
  assigned_to: string | null;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
  customers?: Pick<Customer, "id" | "name"> | null;
  team_members?: Pick<TeamMember, "id" | "name"> | null;
}

export interface AiAgent {
  id: string;
  key: AgentKey;
  name: string;
  description: string;
  enabled: boolean;
}

export interface AgentLog {
  id: string;
  conversation_id: string | null;
  run_id: string;
  agent_key: AgentKey;
  step: number;
  status: "success" | "error" | "skipped";
  input: Record<string, unknown>;
  output: Record<string, unknown>;
  confidence: number | null;
  latency_ms: number | null;
  model: string | null;
  error: string | null;
  is_demo: boolean;
  created_at: string;
}

export interface KnowledgeArticle {
  id: string;
  title: string;
  content: string;
  category: string;
  type: "faq" | "document";
  tags: string[];
  file_path: string | null;
  file_name: string | null;
  file_size: number | null;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface ChannelIntegration {
  id: string;
  channel: Channel;
  status: "not_configured" | "pending_verification" | "connected" | "error";
  enabled: boolean;
  config: Record<string, string>;
  updated_at: string;
}
