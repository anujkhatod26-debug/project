"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowRight, MailCheck } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ fullName: "", email: "", password: "", organization: "" });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [checkEmail, setCheckEmail] = useState(false);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (form.password.length < 8) return setError("Password must be at least 8 characters.");
    setLoading(true);
    setError(null);
    const supabase = createClient();
    const { data, error } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: {
        data: { full_name: form.fullName, organization_name: form.organization },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    setLoading(false);
    if (error) return setError(error.message);
    if (data.session) {
      router.replace("/overview");
      router.refresh();
    } else {
      setCheckEmail(true);
    }
  }

  if (checkEmail) {
    return (
      <div className="glass-strong p-8 text-center">
        <MailCheck className="mx-auto h-10 w-10 text-electric-400" />
        <h2 className="mt-4 font-display text-xl font-semibold text-white">Check your inbox</h2>
        <p className="mt-2 text-sm text-slate-400">
          We sent a confirmation link to <span className="text-slate-200">{form.email}</span>. Open it to activate your workspace.
        </p>
        <Link href="/login" className="mt-6 inline-block text-sm text-electric-400">Back to sign in</Link>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-strong p-8">
      <h2 className="font-display text-2xl font-semibold text-white">Create your workspace</h2>
      <p className="mt-1 text-sm text-slate-400">
        The first account becomes the Admin. Teammates you invite join with the role you choose.
      </p>
      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <Field label="Full name">
          <Input required value={form.fullName} onChange={set("fullName")} placeholder="Pranav Hiremath" />
        </Field>
        <Field label="Organization name" hint="Leave blank if a teammate already invited you.">
          <Input value={form.organization} onChange={set("organization")} placeholder="Acme Retail" />
        </Field>
        <Field label="Work email">
          <Input type="email" required value={form.email} onChange={set("email")} placeholder="you@company.com" />
        </Field>
        <Field label="Password">
          <Input type="password" required minLength={8} value={form.password} onChange={set("password")} placeholder="At least 8 characters" />
        </Field>
        {error && <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-xs text-rose-300 ring-1 ring-rose-500/20">{error}</p>}
        <Button type="submit" className="w-full" size="lg" loading={loading}>
          Create account <ArrowRight />
        </Button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-400">
        Already have an account?{" "}
        <Link href="/login" className="font-medium text-electric-400 hover:text-electric-500">Sign in</Link>
      </p>
    </motion.div>
  );
}
