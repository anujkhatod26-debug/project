import { Logo } from "@/components/brand/logo";
import { TAGLINE } from "@/lib/constants";
import { Bot, GitBranch, MessagesSquare, ShieldCheck } from "lucide-react";

const points = [
  { icon: Bot, title: "Seven specialised AI agents", text: "Understanding, sentiment, routing, support, technical, billing and human handoff." },
  { icon: MessagesSquare, title: "One inbox for every channel", text: "Website chat today, with email, WhatsApp, Instagram and Messenger ready to connect." },
  { icon: GitBranch, title: "See every decision", text: "Watch each agent's reasoning, confidence and escalation in real time." },
  { icon: ShieldCheck, title: "Built safe", text: "Row-level security, server-side keys and no actions without authorization." },
];

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden overflow-hidden border-r border-white/5 lg:block">
        <div className="grid-bg absolute inset-0 opacity-60" />
        <div className="absolute -left-20 top-1/3 h-96 w-96 rounded-full bg-electric-600/20 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-80 w-80 rounded-full bg-violet-600/20 blur-3xl" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <Logo />
          <div>
            <h1 className="font-display text-4xl font-semibold leading-tight text-white">
              {TAGLINE.split(". ").map((part, i, arr) => (
                <span key={i} className={i === arr.length - 1 ? "gradient-text block" : "block"}>
                  {part}
                  {i < arr.length - 1 ? "." : ""}
                </span>
              ))}
            </h1>
            <div className="mt-10 grid gap-5">
              {points.map(({ icon: Icon, title, text }) => (
                <div key={title} className="flex gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/5 ring-1 ring-white/10">
                    <Icon className="h-5 w-5 text-electric-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{title}</p>
                    <p className="text-sm text-slate-400">{text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <p className="text-xs text-slate-500">Omnichannel Customer Support Multi-Agent System</p>
        </div>
      </div>
      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <Logo className="mb-8 lg:hidden" />
          {children}
        </div>
      </div>
    </div>
  );
}
