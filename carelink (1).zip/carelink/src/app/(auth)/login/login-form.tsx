"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";

export function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(params.get("error") === "no_profile" ? "Your account has no profile yet. Make sure the database migration has been run." : null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return setError(error.message);
    router.replace(params.get("next") || "/overview");
    router.refresh();
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-strong p-8">
      <h2 className="font-display text-2xl font-semibold text-white">Welcome back</h2>
      <p className="mt-1 text-sm text-slate-400">Sign in to your CareLink workspace.</p>
      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <Field label="Work email">
          <Input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
        </Field>
        <Field label="Password">
          <Input type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </Field>
        {error && <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-xs text-rose-300 ring-1 ring-rose-500/20">{error}</p>}
        <Button type="submit" className="w-full" size="lg" loading={loading}>
          Sign in <ArrowRight />
        </Button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-400">
        New to CareLink?{" "}
        <Link href="/register" className="font-medium text-electric-400 hover:text-electric-500">
          Create a workspace
        </Link>
      </p>
    </motion.div>
  );
}
