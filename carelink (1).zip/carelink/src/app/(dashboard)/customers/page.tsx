import Link from "next/link";
import { Users } from "lucide-react";
import { getSession } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { Avatar, EmptyState, PageHeader, Table, Td, Th } from "@/components/ui/misc";
import { Badge, DemoBadge, SentimentBadge } from "@/components/ui/badge";
import { CustomerDialog } from "@/components/customers/customer-dialog";
import { CustomerFilters } from "@/components/customers/filters";
import { CHANNEL_META } from "@/lib/constants";
import { formatDate } from "@/lib/utils";
import type { Channel, Customer } from "@/types";

export default async function CustomersPage({ searchParams }: { searchParams: Promise<{ q?: string; sentiment?: string }> }) {
  const sp = await searchParams;
  const { supabase } = await getSession();

  let query = supabase.from("customers").select("*").order("last_interaction_at", { ascending: false, nullsFirst: false }).limit(500);
  if (sp.q) query = query.or(`name.ilike.%${sp.q.replace(/[,%()]/g, "")}%,email.ilike.%${sp.q.replace(/[,%()]/g, "")}%`);
  if (sp.sentiment) query = query.eq("sentiment", sp.sentiment);

  const [{ data: customers }, { data: convos }, { data: tickets }] = await Promise.all([
    query,
    supabase.from("conversations").select("customer_id").limit(10000),
    supabase.from("tickets").select("customer_id, status").limit(10000),
  ]);

  const convoCount = new Map<string, number>();
  for (const c of convos ?? []) convoCount.set(c.customer_id, (convoCount.get(c.customer_id) ?? 0) + 1);
  const openTickets = new Map<string, number>();
  for (const t of tickets ?? []) if (t.customer_id && t.status !== "resolved") openTickets.set(t.customer_id, (openTickets.get(t.customer_id) ?? 0) + 1);

  return (
    <div>
      <PageHeader title="Customers" description="Everyone who has contacted your team, with their history and current mood." actions={<CustomerDialog />} />
      <Card className="p-0">
        <div className="border-b border-white/5 p-4"><CustomerFilters /></div>
        {(customers ?? []).length === 0 ? (
          <EmptyState icon={Users} title="No customers found" description="Customers are created automatically when they start a chat." />
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Customer</Th>
                <Th>Email</Th>
                <Th>Channel</Th>
                <Th className="text-center">Conversations</Th>
                <Th className="text-center">Open tickets</Th>
                <Th>Sentiment</Th>
                <Th>Last interaction</Th>
              </tr>
            </thead>
            <tbody>
              {(customers as Customer[]).map((c) => (
                <tr key={c.id} className="hover:bg-white/[0.02]">
                  <Td>
                    <Link href={`/customers/${c.id}`} className="flex items-center gap-3">
                      <Avatar name={c.name} />
                      <span className="font-medium text-white hover:text-electric-400">{c.name}</span>
                      {c.is_demo && <DemoBadge />}
                    </Link>
                  </Td>
                  <Td className="text-slate-400">{c.email ?? "—"}</Td>
                  <Td><Badge tone="slate">{CHANNEL_META[c.primary_channel as Channel]?.label}</Badge></Td>
                  <Td className="text-center">{convoCount.get(c.id) ?? 0}</Td>
                  <Td className="text-center">{openTickets.get(c.id) ?? 0}</Td>
                  <Td><SentimentBadge sentiment={c.sentiment} /></Td>
                  <Td className="text-slate-400">{formatDate(c.last_interaction_at)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </div>
  );
}
