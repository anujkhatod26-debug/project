import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Mail, MessagesSquare, Phone, Ticket } from "lucide-react";
import { getSession } from "@/lib/auth";
import { Card, CardHeader } from "@/components/ui/card";
import { Avatar, EmptyState } from "@/components/ui/misc";
import { Badge, DemoBadge, PriorityBadge, SentimentBadge, StatusBadge } from "@/components/ui/badge";
import { CustomerDialog } from "@/components/customers/customer-dialog";
import { AGENT_META, CHANNEL_META } from "@/lib/constants";
import { formatDate } from "@/lib/utils";
import type { AgentKey, Channel, Customer } from "@/types";

export default async function CustomerDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase } = await getSession();
  const { data: customer } = await supabase.from("customers").select("*").eq("id", id).maybeSingle<Customer>();
  if (!customer) notFound();

  const [{ data: convos }, { data: tickets }, { data: messages }] = await Promise.all([
    supabase.from("conversations").select("*").eq("customer_id", id).order("created_at", { ascending: false }),
    supabase.from("tickets").select("*").eq("customer_id", id).order("created_at", { ascending: false }),
    supabase
      .from("messages")
      .select("id, conversation_id, sender, agent_key, author_name, content, created_at, conversations!inner(customer_id)")
      .eq("conversations.customer_id", id)
      .order("created_at", { ascending: false })
      .limit(40),
  ]);

  return (
    <div>
      <Link href="/customers" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white">
        <ArrowLeft className="h-4 w-4" /> Customers
      </Link>
      <div className="grid gap-6 xl:grid-cols-3">
        <Card>
          <div className="flex items-start gap-4">
            <Avatar name={customer.name} className="h-14 w-14 text-base" />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h1 className="font-display text-xl font-semibold text-white">{customer.name}</h1>
                {customer.is_demo && <DemoBadge />}
              </div>
              <p className="mt-1 text-xs text-slate-500">Customer since {formatDate(customer.created_at, false)}</p>
            </div>
            <CustomerDialog customer={customer} />
          </div>
          <div className="mt-5 space-y-2 text-sm">
            <p className="flex items-center gap-2 text-slate-300"><Mail className="h-4 w-4 text-slate-500" /> {customer.email ?? "—"}</p>
            <p className="flex items-center gap-2 text-slate-300"><Phone className="h-4 w-4 text-slate-500" /> {customer.phone ?? "—"}</p>
          </div>
          <div className="mt-5 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl bg-white/5 p-3"><p className="font-display text-lg text-white">{convos?.length ?? 0}</p><p className="text-[11px] text-slate-500">Conversations</p></div>
            <div className="rounded-xl bg-white/5 p-3"><p className="font-display text-lg text-white">{(tickets ?? []).filter((t) => t.status !== "resolved").length}</p><p className="text-[11px] text-slate-500">Open tickets</p></div>
            <div className="flex flex-col items-center justify-center rounded-xl bg-white/5 p-3"><SentimentBadge sentiment={customer.sentiment} /><p className="mt-1 text-[11px] text-slate-500">Sentiment</p></div>
          </div>
          {customer.notes && <p className="mt-5 rounded-xl bg-white/5 p-3 text-sm text-slate-300">{customer.notes}</p>}
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader title="Conversations" />
          {(convos ?? []).length === 0 ? (
            <EmptyState icon={MessagesSquare} title="No conversations" />
          ) : (
            <ul className="divide-y divide-white/5">
              {(convos ?? []).map((c) => (
                <li key={c.id}>
                  <Link href={`/inbox?c=${c.id}`} className="flex items-center gap-3 py-3">
                    <Badge tone="slate">{CHANNEL_META[c.channel as Channel]?.label}</Badge>
                    <p className="min-w-0 flex-1 truncate text-sm text-slate-200">{c.subject ?? "Conversation"}</p>
                    <PriorityBadge priority={c.priority} />
                    <StatusBadge status={c.status} />
                    <span className="w-28 text-right text-[11px] text-slate-500">{formatDate(c.created_at)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <CardHeader title="Tickets" />
          {(tickets ?? []).length === 0 ? (
            <EmptyState icon={Ticket} title="No tickets" />
          ) : (
            <ul className="space-y-2">
              {(tickets ?? []).map((t) => (
                <li key={t.id}>
                  <Link href={`/tickets?t=${t.id}`} className="block rounded-xl bg-white/5 p-3 hover:bg-white/10">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs text-electric-400">{t.ticket_number}</span>
                      <StatusBadge status={t.status} />
                    </div>
                    <p className="mt-1 text-sm text-slate-200">{t.title}</p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader title="Interaction history" description="Latest messages across all conversations" />
          <ul className="space-y-3">
            {(messages ?? []).length === 0 && <li className="text-xs text-slate-500">No messages yet.</li>}
            {(messages ?? []).map((m) => (
              <li key={m.id} className="flex gap-3">
                <div className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${m.sender === "customer" ? "bg-electric-400" : m.sender === "ai" ? "bg-violet-400" : m.sender === "human" ? "bg-emerald-400" : "bg-slate-500"}`} />
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] text-slate-500">
                    {m.sender === "ai" ? AGENT_META[m.agent_key as AgentKey]?.name ?? "AI" : m.author_name ?? m.sender} · {formatDate(m.created_at)}
                  </p>
                  <p className="line-clamp-3 whitespace-pre-wrap text-sm text-slate-300">{m.content}</p>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
