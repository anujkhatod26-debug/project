import { Ticket as TicketIcon } from "lucide-react";
import { getSession, canManage } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { TicketDialog } from "@/components/tickets/ticket-dialog";
import { TicketFilters } from "@/components/tickets/ticket-filters";
import { TicketTable } from "@/components/tickets/ticket-table";
import { TICKET_STATUSES } from "@/lib/constants";
import { titleCase } from "@/lib/utils";
import type { Ticket } from "@/types";

type SP = { q?: string; status?: string; priority?: string; assigned?: string; t?: string };

export default async function TicketsPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const { supabase, profile } = await getSession();

  let q = supabase
    .from("tickets")
    .select("*, customers(id, name), team_members(id, name)")
    .order("created_at", { ascending: false })
    .limit(300);
  if (sp.t) q = q.eq("id", sp.t);
  if (sp.status) q = q.eq("status", sp.status);
  if (sp.priority) q = q.eq("priority", sp.priority);
  if (sp.assigned === "none") q = q.is("assigned_to", null);
  else if (sp.assigned) q = q.eq("assigned_to", sp.assigned);
  if (sp.q) {
    const term = sp.q.replace(/[,%()]/g, "");
    q = q.or(`ticket_number.ilike.%${term}%,title.ilike.%${term}%,description.ilike.%${term}%`);
  }

  const [{ data: tickets }, { data: team }, { data: customers }, { data: all }] = await Promise.all([
    q,
    supabase.from("team_members").select("id, name").eq("invite_status", "active").order("name"),
    supabase.from("customers").select("id, name").order("name").limit(500),
    supabase.from("tickets").select("status").limit(10000),
  ]);

  const counts = new Map<string, number>();
  for (const t of all ?? []) counts.set(t.status, (counts.get(t.status) ?? 0) + 1);

  return (
    <div>
      <PageHeader
        title="Tickets"
        description="Create, assign and track support tickets. Escalated AI conversations create tickets automatically."
        actions={<TicketDialog team={team ?? []} customers={customers ?? []} />}
      />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
        {TICKET_STATUSES.map((s) => (
          <div key={s} className="glass px-4 py-3">
            <p className="text-[11px] text-slate-500">{titleCase(s)}</p>
            <p className="font-display text-xl text-white">{counts.get(s) ?? 0}</p>
          </div>
        ))}
      </div>
      <Card className="p-0">
        <div className="border-b border-white/5 p-4"><TicketFilters team={team ?? []} /></div>
        {sp.t && <p className="border-b border-white/5 px-4 py-2 text-xs text-slate-400">Showing one ticket. <a href="/tickets" className="text-electric-400 hover:underline">Show all</a></p>}
        {(tickets ?? []).length === 0 ? (
          <EmptyState icon={TicketIcon} title="No tickets match" description="Create a ticket or adjust the filters." />
        ) : (
          <TicketTable
            key={JSON.stringify(sp)}
            tickets={tickets as Ticket[]}
            team={team ?? []}
            customers={customers ?? []}
            canDelete={canManage(profile.role)}
            highlight={sp.t}
          />
        )}
      </Card>
    </div>
  );
}
