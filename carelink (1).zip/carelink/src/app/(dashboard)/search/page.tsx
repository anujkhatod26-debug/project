import Link from "next/link";
import { BookOpen, MessagesSquare, Search, Ticket, Users } from "lucide-react";
import { getSession } from "@/lib/auth";
import { Card, CardHeader } from "@/components/ui/card";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { StatusBadge } from "@/components/ui/badge";

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  const { supabase } = await getSession();
  const term = q.replace(/[,%()]/g, "").trim();

  if (!term) {
    return (
      <div>
        <PageHeader title="Search" />
        <Card><EmptyState icon={Search} title="Type in the search bar above" /></Card>
      </div>
    );
  }

  const like = `%${term}%`;
  const [customers, tickets, convos, kb] = await Promise.all([
    supabase.from("customers").select("id, name, email").or(`name.ilike.${like},email.ilike.${like}`).limit(10),
    supabase.from("tickets").select("id, ticket_number, title, status").or(`ticket_number.ilike.${like},title.ilike.${like},description.ilike.${like}`).limit(10),
    supabase.from("conversations").select("id, subject, status, customers(name)").ilike("subject", like).limit(10),
    supabase.from("knowledge_articles").select("id, title, category").or(`title.ilike.${like},content.ilike.${like}`).limit(10),
  ]);

  const total = (customers.data?.length ?? 0) + (tickets.data?.length ?? 0) + (convos.data?.length ?? 0) + (kb.data?.length ?? 0);

  return (
    <div>
      <PageHeader title={`Results for “${term}”`} description={`${total} match(es) across customers, tickets, conversations and knowledge.`} />
      {total === 0 ? (
        <Card><EmptyState icon={Search} title="Nothing found" /></Card>
      ) : (
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader title="Customers" action={<Users className="h-4 w-4 text-slate-500" />} />
            {(customers.data ?? []).map((c) => (
              <Link key={c.id} href={`/customers/${c.id}`} className="block rounded-lg px-2 py-2 hover:bg-white/5">
                <p className="text-sm text-white">{c.name}</p><p className="text-xs text-slate-500">{c.email}</p>
              </Link>
            ))}
            {!customers.data?.length && <p className="text-xs text-slate-500">None</p>}
          </Card>
          <Card>
            <CardHeader title="Tickets" action={<Ticket className="h-4 w-4 text-slate-500" />} />
            {(tickets.data ?? []).map((t) => (
              <Link key={t.id} href={`/tickets?t=${t.id}`} className="flex items-center gap-2 rounded-lg px-2 py-2 hover:bg-white/5">
                <span className="font-mono text-xs text-electric-400">{t.ticket_number}</span>
                <span className="flex-1 truncate text-sm text-slate-200">{t.title}</span>
                <StatusBadge status={t.status} />
              </Link>
            ))}
            {!tickets.data?.length && <p className="text-xs text-slate-500">None</p>}
          </Card>
          <Card>
            <CardHeader title="Conversations" action={<MessagesSquare className="h-4 w-4 text-slate-500" />} />
            {(convos.data ?? []).map((c) => (
              <Link key={c.id} href={`/inbox?c=${c.id}`} className="flex items-center gap-2 rounded-lg px-2 py-2 hover:bg-white/5">
                <span className="flex-1 truncate text-sm text-slate-200">{(c.customers as unknown as { name: string } | null)?.name}: {c.subject}</span>
                <StatusBadge status={c.status} />
              </Link>
            ))}
            {!convos.data?.length && <p className="text-xs text-slate-500">None</p>}
          </Card>
          <Card>
            <CardHeader title="Knowledge base" action={<BookOpen className="h-4 w-4 text-slate-500" />} />
            {(kb.data ?? []).map((a) => (
              <Link key={a.id} href={`/knowledge?q=${encodeURIComponent(term)}`} className="block rounded-lg px-2 py-2 hover:bg-white/5">
                <p className="text-sm text-slate-200">{a.title}</p><p className="text-xs text-slate-500">{a.category}</p>
              </Link>
            ))}
            {!kb.data?.length && <p className="text-xs text-slate-500">None</p>}
          </Card>
        </div>
      )}
    </div>
  );
}
