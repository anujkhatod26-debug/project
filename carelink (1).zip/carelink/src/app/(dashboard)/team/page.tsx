import { getSession } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/misc";
import { InviteDialog, TeamTable } from "@/components/team/team-table";
import type { TeamMember } from "@/types";

export default async function TeamPage() {
  const { supabase, profile } = await getSession();
  const [{ data: members }, { data: convos }] = await Promise.all([
    supabase.from("team_members").select("*").order("created_at"),
    supabase.from("conversations").select("assigned_to").in("status", ["open", "pending", "escalated"]).not("assigned_to", "is", null).limit(10000),
  ]);
  const load: Record<string, number> = {};
  for (const c of convos ?? []) load[c.assigned_to!] = (load[c.assigned_to!] ?? 0) + 1;
  const isAdmin = profile.role === "admin";

  return (
    <div>
      <PageHeader
        title="Team Management"
        description="Human support staff. The Human Handoff Agent assigns escalations to the least busy person marked Available."
        actions={isAdmin ? <InviteDialog /> : undefined}
      />
      <Card className="p-0">
        <TeamTable members={(members ?? []) as TeamMember[]} me={profile.id} isAdmin={isAdmin} load={load} />
      </Card>
      <div className="mt-4 grid gap-3 text-xs text-slate-400 md:grid-cols-3">
        <div className="glass p-4"><p className="font-medium text-white">Admin</p><p className="mt-1">Full access: team, agents, settings, channels, knowledge base, delete records.</p></div>
        <div className="glass p-4"><p className="font-medium text-white">Support Manager</p><p className="mt-1">Manage tickets and knowledge base, delete tickets, view analytics.</p></div>
        <div className="glass p-4"><p className="font-medium text-white">Support Agent</p><p className="mt-1">Handle conversations and tickets, set own availability.</p></div>
      </div>
    </div>
  );
}
