import Link from "next/link";
import { Activity, CheckCircle2, Clock, Hourglass, MessagesSquare, Smile, Sparkles, Ticket, Bot } from "lucide-react";
import { getSession } from "@/lib/auth";
import { computeMetrics } from "@/lib/metrics";
import { Card, CardHeader } from "@/components/ui/card";
import { PageHeader, EmptyState, Avatar } from "@/components/ui/misc";
import { StatCard } from "@/components/dashboard/stat-card";
import { ActivityChart, AgentPerformanceChart, StatusDonut } from "@/components/dashboard/charts";
import { LoadDemoButton } from "@/components/dashboard/demo-button";
import { Badge, DemoBadge, PriorityBadge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AGENT_META, CHANNEL_META } from "@/lib/constants";
import { formatDuration, timeAgo, titleCase } from "@/lib/utils";
import type { AgentKey, Channel } from "@/types";

export default async function OverviewPage() {
  const { supabase, profile } = await getSession();
  const to = new Date();
  const from = new Date(to.getTime() - 13 * 86400000);
  from.setHours(0, 0, 0, 0);

  const [metrics, recentConvos, recentTickets, team] = await Promise.all([
    computeMetrics(supabase, profile.organization_id, from, to),
    supabase
      .from("conversations")
      .select("id, subject, status, priority, channel, current_agent, last_message_at, is_demo, customers(name)")
      .order("last_message_at", { ascending: false })
      .limit(6),
    supabase
      .from("tickets")
      .select("id, ticket_number, title, status, priority, updated_at, is_demo")
      .order("updated_at", { ascending: false })
      .limit(6),
    supabase.from("team_members").select("id, name, role, availability, invite_status").eq("invite_status", "active").order("name"),
  ]);

  const t = metrics.totals;
  const pct = (x: number | null) => (x == null ? "—" : `${Math.round(x * 100)}%`);
  const isEmpty = t.conversations === 0 && (recentConvos.data ?? []).length === 0;

  return (
    <div>
      <PageHeader
        title={`Welcome back, ${profile.full_name.split(" ")[0] || "there"}`}
        description="Live view of conversations, tickets and AI agent activity over the last 14 days."
        actions={
          <>
            <Button asChild variant="secondary">
              <Link href="/analytics">Full analytics</Link>
            </Button>
            <Button asChild>
              <Link href="/workflow"><Sparkles /> Test the AI agents</Link>
            </Button>
          </>
        }
      />

      {isEmpty && (
        <Card className="mb-6">
          <EmptyState
            icon={Sparkles}
            title="Your workspace is ready"
            description="Send a message in Agent Workflow to see the agents in action, or load demo data to explore every screen with sample records."
            action={
              <div className="flex gap-2">
                {profile.role === "admin" && <LoadDemoButton />}
                <Button asChild variant="secondary"><Link href="/workflow">Open live chat</Link></Button>
              </div>
            }
          />
        </Card>
      )}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
        <StatCard index={0} label="Total conversations" value={String(t.conversations)} icon={MessagesSquare} sub="Last 14 days" />
        <StatCard index={1} label="Open tickets" value={String(t.openTickets + t.inProgressTickets + t.escalatedTickets)} icon={Ticket} accent="#60a5fa" sub={`${t.escalatedTickets} escalated`} />
        <StatCard index={2} label="Resolved tickets" value={String(t.resolvedTickets)} icon={CheckCircle2} accent="#10b981" />
        <StatCard index={3} label="Pending tickets" value={String(t.pendingTickets)} icon={Hourglass} accent="#f59e0b" />
        <StatCard index={4} label="AI resolution rate" value={pct(t.aiResolutionRate)} icon={Bot} accent="#8b5cf6" sub={`${t.aiResolved} resolved by AI`} />
        <StatCard index={5} label="Avg response time" value={formatDuration(t.avgFirstResponseMs)} icon={Clock} accent="#22d3ee" sub="First reply" />
        <StatCard index={6} label="Customer satisfaction" value={t.csat == null ? "—" : `${t.csat.toFixed(1)}/5`} icon={Smile} accent="#f472b6" sub={`${t.csatResponses} ratings`} />
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader title="Conversation activity" description="Daily conversations, AI resolutions and escalations" action={metrics.hasDemo ? <DemoBadge /> : null} />
          <ActivityChart data={metrics.daily} />
        </Card>
        <Card>
          <CardHeader title="Ticket status distribution" description="Tickets created in the last 14 days" />
          <StatusDonut data={metrics.ticketStatus} />
        </Card>
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader title="AI agent performance" description="Tasks handled and success rate, from agent execution logs" action={<Link href="/agents" className="text-xs text-electric-400 hover:underline">All agents →</Link>} />
          <AgentPerformanceChart data={metrics.agents} />
        </Card>
        <Card>
          <CardHeader title="Agent availability" description="Human support team" action={<Link href="/team" className="text-xs text-electric-400 hover:underline">Manage →</Link>} />
          <ul className="space-y-2.5">
            {(team.data ?? []).length === 0 && <li className="text-xs text-slate-500">No team members yet.</li>}
            {(team.data ?? []).map((m) => (
              <li key={m.id} className="flex items-center gap-3">
                <div className="relative">
                  <Avatar name={m.name} />
                  <span
                    className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full ring-2 ring-navy-900 ${
                      m.availability === "available" ? "bg-emerald-400" : m.availability === "busy" ? "bg-amber-400" : "bg-slate-500"
                    }`}
                  />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-white">{m.name}</p>
                  <p className="text-[11px] text-slate-500">{titleCase(m.role)}</p>
                </div>
                <StatusBadge status={m.availability} />
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader title="Recent conversations" action={<Link href="/inbox" className="text-xs text-electric-400 hover:underline">Open inbox →</Link>} />
          {(recentConvos.data ?? []).length === 0 ? (
            <EmptyState icon={MessagesSquare} title="No conversations yet" />
          ) : (
            <ul className="divide-y divide-white/5">
              {(recentConvos.data ?? []).map((c) => (
                <li key={c.id}>
                  <Link href={`/inbox?c=${c.id}`} className="flex items-center gap-3 py-3 hover:opacity-90">
                    <Avatar name={(c.customers as unknown as { name: string } | null)?.name} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="truncate text-sm font-medium text-white">{(c.customers as unknown as { name: string } | null)?.name ?? "Customer"}</p>
                        {c.is_demo && <DemoBadge />}
                      </div>
                      <p className="truncate text-xs text-slate-400">{c.subject ?? "New conversation"}</p>
                    </div>
                    <div className="hidden flex-col items-end gap-1 sm:flex">
                      <div className="flex gap-1">
                        <Badge tone="slate">{CHANNEL_META[c.channel as Channel]?.label}</Badge>
                        <StatusBadge status={c.status} />
                      </div>
                      <span className="text-[10px] text-slate-500">
                        {c.current_agent ? AGENT_META[c.current_agent as AgentKey]?.short + " · " : ""}
                        {timeAgo(c.last_message_at)}
                      </span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card>
          <CardHeader title="Recent ticket activity" action={<Link href="/tickets" className="text-xs text-electric-400 hover:underline">All tickets →</Link>} />
          {(recentTickets.data ?? []).length === 0 ? (
            <EmptyState icon={Activity} title="No tickets yet" />
          ) : (
            <ul className="divide-y divide-white/5">
              {(recentTickets.data ?? []).map((tk) => (
                <li key={tk.id}>
                  <Link href={`/tickets?t=${tk.id}`} className="flex items-center gap-3 py-3 hover:opacity-90">
                    <span className="w-16 shrink-0 font-mono text-xs text-electric-400">{tk.ticket_number}</span>
                    <p className="min-w-0 flex-1 truncate text-sm text-slate-200">{tk.title}</p>
                    {tk.is_demo && <DemoBadge />}
                    <PriorityBadge priority={tk.priority} />
                    <StatusBadge status={tk.status} />
                    <span className="hidden w-14 text-right text-[10px] text-slate-500 sm:block">{timeAgo(tk.updated_at)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
