import { getSession } from "@/lib/auth";
import { PageHeader } from "@/components/ui/misc";
import { LiveChat } from "@/components/chat/live-chat";
import { isAIConfigured } from "@/lib/agents/claude";
import type { Message, Priority } from "@/types";

export default async function WorkflowPage({ searchParams }: { searchParams: Promise<{ c?: string }> }) {
  const { c } = await searchParams;
  const { supabase } = await getSession();

  const { data: team } = await supabase.from("team_members").select("id, name").eq("invite_status", "active").order("name");

  let initialConversation = null;
  let initialMessages: Message[] = [];
  if (c) {
    const { data: convo } = await supabase
      .from("conversations")
      .select("id, status, priority, sentiment, intent, subject, customers(name, email)")
      .eq("id", c)
      .maybeSingle();
    if (convo) {
      const cust = convo.customers as unknown as { name: string; email: string | null } | null;
      initialConversation = {
        id: convo.id,
        status: convo.status,
        customerName: cust?.name ?? "Customer",
        customerEmail: cust?.email ?? null,
        priority: convo.priority as Priority,
        sentiment: convo.sentiment,
        intent: convo.intent,
        subject: convo.subject,
      };
      const { data } = await supabase.from("messages").select("*").eq("conversation_id", c).order("created_at");
      initialMessages = (data ?? []) as Message[];
    }
  }

  return (
    <div>
      <PageHeader
        title="Agent Workflow"
        description="Live AI chat with a step-by-step view of how the seven agents understand, route, answer and escalate each message."
      />
      <LiveChat key={c ?? "new"} team={team ?? []} initialConversation={initialConversation} initialMessages={initialMessages} aiConfigured={isAIConfigured()} />
    </div>
  );
}
