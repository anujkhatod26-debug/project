import Link from "next/link";
import { getSession } from "@/lib/auth";
import { Card, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/misc";
import { Button } from "@/components/ui/button";
import {
  AiConfigForm,
  ChannelCard,
  CopyField,
  NotificationsForm,
  ProfileForm,
  SelectTab,
  ThemeForm,
} from "@/components/settings/settings-forms";
import { ClearDemoButton, LoadDemoButton } from "@/components/dashboard/demo-button";
import { MODELS, isAIConfigured } from "@/lib/agents/claude";
import { hasServiceRole } from "@/lib/supabase/admin";
import { CHANNEL_REQUIREMENTS } from "@/lib/channels/requirements";
import { CHANNEL_META } from "@/lib/constants";
import { cn } from "@/lib/utils";
import type { Channel, ChannelIntegration, OrgSettings } from "@/types";

const TABS = [
  { id: "profile", label: "Profile" },
  { id: "team", label: "Team settings" },
  { id: "ai", label: "AI configuration" },
  { id: "api", label: "API configuration" },
  { id: "notifications", label: "Notifications" },
  { id: "channels", label: "Channel integrations" },
  { id: "theme", label: "Theme" },
  { id: "demo", label: "Demo mode" },
];

export default async function SettingsPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const { tab = "profile" } = await searchParams;
  const { supabase, profile, org } = await getSession();
  const isAdmin = profile.role === "admin";
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

  const { data: channels } = tab === "channels" ? await supabase.from("channel_integrations").select("*") : { data: [] };
  const { count: demoCount } = tab === "demo" ? await supabase.from("conversations").select("id", { count: "exact", head: true }).eq("is_demo", true) : { count: 0 };

  const widgetUrl = `${appUrl}/widget/${org.slug}`;
  const embed = `<iframe src="${widgetUrl}" style="position:fixed;bottom:20px;right:20px;width:380px;height:600px;border:0;border-radius:16px;z-index:9999" title="Support chat"></iframe>`;

  return (
    <div>
      <PageHeader title="Settings" description="Your profile, workspace, AI behaviour and channel connections." />
      <div className="mb-4"><SelectTab tabs={TABS} active={tab} /></div>
      <div className="grid gap-6 md:grid-cols-[200px_1fr]">
        <nav className="hidden space-y-1 md:block">
          {TABS.map((t) => (
            <Link key={t.id} href={`/settings?tab=${t.id}`} className={cn("block rounded-xl px-3 py-2 text-sm", tab === t.id ? "bg-electric-500/15 text-white" : "text-slate-400 hover:bg-white/5 hover:text-white")}>
              {t.label}
            </Link>
          ))}
        </nav>
        <div className="min-w-0 space-y-6">
          {tab === "profile" && <ProfileForm profile={profile} />}

          {tab === "team" && (
            <Card>
              <CardHeader title="Team settings" description="Invite people, change roles and availability." />
              <p className="text-sm text-slate-400">Workspace: <span className="text-white">{org.name}</span> · Slug <code className="text-electric-400">{org.slug}</code></p>
              <Button asChild className="mt-4"><Link href="/team">Open Team Management</Link></Button>
            </Card>
          )}

          {tab === "ai" && (
            <AiConfigForm name={org.name} settings={org.settings as OrgSettings} isAdmin={isAdmin} models={{ main: MODELS.main(), fast: MODELS.fast() }} aiConfigured={isAIConfigured()} />
          )}

          {tab === "api" && (
            <>
              <Card>
                <CardHeader title="API configuration" description="Keys live only in server environment variables and are never sent to the browser." />
                <ul className="space-y-2 text-sm">
                  {[
                    ["NEXT_PUBLIC_SUPABASE_URL", Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL), "Supabase project URL"],
                    ["NEXT_PUBLIC_SUPABASE_ANON_KEY", Boolean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY), "Public anon key (RLS protects data)"],
                    ["SUPABASE_SERVICE_ROLE_KEY", hasServiceRole(), "Server only: public chat widget and webhooks"],
                    ["ANTHROPIC_API_KEY", isAIConfigured(), "Server only: Claude agents"],
                  ].map(([k, ok, d]) => (
                    <li key={String(k)} className="flex items-center justify-between rounded-xl bg-white/[0.03] px-4 py-3">
                      <div><code className="text-slate-200">{k}</code><p className="text-xs text-slate-500">{d}</p></div>
                      <span className={ok ? "text-emerald-300" : "text-rose-300"}>{ok ? "configured" : "missing"}</span>
                    </li>
                  ))}
                </ul>
              </Card>
              <Card>
                <CardHeader title="Website chat widget" description="Your public support chat. Put this on any website; messages appear in the Omnichannel Inbox." />
                <div className="space-y-3">
                  <CopyField label="Chat page URL" value={widgetUrl} />
                  <CopyField label="Embed code" value={embed} />
                  <Button asChild variant="secondary"><a href={`/widget/${org.slug}`} target="_blank" rel="noreferrer">Open widget</a></Button>
                </div>
              </Card>
            </>
          )}

          {tab === "notifications" && <NotificationsForm prefs={profile.notification_prefs} />}

          {tab === "channels" && (
            <div className="grid gap-4 xl:grid-cols-2">
              {(Object.keys(CHANNEL_META) as Channel[]).map((ch) => {
                const row = (channels as ChannelIntegration[]).find((c) => c.channel === ch);
                const req = CHANNEL_REQUIREMENTS[ch];
                return (
                  <ChannelCard
                    key={ch}
                    channel={ch}
                    label={CHANNEL_META[ch].label}
                    status={row?.status ?? "not_configured"}
                    enabled={row?.enabled ?? false}
                    config={row?.config ?? {}}
                    fields={req.fields}
                    envVars={req.env.map((name) => ({ name, set: Boolean(process.env[name]) }))}
                    webhookUrl={req.webhook ? `${appUrl}/api/webhooks/${ch}` : null}
                    isAdmin={isAdmin}
                    docs={req.docs}
                  />
                );
              })}
            </div>
          )}

          {tab === "theme" && <ThemeForm theme={profile.theme} />}

          {tab === "demo" && (
            <Card>
              <CardHeader title="Demo mode" description="Sample customers, conversations, tickets, team members, knowledge articles and agent logs. Every demo record is tagged Demo." />
              <p className="mb-4 text-sm text-slate-400">{demoCount ? `Demo data is loaded (${demoCount} demo conversations).` : "No demo data is loaded."} Live chats are always processed by the real AI agents.</p>
              {isAdmin ? (
                <div className="flex flex-wrap gap-2">
                  <LoadDemoButton label={demoCount ? "Reload demo data" : "Load demo data"} />
                  {Boolean(demoCount) && <ClearDemoButton />}
                </div>
              ) : (
                <p className="text-xs text-slate-500">Only admins can load or remove demo data.</p>
              )}
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
