import { BookOpen } from "lucide-react";
import { getSession, canManage } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { ArticleDialog } from "@/components/knowledge/article-dialog";
import { UploadDialog } from "@/components/knowledge/upload-dialog";
import { ArticleList } from "@/components/knowledge/article-list";
import { KbFilters } from "@/components/knowledge/kb-filters";
import { getRetriever } from "@/lib/kb/retriever";
import type { KnowledgeArticle } from "@/types";

export default async function KnowledgePage({ searchParams }: { searchParams: Promise<{ q?: string; category?: string; type?: string }> }) {
  const sp = await searchParams;
  const { supabase, profile } = await getSession();
  const editable = canManage(profile.role);

  const { data: cats } = await supabase.from("knowledge_articles").select("category").limit(2000);
  const categories = Array.from(new Set((cats ?? []).map((c) => c.category))).sort();

  let articles: KnowledgeArticle[] = [];
  let searchNote: string | null = null;
  if (sp.q) {
    // Use the exact retrieval the agents use, then load full rows.
    const hits = await getRetriever(supabase).search(profile.organization_id, sp.q, 25);
    if (hits.length) {
      const { data } = await supabase.from("knowledge_articles").select("*").in("id", hits.map((h) => h.id));
      const order = new Map(hits.map((h, i) => [h.id, i]));
      articles = ((data ?? []) as KnowledgeArticle[]).sort((a, b) => order.get(a.id)! - order.get(b.id)!);
    }
    searchNote = `${articles.length} result(s) ranked by relevance`;
  } else {
    const { data } = await supabase.from("knowledge_articles").select("*").order("updated_at", { ascending: false }).limit(300);
    articles = (data ?? []) as KnowledgeArticle[];
  }
  if (sp.category) articles = articles.filter((a) => a.category === sp.category);
  if (sp.type) articles = articles.filter((a) => a.type === sp.type);

  return (
    <div>
      <PageHeader
        title="Knowledge Base"
        description="FAQs and documents the AI agents search before answering. Agents only state policies that are written here."
        actions={editable ? <><UploadDialog /><ArticleDialog /></> : undefined}
      />
      <Card className="p-0">
        <div className="border-b border-white/5 p-4">
          <KbFilters categories={categories} />
          {searchNote && <p className="mt-2 text-xs text-slate-500">{searchNote}</p>}
        </div>
        {articles.length === 0 ? (
          <EmptyState
            icon={BookOpen}
            title={sp.q ? "No matching articles" : "Your knowledge base is empty"}
            description={sp.q ? "Agents would answer this without knowledge-base support, so they'd avoid stating specific policies." : "Add FAQs or upload policy documents so agents can answer accurately."}
          />
        ) : (
          <ArticleList articles={articles} canEdit={editable} />
        )}
      </Card>
      {!editable && <p className="mt-3 text-xs text-slate-500">Only admins and support managers can edit the knowledge base.</p>}
    </div>
  );
}
