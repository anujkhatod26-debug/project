import { Bot, Clock, MessagesSquare, Smile, Timer, UserRound } from "lucide-react";
import { getSession } from "@/lib/auth";
import { computeMetrics, parseRange } from "@/lib/metrics";
import { Card, CardHeader } from "@/components/ui/card";
import { PageHeader, Table, Td, Th } from "@/components/ui/misc";
import { DemoBadge } from "@/components/ui/badge";
import { StatCard } from "@/components/dashboard/stat-card";
import { AgentPerformanceChart, HorizontalBars, StatusDonut, TrendLineChart } from "@/components/dashboard/charts";
import { RangePicker } from "@/components/analytics/range-picker";
import { AGENT_META, CHANNEL_META } from "@/lib/constants";
import { formatDate, formatDuration, titleCase } from "@/lib/utils";
import type { Channel } from "@/types";

export default async function AnalyticsPage({ searchParams }: { searchParams: Promise<{ from?: string; to?: string; range?: string }> }) {
  const sp = await searchParams;
  const { supabase, profile } = await getSession();
  const { from, to } = parseRange(sp);
  const m = await computeMetrics(supabase, profile.organization_id, from, to);

  const { data: humanTickets } = await supabase
    .from("tickets")
    .select("status, assigned_to, team_members(name)")
    .gte("created_at", from.toISOString())
    .lte("created_at", to.toISOString())
    .not("assigned_to", "is", null)
    .limit(10000);
  const humans = new Map<string, { name: string; total: number; resolved: number }>();
  for (const t of humanTickets ?? []) {
    const name = (t.team_members as unknown as { name: string } | null)?.name ?? "Unknown";
    const h = humans.get(t.assigned_to!) ?? { name, total: 0, resolved: 0 };
    h.total++;
    if (t.status === "resolved") h.resolved++;
    humans.set(t.assigned_to!, h);
  }

  const t = m.totals;
  const pct = (x: number | null) => (x == null ? "—" : `${Math.round(x * 100)}%`);

  return (
    <div>
      <PageHeader
        title="Analytics"
        description={`Calculated from your database records, ${formatDate(m.range.from, false)} to ${formatDate(m.range.to, false)}.`}
        actions={<RangePicker />}
      />
      {m.hasDemo && <p className="mb-4 flex items-center gap-2 text-xs text-slate-400"><DemoBadge /> This range includes demo records.</p>}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <StatCard index={0} label="Total conversations" value={String(t.conversations)} icon={MessagesSquare} />
        <StatCard index={1} label="AI-resolved" value={String(t.aiResolved)} sub={pct(t.aiResolutionRate)} icon={Bot} accent="#8b5cf6" />
        <StatCard index={2} label="Human-escalated" value={String(t.escalated)} sub={t.conversations ? pct(t.escalated / t.conversations) : "—"} icon={UserRound} accent="#fb7185" />
        <StatCard index={3} label="Avg first response" value={formatDuration(t.avgFirstResponseMs)} icon={Clock} accent="#22d3ee" />
        <StatCard index={4} label="Avg resolution time" value={formatDuration(t.avgResolutionMs)} icon={Timer} accent="#f59e0b" />
        <StatCard index={5} label="Customer satisfaction" value={t.csat == null ? "—" : `${t.csat.toFixed(2)}/5`} sub={`${t.csatResponses} ratings`} icon={Smile} accent="#f472b6" />
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader title="Daily conversation trend" />
          <TrendLineChart data={m.daily} xKey="date" />
        </Card>
        <Card>
          <CardHeader title="Weekly conversation trend" description="Weeks start on Monday" />
          <TrendLineChart data={m.weekly} xKey="week" />
        </Card>
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Card>
          <CardHeader title="Most common customer issues" description="By AI-detected category" />
          <HorizontalBars data={m.topIssues.map((i) => ({ label: titleCase(i.category), value: i.count }))} />
        </Card>
        <Card>
          <CardHeader title="Conversations by channel" />
          <HorizontalBars color="#8b5cf6" data={m.channels.map((c) => ({ label: CHANNEL_META[c.channel as Channel]?.label ?? c.channel, value: c.count }))} />
        </Card>
        <Card>
          <CardHeader title="Ticket status" />
          <StatusDonut data={m.ticketStatus} />
        </Card>
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader title="AI agent performance" />
          <AgentPerformanceChart data={m.agents} />
          <div className="mt-4">
            <Table>
              <thead>
                <tr><Th>Agent</Th><Th>Tasks</Th><Th>Success rate</Th><Th>Avg confidence</Th><Th>Avg processing time</Th></tr>
              </thead>
              <tbody>
                {m.agents.map((a) => (
                  <tr key={a.key}>
                    <Td><span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ background: AGENT_META[a.key].color }} />{a.name}</span></Td>
                    <Td>{a.tasks}</Td>
                    <Td>{pct(a.successRate)}</Td>
                    <Td>{pct(a.avgConfidence)}</Td>
                    <Td>{formatDuration(a.avgLatencyMs)}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </Card>
        <Card>
          <CardHeader title="Human agent performance" description="Tickets assigned in this period" />
          {humans.size === 0 ? (
            <p className="py-10 text-center text-xs text-slate-500">No assigned tickets in this period.</p>
          ) : (
            <ul className="space-y-3">
              {Array.from(humans.values()).sort((a, b) => b.total - a.total).map((h) => (
                <li key={h.name}>
                  <div className="flex justify-between text-sm"><span className="text-slate-200">{h.name}</span><span className="text-slate-400">{h.resolved}/{h.total} resolved</span></div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-electric-500" style={{ width: `${(h.resolved / h.total) * 100}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
