import Link from "next/link";
import { Inbox, MessagesSquare } from "lucide-react";
import { getSession } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { Avatar, EmptyState, PageHeader } from "@/components/ui/misc";
import { Badge, DemoBadge, PriorityBadge } from "@/components/ui/badge";
import { InboxFilters } from "@/components/inbox/inbox-filters";
import { ConversationView } from "@/components/inbox/conversation-view";
import { CHANNEL_META } from "@/lib/constants";
import { cn, timeAgo } from "@/lib/utils";
import type { Channel, ChannelIntegration, Conversation, Message } from "@/types";

type SP = { c?: string; q?: string; status?: string; priority?: string; channel?: string };

export default async function InboxPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const { supabase } = await getSession();

  let q = supabase
    .from("conversations")
    .select("id, subject, status, priority, channel, last_message_at, is_demo, customer_id, customers!inner(name, email)")
    .order("last_message_at", { ascending: false })
    .limit(150);
  if (sp.status) q = q.eq("status", sp.status);
  if (sp.priority) q = q.eq("priority", sp.priority);
  if (sp.channel) q = q.eq("channel", sp.channel);
  if (sp.q) {
    const term = sp.q.replace(/[,%()]/g, "");
    q = q.or(`name.ilike.%${term}%,email.ilike.%${term}%`, { referencedTable: "customers" });
  }

  // Also search inside subjects via a second query and merge
  const [listRes, subjectRes, channelsRes, teamRes] = await Promise.all([
    q,
    sp.q
      ? supabase
          .from("conversations")
          .select("id, subject, status, priority, channel, last_message_at, is_demo, customer_id, customers(name, email)")
          .ilike("subject", `%${sp.q.replace(/[,%()]/g, "")}%`)
          .limit(50)
      : Promise.resolve({ data: [] as never[] }),
    supabase.from("channel_integrations").select("*"),
    supabase.from("team_members").select("id, name").eq("invite_status", "active").order("name"),
  ]);

  const map = new Map<string, NonNullable<typeof listRes.data>[number]>();
  for (const r of [...(listRes.data ?? []), ...((subjectRes.data ?? []) as typeof listRes.data & object)]) map.set(r.id, r);
  const list = Array.from(map.values()).sort((a, b) => b.last_message_at.localeCompare(a.last_message_at));

  const selectedId = sp.c ?? list[0]?.id;
  let selected: { conversation: Conversation; messages: Message[]; tickets: { id: string; ticket_number: string; status: string; title: string }[] } | null = null;
  if (selectedId) {
    const [{ data: convo }, { data: messages }, { data: tickets }] = await Promise.all([
      supabase.from("conversations").select("*, customers(id, name, email)").eq("id", selectedId).maybeSingle(),
      supabase.from("messages").select("*").eq("conversation_id", selectedId).order("created_at"),
      supabase.from("tickets").select("id, ticket_number, status, title").eq("conversation_id", selectedId),
    ]);
    if (convo) selected = { conversation: convo as Conversation, messages: (messages ?? []) as Message[], tickets: tickets ?? [] };
  }

  const channels = (channelsRes.data ?? []) as ChannelIntegration[];
  const qs = (id: string) => {
    const n = new URLSearchParams(Object.entries(sp).filter(([k, v]) => k !== "c" && v) as [string, string][]);
    n.set("c", id);
    return `/inbox?${n.toString()}`;
  };

  return (
    <div>
      <PageHeader title="Omnichannel Inbox" description="Every customer conversation in one place. Website chat is live; other channels connect from Settings." />

      <div className="mb-4 flex flex-wrap gap-2">
        {(Object.keys(CHANNEL_META) as Channel[]).map((ch) => {
          const integ = channels.find((x) => x.channel === ch);
          const connected = integ?.status === "connected" && integ.enabled;
          return (
            <Link key={ch} href={ch === "web_chat" ? "/settings?tab=channels" : "/settings?tab=channels"} className="glass flex items-center gap-2 px-3 py-2 text-xs">
              <span className="h-2 w-2 rounded-full" style={{ background: connected ? "#34d399" : "#475569" }} />
              <span className="text-slate-200">{CHANNEL_META[ch].label}</span>
              <span className="text-slate-500">{connected ? "Connected" : "Not connected"}</span>
            </Link>
          );
        })}
      </div>

      <Card className="flex h-[calc(100vh-15rem)] min-h-[600px] overflow-hidden p-0">
        <div className={cn("w-full flex-col border-r border-white/5 md:flex md:w-80 md:shrink-0", sp.c ? "hidden" : "flex")}>
          <div className="border-b border-white/5 p-3"><InboxFilters /></div>
          <div className="flex-1 overflow-y-auto scrollbar-thin">
            {list.length === 0 ? (
              <EmptyState icon={Inbox} title="No conversations" description="Try clearing filters, or start one from Agent Workflow." />
            ) : (
              list.map((c) => {
                const cust = c.customers as unknown as { name: string } | null;
                return (
                  <Link
                    key={c.id}
                    href={qs(c.id)}
                    scroll={false}
                    className={cn("flex gap-3 border-b border-white/[0.04] px-3 py-3 transition hover:bg-white/[0.03]", c.id === selectedId && "bg-electric-500/[0.08]")}
                  >
                    <Avatar name={cust?.name} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="truncate text-sm font-medium text-white">{cust?.name ?? "Customer"}</p>
                        <span className="ml-auto shrink-0 text-[10px] text-slate-500">{timeAgo(c.last_message_at)}</span>
                      </div>
                      <p className="truncate text-xs text-slate-400">{c.subject ?? "New conversation"}</p>
                      <div className="mt-1.5 flex flex-wrap items-center gap-1">
                        <span className="h-1.5 w-1.5 rounded-full" style={{ background: CHANNEL_META[c.channel as Channel]?.color }} />
                        <span className="text-[10px] text-slate-500">{CHANNEL_META[c.channel as Channel]?.label}</span>
                        <PriorityBadge priority={c.priority} />
                        {c.status === "escalated" && <Badge tone="red">Escalated</Badge>}
                        {c.status === "resolved" && <Badge tone="green">Resolved</Badge>}
                        {c.is_demo && <DemoBadge />}
                      </div>
                    </div>
                  </Link>
                );
              })
            )}
          </div>
        </div>
        <div className={cn("min-w-0 flex-1 md:block", sp.c ? "block" : "hidden")}>
          {selected ? (
            <ConversationView
              key={selected.conversation.id}
              conversation={selected.conversation as Conversation & { customers: { id: string; name: string; email: string | null } | null }}
              messages={selected.messages}
              team={teamRes.data ?? []}
              tickets={selected.tickets}
            />
          ) : (
            <EmptyState icon={MessagesSquare} title="Select a conversation" />
          )}
        </div>
      </Card>
    </div>
  );
}
