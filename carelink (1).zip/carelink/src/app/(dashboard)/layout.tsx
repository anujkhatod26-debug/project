import { getSession } from "@/lib/auth";
import { DashboardShell } from "@/components/layout/shell";
import { isAIConfigured } from "@/lib/agents/claude";
import type { NotificationItem } from "@/components/layout/topbar";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { supabase, profile, org } = await getSession();

  const [escalations, newTickets, inboxCount, ticketCount, demo] = await Promise.all([
    supabase
      .from("conversations")
      .select("id, subject, updated_at, customers(name)")
      .eq("status", "escalated")
      .order("updated_at", { ascending: false })
      .limit(5),
    supabase.from("tickets").select("id, title, ticket_number, created_at").order("created_at", { ascending: false }).limit(4),
    supabase.from("conversations").select("id", { count: "exact", head: true }).in("status", ["open", "escalated"]),
    supabase.from("tickets").select("id", { count: "exact", head: true }).in("status", ["open", "escalated"]),
    supabase.from("conversations").select("id", { count: "exact", head: true }).eq("is_demo", true),
  ]);

  const notifications: NotificationItem[] = [
    ...(escalations.data ?? []).map((c) => ({
      id: `e-${c.id}`,
      kind: "escalation" as const,
      title: `Escalated: ${(c.customers as unknown as { name: string } | null)?.name ?? "Customer"} – ${c.subject ?? "needs a human"}`,
      href: `/inbox?c=${c.id}`,
      at: c.updated_at as string,
    })),
    ...(newTickets.data ?? []).map((t) => ({
      id: `t-${t.id}`,
      kind: "ticket" as const,
      title: `${t.ticket_number}: ${t.title}`,
      href: `/tickets?t=${t.id}`,
      at: t.created_at as string,
    })),
  ]
    .sort((a, b) => b.at.localeCompare(a.at))
    .slice(0, 8);

  return (
    <DashboardShell
      profile={profile}
      orgName={org?.name ?? ""}
      orgId={profile.organization_id}
      notifications={notifications}
      counts={{ inbox: inboxCount.count ?? 0, tickets: ticketCount.count ?? 0 }}
      hasDemo={(demo.count ?? 0) > 0}
      aiConfigured={isAIConfigured()}
      theme={profile.theme}
    >
      {children}
    </DashboardShell>
  );
}
