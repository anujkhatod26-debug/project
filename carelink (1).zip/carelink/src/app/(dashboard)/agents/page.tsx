import Link from "next/link";
import { Brain, GitBranch, HeartPulse, Headphones, Receipt, UserRound, Wrench, ScrollText } from "lucide-react";
import { getSession } from "@/lib/auth";
import { computeMetrics } from "@/lib/metrics";
import { Card } from "@/components/ui/card";
import { EmptyState, PageHeader, Table, Td, Th } from "@/components/ui/misc";
import { DemoBadge, StatusBadge } from "@/components/ui/badge";
import { AgentToggle } from "@/components/agents/agent-toggle";
import { LogFilter } from "@/components/agents/log-filter";
import { AGENT_META, AGENT_ORDER } from "@/lib/constants";
import { formatDate, formatDuration, timeAgo } from "@/lib/utils";
import type { AgentKey, AgentLog, AiAgent } from "@/types";

const ICON: Record<AgentKey, React.ElementType> = {
  understanding: Brain,
  sentiment: HeartPulse,
  routing: GitBranch,
  support: Headphones,
  technical: Wrench,
  billing: Receipt,
  handoff: UserRound,
};

export default async function AgentsPage({ searchParams }: { searchParams: Promise<{ agent?: string; status?: string }> }) {
  const sp = await searchParams;
  const { supabase, profile } = await getSession();
  const to = new Date();
  const from = new Date(to.getTime() - 90 * 86400000);

  let logsQ = supabase.from("agent_logs").select("*").order("created_at", { ascending: false }).limit(60);
  if (sp.agent) logsQ = logsQ.eq("agent_key", sp.agent);
  if (sp.status) logsQ = logsQ.eq("status", sp.status);

  const [{ data: agents }, metrics, { data: logs }] = await Promise.all([
    supabase.from("ai_agents").select("*"),
    computeMetrics(supabase, profile.organization_id, from, to),
    logsQ,
  ]);

  const byKey = new Map((agents as AiAgent[] | null ?? []).map((a) => [a.key, a]));
  const stats = new Map(metrics.agents.map((a) => [a.key, a]));
  const isAdmin = profile.role === "admin";

  return (
    <div>
      <PageHeader
        title="AI Agents"
        description="Seven specialised agents powered by Claude. Statistics come from the last 90 days of execution logs."
      />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {AGENT_ORDER.map((key) => {
          const a = byKey.get(key);
          const s = stats.get(key);
          const Icon = ICON[key];
          const meta = AGENT_META[key];
          return (
            <Card key={key} className="relative overflow-hidden">
              <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-20 blur-3xl" style={{ background: meta.color }} />
              <div className="flex items-start gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl ring-1 ring-white/10" style={{ background: `${meta.color}1f` }}>
                  <Icon className="h-5 w-5" style={{ color: meta.color }} />
                </div>
                <div className="flex-1">
                  <p className="font-display font-semibold text-white">{a?.name ?? meta.name}</p>
                  <p className="mt-0.5 text-xs text-slate-400">{a?.description}</p>
                </div>
                <AgentToggle agentKey={key} enabled={a?.enabled ?? true} canEdit={isAdmin} />
              </div>
              <div className="mt-4 flex items-center gap-2 text-xs">
                <span className={`h-2 w-2 rounded-full ${a?.enabled === false ? "bg-slate-500" : "bg-emerald-400"}`} />
                <span className="text-slate-300">{a?.enabled === false ? "Disabled" : "Active"}</span>
                <span className="ml-auto text-slate-500">Last run {s?.lastActive ? timeAgo(s.lastActive) : "never"}</span>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl bg-white/5 p-2.5">
                  <p className="font-display text-lg text-white">{s?.tasks ?? 0}</p>
                  <p className="text-[10px] text-slate-500">Tasks</p>
                </div>
                <div className="rounded-xl bg-white/5 p-2.5">
                  <p className="font-display text-lg text-white">{s?.successRate == null ? "—" : `${Math.round(s.successRate * 100)}%`}</p>
                  <p className="text-[10px] text-slate-500">Success</p>
                </div>
                <div className="rounded-xl bg-white/5 p-2.5">
                  <p className="font-display text-lg text-white">{formatDuration(s?.avgLatencyMs)}</p>
                  <p className="text-[10px] text-slate-500">Avg time</p>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <Card className="mt-6 p-0">
        <div className="flex flex-col gap-3 border-b border-white/5 p-5 sm:flex-row sm:items-center">
          <div className="mr-auto">
            <h3 className="font-display text-base font-semibold text-white">Agent execution logs</h3>
            <p className="text-xs text-slate-400">Every agent call, with status, confidence and latency. Latest 60 shown.</p>
          </div>
          <LogFilter />
        </div>
        {(logs ?? []).length === 0 ? (
          <EmptyState icon={ScrollText} title="No agent runs yet" description="Send a message in Agent Workflow to create the first logs." />
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Time</Th>
                <Th>Agent</Th>
                <Th>Step</Th>
                <Th>Status</Th>
                <Th>Confidence</Th>
                <Th>Latency</Th>
                <Th>Output / error</Th>
                <Th></Th>
              </tr>
            </thead>
            <tbody>
              {(logs as AgentLog[]).map((l) => (
                <tr key={l.id} className="hover:bg-white/[0.02]">
                  <Td className="whitespace-nowrap text-xs text-slate-400">{formatDate(l.created_at)}</Td>
                  <Td>
                    <span className="flex items-center gap-2 text-sm text-slate-200">
                      <span className="h-2 w-2 rounded-full" style={{ background: AGENT_META[l.agent_key]?.color }} />
                      {AGENT_META[l.agent_key]?.short ?? l.agent_key}
                      {l.is_demo && <DemoBadge />}
                    </span>
                  </Td>
                  <Td className="text-xs text-slate-400">{l.step}</Td>
                  <Td><StatusBadge status={l.status} /></Td>
                  <Td className="text-xs">{l.confidence == null ? "—" : `${Math.round(Number(l.confidence) * 100)}%`}</Td>
                  <Td className="text-xs">{formatDuration(l.latency_ms)}</Td>
                  <Td className="max-w-[340px]">
                    <p className="truncate font-mono text-[11px] text-slate-400" title={l.error ?? JSON.stringify(l.output)}>
                      {l.error ?? JSON.stringify(l.output)}
                    </p>
                  </Td>
                  <Td>{l.conversation_id && <Link href={`/inbox?c=${l.conversation_id}`} className="text-xs text-electric-400 hover:underline">View</Link>}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </div>
  );
}
