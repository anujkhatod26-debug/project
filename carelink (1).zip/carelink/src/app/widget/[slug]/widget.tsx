"use client";
import { useEffect, useRef, useState } from "react";
import { Loader2, Send } from "lucide-react";
import { Logo } from "@/components/brand/logo";

interface Msg {
  id: string;
  sender: "customer" | "ai" | "human" | "system";
  author_name: string | null;
  content: string;
  created_at: string;
}

type Session = { conversationId: string; token: string; customerName: string };

const KEY = (slug: string) => `carelink-widget-${slug}`;

function load(slug: string): Session | null {
  try {
    const raw = localStorage.getItem(KEY(slug));
    return raw ? (JSON.parse(raw) as Session) : null;
  } catch {
    return null;
  }
}
function store(slug: string, s: Session | null) {
  try {
    if (s) localStorage.setItem(KEY(slug), JSON.stringify(s));
    else localStorage.removeItem(KEY(slug));
  } catch {
    /* storage unavailable */
  }
}

export function ChatWidget({ orgSlug, orgName }: { orgSlug: string; orgName: string }) {
  const [session, setSession] = useState<Session | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState("open");
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setSession(load(orgSlug));
  }, [orgSlug]);

  useEffect(() => {
    if (!session) return;
    let stop = false;
    const poll = async () => {
      try {
        const r = await fetch(`/api/widget/messages?conversationId=${session.conversationId}&token=${session.token}`);
        if (r.status === 404) {
          store(orgSlug, null);
          setSession(null);
          return;
        }
        const d = await r.json();
        if (!stop && d.messages) {
          setMessages(d.messages);
          setStatus(d.status);
        }
      } catch {
        /* retry next tick */
      }
    };
    poll();
    const id = setInterval(poll, 4000);
    return () => {
      stop = true;
      clearInterval(id);
    };
  }, [session, orgSlug]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, busy]);

  async function start(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const r = await fetch("/api/widget/start", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ orgSlug, name, email }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Could not start chat");
      const s = { conversationId: d.conversationId, token: d.token, customerName: d.customerName };
      store(orgSlug, s);
      setSession(s);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!session || !text.trim() || busy) return;
    const content = text.trim();
    setText("");
    setBusy(true);
    setError(null);
    setMessages((m) => [...m, { id: `tmp-${Date.now()}`, sender: "customer", author_name: session.customerName, content, created_at: new Date().toISOString() }]);
    try {
      const r = await fetch("/api/widget/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId: session.conversationId, token: session.token, message: content }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Message failed");
      const fresh = await fetch(`/api/widget/messages?conversationId=${session.conversationId}&token=${session.token}`).then((x) => x.json());
      if (fresh.messages) {
        setMessages(fresh.messages);
        setStatus(fresh.status);
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex h-screen flex-col bg-navy-950">
      <header className="flex items-center gap-3 border-b border-white/5 bg-gradient-to-r from-electric-600/20 to-violet-600/20 px-4 py-3">
        <Logo withText={false} />
        <div className="flex-1">
          <p className="text-sm font-semibold text-white">{orgName} Support</p>
          <p className="text-[11px] text-slate-400">{status === "escalated" ? "A team member will reply here" : "AI assistant · usually instant"}</p>
        </div>
        {session && (
          <button className="text-[11px] text-slate-400 hover:text-white" onClick={() => { store(orgSlug, null); setSession(null); setMessages([]); }}>
            New chat
          </button>
        )}
      </header>

      {!session ? (
        <form onSubmit={start} className="m-auto w-full max-w-sm space-y-3 p-6">
          <p className="font-display text-lg font-semibold text-white">Hi there 👋</p>
          <p className="text-sm text-slate-400">Tell us who you are and we&apos;ll get you help right away.</p>
          <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" maxLength={120} className="h-10 w-full rounded-xl border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-electric-500/60" />
          <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="h-10 w-full rounded-xl border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-electric-500/60" />
          {error && <p className="text-xs text-rose-300">{error}</p>}
          <button disabled={busy} className="flex h-10 w-full items-center justify-center rounded-xl bg-gradient-to-r from-electric-600 to-violet-600 text-sm font-medium text-white disabled:opacity-50">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Start chat"}
          </button>
          <p className="text-center text-[10px] text-slate-500">Powered by CareLink</p>
        </form>
      ) : (
        <>
          <div className="flex-1 space-y-3 overflow-y-auto p-4 scrollbar-thin">
            {messages.length === 0 && <p className="mt-10 text-center text-sm text-slate-500">How can we help you today?</p>}
            {messages.map((m) => (
              <div key={m.id} className={m.sender === "customer" ? "flex justify-end" : "flex justify-start"}>
                <div className="max-w-[85%]">
                  {m.sender !== "customer" && <p className="mb-0.5 text-[10px] text-slate-500">{m.sender === "human" ? m.author_name : m.sender === "ai" ? "AI assistant" : "Support"}</p>}
                  <div className={`whitespace-pre-wrap rounded-2xl px-3.5 py-2 text-sm ${m.sender === "customer" ? "rounded-br-md bg-gradient-to-br from-electric-600 to-violet-600 text-white" : m.sender === "human" ? "rounded-bl-md bg-emerald-600/80 text-white" : "rounded-bl-md bg-white/[0.06] text-slate-100"}`}>
                    {m.content}
                  </div>
                </div>
              </div>
            ))}
            {busy && (
              <div className="flex gap-1 px-2">
                {[0, 1, 2].map((i) => <span key={i} className="h-1.5 w-1.5 animate-pulseDot rounded-full bg-electric-400" style={{ animationDelay: `${i * 0.2}s` }} />)}
              </div>
            )}
            <div ref={bottom} />
          </div>
          {error && <p className="px-4 text-xs text-rose-300">{error}</p>}
          <form onSubmit={send} className="flex gap-2 border-t border-white/5 p-3">
            <input value={text} onChange={(e) => setText(e.target.value)} maxLength={4000} placeholder="Type your message…" className="h-10 flex-1 rounded-xl border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-electric-500/60" />
            <button disabled={busy || !text.trim()} className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-electric-600 to-violet-600 text-white disabled:opacity-40" aria-label="Send">
              <Send className="h-4 w-4" />
            </button>
          </form>
        </>
      )}
    </div>
  );
}
