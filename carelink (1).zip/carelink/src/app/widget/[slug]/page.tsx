import { notFound } from "next/navigation";
import { createAdminClient, hasServiceRole } from "@/lib/supabase/admin";
import { ChatWidget } from "./widget";

export const dynamic = "force-dynamic";

export default async function WidgetPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!hasServiceRole()) {
    return <p className="p-6 text-sm text-slate-400">The chat widget needs SUPABASE_SERVICE_ROLE_KEY on the server.</p>;
  }
  const db = createAdminClient();
  const { data: org } = await db.from("organizations").select("name, slug").eq("slug", slug).maybeSingle();
  if (!org) notFound();
  return <ChatWidget orgSlug={org.slug} orgName={org.name} />;
}
