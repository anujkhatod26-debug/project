import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toast";

export const metadata: Metadata = {
  title: "CareLink – Omnichannel AI Customer Support",
  description: "One Platform. Every Conversation. Intelligent Support.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="font-sans">
        <Toaster>{children}</Toaster>
      </body>
    </html>
  );
}
