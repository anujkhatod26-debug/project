import { Logo } from "@/components/brand/logo";

const vars = [
  ["NEXT_PUBLIC_SUPABASE_URL", Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL)],
  ["NEXT_PUBLIC_SUPABASE_ANON_KEY", Boolean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)],
  ["SUPABASE_SERVICE_ROLE_KEY", Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY)],
  ["ANTHROPIC_API_KEY", Boolean(process.env.ANTHROPIC_API_KEY)],
] as const;

export const dynamic = "force-dynamic";

export default function SetupPage() {
  return (
    <div className="mx-auto max-w-xl p-8">
      <Logo />
      <div className="glass mt-8 p-6">
        <h1 className="font-display text-xl font-semibold text-white">Finish setting up CareLink</h1>
        <p className="mt-2 text-sm text-slate-400">
          Copy <code className="text-electric-400">.env.example</code> to <code className="text-electric-400">.env.local</code>, fill in the values below, run the SQL migration in Supabase, then restart <code>npm run dev</code>.
        </p>
        <ul className="mt-5 space-y-2 text-sm">
          {vars.map(([k, set]) => (
            <li key={k} className="flex items-center justify-between rounded-lg bg-white/5 px-3 py-2">
              <code>{k}</code>
              <span className={set ? "text-emerald-400" : "text-rose-400"}>{set ? "set" : "missing"}</span>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-xs text-slate-500">Full instructions are in README.md.</p>
      </div>
    </div>
  );
}
