import { requireApiUser, canManage, HttpError } from "@/lib/auth";
import { check, handleError, must, ok } from "@/lib/api";
import { conversationUpdateSchema } from "@/lib/validation";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase } = await requireApiUser();
    const convo = must(
      await supabase.from("conversations").select("*, customers(id,name,email), team_members(id,name)").eq("id", id).single(),
      "Conversation"
    );
    const messages = must(
      await supabase.from("messages").select("*").eq("conversation_id", id).order("created_at"),
      "Messages"
    );
    return ok({ conversation: convo, messages });
  } catch (err) {
    return handleError(err);
  }
}

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase } = await requireApiUser();
    const body = conversationUpdateSchema.parse(await req.json());
    const update: Record<string, unknown> = { ...body };
    if (body.status === "resolved") update.resolved_at = new Date().toISOString();
    if (body.status && body.status !== "resolved") update.resolved_at = null;
    if (body.status === "open" || body.status === "pending") update.escalated = false;
    const data = must(await supabase.from("conversations").update(update).eq("id", id).select().single(), "Update");
    return ok(data);
  } catch (err) {
    return handleError(err);
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase, profile } = await requireApiUser();
    if (!canManage(profile.role)) throw new HttpError(403, "Only admins and managers can delete conversations");
    check(await supabase.from("conversations").delete().eq("id", id), "Delete");
    return ok({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
