import { requireApiUser } from "@/lib/auth";
import { handleError, ok } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { runManualHandoff } from "@/lib/agents/orchestrator";

export const runtime = "nodejs";
export const maxDuration = 60;

/** "Request human support": runs the Human Handoff Agent for a conversation. */
export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const { supabase, profile, user } = await requireApiUser();
    rateLimit(`handoff:${user.id}`, 10, 60_000);
    const result = await runManualHandoff({
      db: supabase,
      orgId: profile.organization_id,
      conversationId: id,
      requestedBy: profile.full_name || profile.email,
    });
    return ok(result);
  } catch (err) {
    return handleError(err);
  }
}
