import { requireApiUser } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { humanReplySchema } from "@/lib/validation";
import { sendOutbound } from "@/lib/channels/adapters";
import type { Channel } from "@/types";

/** A human support rep replies in a conversation from the inbox. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const { supabase, profile } = await requireApiUser();
    const body = humanReplySchema.parse(await req.json());
    const convo = must(
      await supabase.from("conversations").select("id, channel, subject, first_response_at, customers(email, phone)").eq("id", id).single(),
      "Conversation"
    );

    // External channels: deliver through the real API first. If the channel isn't connected, say so honestly.
    let delivery: { delivered: boolean; error?: string } = { delivered: true };
    if (convo.channel !== "web_chat") {
      const { data: integ } = await supabase.from("channel_integrations").select("config, enabled").eq("channel", convo.channel).maybeSingle();
      const cust = convo.customers as { email: string | null; phone: string | null } | null;
      const to = convo.channel === "email" ? cust?.email : cust?.phone;
      try {
        if (!integ?.enabled) throw new Error(`${convo.channel} channel is not connected`);
        if (!to) throw new Error("Customer has no address for this channel");
        await sendOutbound(convo.channel as Channel, { config: (integ.config as Record<string, string>) ?? {}, to, text: body.content, subject: convo.subject ? `Re: ${convo.subject}` : undefined });
      } catch (err) {
        delivery = { delivered: false, error: err instanceof Error ? err.message : String(err) };
      }
    }

    const now = new Date().toISOString();
    const msg = must(
      await supabase
        .from("messages")
        .insert({
          organization_id: profile.organization_id,
          conversation_id: id,
          sender: "human",
          author_name: profile.full_name || profile.email,
          content: body.content,
          metadata: { profile_id: profile.id, delivery },
        })
        .select()
        .single(),
      "Reply"
    );
    await supabase
      .from("conversations")
      .update({ last_message_at: now, first_response_at: convo.first_response_at ?? now, current_agent: null })
      .eq("id", id);
    return ok({ ...msg, delivery }, 201);
  } catch (err) {
    return handleError(err);
  }
}
