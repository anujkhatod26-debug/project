import { requireApiUser } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { customerSchema } from "@/lib/validation";

export async function POST(req: Request) {
  try {
    const { supabase, profile } = await requireApiUser();
    const body = customerSchema.parse(await req.json());
    const data = must(
      await supabase.from("customers").insert({ ...body, organization_id: profile.organization_id }).select().single(),
      "Create customer"
    );
    return ok(data, 201);
  } catch (err) {
    return handleError(err);
  }
}
