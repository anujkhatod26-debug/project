import { requireApiUser, canManage, HttpError } from "@/lib/auth";
import { check, handleError, must, ok } from "@/lib/api";
import { customerSchema } from "@/lib/validation";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase } = await requireApiUser();
    const body = customerSchema.partial().parse(await req.json());
    const data = must(await supabase.from("customers").update(body).eq("id", id).select().single(), "Update customer");
    return ok(data);
  } catch (err) {
    return handleError(err);
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase, profile } = await requireApiUser();
    if (!canManage(profile.role)) throw new HttpError(403, "Only admins and managers can delete customers");
    check(await supabase.from("customers").delete().eq("id", id), "Delete customer");
    return ok({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
