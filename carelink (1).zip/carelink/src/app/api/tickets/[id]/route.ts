import { requireApiUser, canManage, HttpError } from "@/lib/auth";
import { check, handleError, must, ok } from "@/lib/api";
import { ticketUpdateSchema } from "@/lib/validation";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase } = await requireApiUser();
    const body = ticketUpdateSchema.parse(await req.json());
    const update: Record<string, unknown> = { ...body };
    if (body.status === "resolved") update.resolved_at = new Date().toISOString();
    else if (body.status) update.resolved_at = null;
    const data = must(await supabase.from("tickets").update(update).eq("id", id).select().single(), "Update ticket");
    return ok(data);
  } catch (err) {
    return handleError(err);
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase, profile } = await requireApiUser();
    if (!canManage(profile.role)) throw new HttpError(403, "Only admins and support managers can delete tickets");
    check(await supabase.from("tickets").delete().eq("id", id), "Delete ticket");
    return ok({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
