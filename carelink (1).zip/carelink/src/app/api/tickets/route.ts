import { requireApiUser } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { ticketCreateSchema } from "@/lib/validation";

export async function POST(req: Request) {
  try {
    const { supabase, profile } = await requireApiUser();
    const body = ticketCreateSchema.parse(await req.json());

    // When created from a conversation, fill in customer + category automatically.
    let extra: Record<string, unknown> = {};
    if (body.conversation_id) {
      const { data: c } = await supabase
        .from("conversations")
        .select("customer_id, category, priority")
        .eq("id", body.conversation_id)
        .single();
      if (c) extra = { customer_id: body.customer_id ?? c.customer_id, category: body.category !== "general" ? body.category : c.category ?? "general" };
    }

    const data = must(
      await supabase
        .from("tickets")
        .insert({
          ...body,
          ...extra,
          organization_id: profile.organization_id,
          created_by: profile.id,
          resolved_at: body.status === "resolved" ? new Date().toISOString() : null,
        })
        .select()
        .single(),
      "Create ticket"
    );
    return ok(data, 201);
  } catch (err) {
    return handleError(err);
  }
}
