import { requireApiUser, HttpError } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const maxDuration = 60;

const MAX_BYTES = 10 * 1024 * 1024;

async function extractText(file: File, buf: Buffer) {
  const name = file.name.toLowerCase();
  if (name.endsWith(".pdf") || file.type === "application/pdf") {
    const { PDFParse } = await import("pdf-parse");
    const parser = new PDFParse({ data: new Uint8Array(buf) });
    try {
      const result = await parser.getText();
      return result.text;
    } finally {
      await parser.destroy().catch(() => {});
    }
  }
  if (/\.(txt|md|markdown|csv)$/.test(name) || file.type.startsWith("text/")) {
    return buf.toString("utf-8");
  }
  throw new HttpError(400, "Only PDF, TXT, MD and CSV files are supported");
}

/** Upload a PDF or text document: store the file in Supabase Storage and index its text. */
export async function POST(req: Request) {
  try {
    const { supabase, profile, user } = await requireApiUser(["admin", "support_manager"]);
    rateLimit(`kb-upload:${user.id}`, 10, 60_000);

    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) throw new HttpError(400, "No file uploaded");
    if (file.size > MAX_BYTES) throw new HttpError(400, "File is larger than 10 MB");

    const category = String(form.get("category") || "general").slice(0, 60);
    const title = String(form.get("title") || file.name.replace(/\.[^.]+$/, "")).slice(0, 200);

    const buf = Buffer.from(await file.arrayBuffer());
    const text = (await extractText(file, buf)).replace(/\u0000/g, "").replace(/[ \t]+\n/g, "\n").trim();
    if (!text) throw new HttpError(400, "No readable text found in this file (scanned PDFs need OCR first)");

    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-100);
    const path = `${profile.organization_id}/${Date.now()}-${safeName}`;
    const up = await supabase.storage.from("knowledge-base").upload(path, buf, {
      contentType: file.type || "application/octet-stream",
      upsert: false,
    });
    if (up.error) throw new HttpError(400, `Storage upload failed: ${up.error.message}`);

    const data = must(
      await supabase
        .from("knowledge_articles")
        .insert({
          organization_id: profile.organization_id,
          title,
          category,
          type: "document",
          content: text.slice(0, 200000),
          file_path: path,
          file_name: file.name,
          file_size: file.size,
          created_by: profile.id,
        })
        .select()
        .single(),
      "Save document"
    );
    return ok({ ...data, characters: text.length }, 201);
  } catch (err) {
    return handleError(err);
  }
}
