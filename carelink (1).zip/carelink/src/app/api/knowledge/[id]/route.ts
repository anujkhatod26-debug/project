import { requireApiUser } from "@/lib/auth";
import { check, handleError, must, ok } from "@/lib/api";
import { articleSchema } from "@/lib/validation";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase } = await requireApiUser(["admin", "support_manager"]);
    const body = articleSchema.partial().parse(await req.json());
    const data = must(await supabase.from("knowledge_articles").update(body).eq("id", id).select().single(), "Update article");
    return ok(data);
  } catch (err) {
    return handleError(err);
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase } = await requireApiUser(["admin", "support_manager"]);
    const article = must(await supabase.from("knowledge_articles").select("file_path").eq("id", id).single(), "Article");
    if (article.file_path) await supabase.storage.from("knowledge-base").remove([article.file_path]);
    check(await supabase.from("knowledge_articles").delete().eq("id", id), "Delete article");
    return ok({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
