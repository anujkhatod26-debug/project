import { requireApiUser, HttpError } from "@/lib/auth";
import { handleError, must } from "@/lib/api";
import { NextResponse } from "next/server";

/** Redirects to a short-lived signed URL for the original uploaded file. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const { supabase } = await requireApiUser();
    const a = must(await supabase.from("knowledge_articles").select("file_path").eq("id", id).single(), "Article");
    if (!a.file_path) throw new HttpError(404, "This article has no file");
    const { data, error } = await supabase.storage.from("knowledge-base").createSignedUrl(a.file_path, 60);
    if (error || !data) throw new HttpError(400, error?.message ?? "Could not sign URL");
    return NextResponse.redirect(data.signedUrl);
  } catch (err) {
    return handleError(err);
  }
}
