import { requireApiUser } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { articleSchema } from "@/lib/validation";

/** Create an FAQ entry. */
export async function POST(req: Request) {
  try {
    const { supabase, profile } = await requireApiUser(["admin", "support_manager"]);
    const body = articleSchema.parse(await req.json());
    const data = must(
      await supabase
        .from("knowledge_articles")
        .insert({ ...body, type: "faq", organization_id: profile.organization_id, created_by: profile.id })
        .select()
        .single(),
      "Create article"
    );
    return ok(data, 201);
  } catch (err) {
    return handleError(err);
  }
}
