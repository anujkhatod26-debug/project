import { requireApiUser } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { orgSettingsSchema } from "@/lib/validation";

export async function PATCH(req: Request) {
  try {
    const { supabase, profile } = await requireApiUser(["admin"]);
    const body = orgSettingsSchema.parse(await req.json());
    const current = must(
      await supabase.from("organizations").select("settings").eq("id", profile.organization_id).single(),
      "Organization"
    );
    const update: Record<string, unknown> = {};
    if (body.name) update.name = body.name;
    if (body.settings) update.settings = { ...(current.settings as object), ...body.settings };
    const data = must(
      await supabase.from("organizations").update(update).eq("id", profile.organization_id).select().single(),
      "Update organization"
    );
    return ok(data);
  } catch (err) {
    return handleError(err);
  }
}
