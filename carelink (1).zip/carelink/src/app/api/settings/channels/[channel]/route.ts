import { requireApiUser, HttpError } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { channelUpdateSchema } from "@/lib/validation";
import { CHANNEL_REQUIREMENTS, missingEnv } from "@/lib/channels/requirements";
import type { Channel } from "@/types";


export async function PATCH(req: Request, { params }: { params: Promise<{ channel: string }> }) {
  try {
    const { channel } = await params;
    if (!(channel in CHANNEL_REQUIREMENTS)) throw new HttpError(404, "Unknown channel");
    const { supabase, profile } = await requireApiUser(["admin"]);
    const body = channelUpdateSchema.parse(await req.json());

    const missing = missingEnv(channel as Channel);
    const update: Record<string, unknown> = {};
    if (body.config) update.config = body.config;
    if (body.enabled !== undefined) {
      if (body.enabled && missing.length) {
        throw new HttpError(400, `Cannot enable ${channel}: missing server credentials ${missing.join(", ")}`);
      }
      update.enabled = body.enabled;
    }
    update.status = channel === "web_chat" ? "connected" : missing.length ? (body.config ? "pending_verification" : "not_configured") : "connected";

    const data = must(
      await supabase
        .from("channel_integrations")
        .update(update)
        .eq("organization_id", profile.organization_id)
        .eq("channel", channel)
        .select()
        .single(),
      "Update channel"
    );
    return ok({ ...data, missing });
  } catch (err) {
    return handleError(err);
  }
}
