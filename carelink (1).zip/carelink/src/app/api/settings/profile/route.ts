import { requireApiUser } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { profileSchema } from "@/lib/validation";

export async function PATCH(req: Request) {
  try {
    const { supabase, profile } = await requireApiUser();
    const body = profileSchema.parse(await req.json());
    const data = must(await supabase.from("profiles").update(body).eq("id", profile.id).select().single(), "Update profile");
    if (body.full_name) {
      await supabase.from("team_members").update({ name: body.full_name }).eq("profile_id", profile.id);
    }
    return ok(data);
  } catch (err) {
    return handleError(err);
  }
}
