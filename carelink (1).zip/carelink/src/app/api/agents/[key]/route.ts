import { requireApiUser } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { z } from "zod";

const schema = z.object({ enabled: z.boolean() });

/** Admins enable or disable an AI agent for their organization. */
export async function PATCH(req: Request, { params }: { params: Promise<{ key: string }> }) {
  try {
    const { key } = await params;
    const { supabase, profile } = await requireApiUser(["admin"]);
    const body = schema.parse(await req.json());
    const data = must(
      await supabase
        .from("ai_agents")
        .update({ enabled: body.enabled })
        .eq("organization_id", profile.organization_id)
        .eq("key", key)
        .select()
        .single(),
      "Update agent"
    );
    return ok(data);
  } catch (err) {
    return handleError(err);
  }
}
