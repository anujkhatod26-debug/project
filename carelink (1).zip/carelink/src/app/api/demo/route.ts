import { requireApiUser } from "@/lib/auth";
import { handleError, ok } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { clearDemoData, seedDemoData } from "@/lib/demo";

export const runtime = "nodejs";

/** Load demo data (admin only). Existing demo rows are replaced; real data is untouched. */
export async function POST() {
  try {
    const { supabase, profile, user } = await requireApiUser(["admin"]);
    rateLimit(`demo:${user.id}`, 3, 60_000);
    const counts = await seedDemoData(supabase, profile.organization_id);
    return ok({ ok: true, counts });
  } catch (err) {
    return handleError(err);
  }
}

/** Remove all demo data (admin only). */
export async function DELETE() {
  try {
    const { supabase, profile } = await requireApiUser(["admin"]);
    await clearDemoData(supabase, profile.organization_id);
    return ok({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
