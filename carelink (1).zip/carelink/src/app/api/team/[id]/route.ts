import { requireApiUser, HttpError } from "@/lib/auth";
import { check, handleError, must, ok } from "@/lib/api";
import { teamUpdateSchema } from "@/lib/validation";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase, profile } = await requireApiUser();
    const body = teamUpdateSchema.parse(await req.json());
    const member = must(await supabase.from("team_members").select("*").eq("id", id).single(), "Member");

    const isSelf = member.profile_id === profile.id;
    if (profile.role !== "admin") {
      if (!isSelf || body.role || body.name) throw new HttpError(403, "You can only change your own availability");
    }
    const data = must(await supabase.from("team_members").update(body).eq("id", id).select().single(), "Update member");

    // Keep the profile role in sync with the team role.
    if (body.role && member.profile_id) {
      await supabase.from("profiles").update({ role: body.role }).eq("id", member.profile_id);
    }
    return ok(data);
  } catch (err) {
    return handleError(err);
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const { supabase, profile } = await requireApiUser(["admin"]);
    const member = must(await supabase.from("team_members").select("profile_id").eq("id", id).single(), "Member");
    if (member.profile_id === profile.id) throw new HttpError(400, "You cannot remove yourself");
    check(await supabase.from("team_members").delete().eq("id", id), "Remove member");
    return ok({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
