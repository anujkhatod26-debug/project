import { requireApiUser } from "@/lib/auth";
import { handleError, must, ok } from "@/lib/api";
import { teamInviteSchema } from "@/lib/validation";

/**
 * Admin adds a team member. They appear as "invited" until they register with the same
 * email, at which point the signup trigger links them to this organization with this role.
 */
export async function POST(req: Request) {
  try {
    const { supabase, profile } = await requireApiUser(["admin"]);
    const body = teamInviteSchema.parse(await req.json());
    const data = must(
      await supabase
        .from("team_members")
        .insert({ ...body, organization_id: profile.organization_id, invite_status: "invited", availability: "offline" })
        .select()
        .single(),
      "Invite"
    );
    return ok(data, 201);
  } catch (err) {
    return handleError(err);
  }
}
