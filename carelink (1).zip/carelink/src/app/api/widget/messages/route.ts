import { handleError } from "@/lib/api";
import { createAdminClient } from "@/lib/supabase/admin";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { z } from "zod";

export const runtime = "nodejs";

const q = z.object({ conversationId: z.uuid(), token: z.uuid() });

/** Public website chat: poll for messages (so visitors see human replies). */
export async function GET(req: Request) {
  try {
    rateLimit(`widget-poll:${clientIp(req)}`, 60, 60_000);
    const url = new URL(req.url);
    const { conversationId, token } = q.parse(Object.fromEntries(url.searchParams));
    const db = createAdminClient();
    const { data: convo } = await db
      .from("conversations")
      .select("id, status")
      .eq("id", conversationId)
      .eq("public_token", token)
      .maybeSingle();
    if (!convo) return Response.json({ error: "Conversation not found" }, { status: 404 });

    const { data: messages } = await db
      .from("messages")
      .select("id, sender, author_name, content, created_at")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true })
      .limit(200);
    return Response.json({ status: convo.status, messages: messages ?? [] });
  } catch (err) {
    return handleError(err);
  }
}
