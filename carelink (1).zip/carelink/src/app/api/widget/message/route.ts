import { handleError } from "@/lib/api";
import { widgetMessageSchema } from "@/lib/validation";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { createAdminClient } from "@/lib/supabase/admin";
import { addCustomerMessage } from "@/lib/conversations";
import { runAgentWorkflow } from "@/lib/agents/orchestrator";

export const runtime = "nodejs";
export const maxDuration = 60;

/** Public website chat: visitor sends a message. Runs the full agent workflow server-side. */
export async function POST(req: Request) {
  try {
    const body = widgetMessageSchema.parse(await req.json());
    rateLimit(`widget-msg:${clientIp(req)}`, 12, 60_000);
    rateLimit(`widget-convo:${body.conversationId}`, 8, 60_000);
    const db = createAdminClient();

    const { data: convo } = await db
      .from("conversations")
      .select("id, organization_id, status, customers(name)")
      .eq("id", body.conversationId)
      .eq("public_token", body.token)
      .maybeSingle();
    if (!convo) return Response.json({ error: "Conversation not found" }, { status: 404 });

    const name = (convo.customers as unknown as { name: string } | null)?.name ?? "Visitor";
    const msg = await addCustomerMessage(db, convo.organization_id, convo.id, body.message, name);

    if (convo.status === "escalated") {
      return Response.json({ humanMode: true });
    }
    if (convo.status === "resolved") {
      await db.from("conversations").update({ status: "open", resolved_at: null }).eq("id", convo.id);
    }

    const final = await runAgentWorkflow({
      db,
      orgId: convo.organization_id,
      conversationId: convo.id,
      customerMessageId: msg.id,
      customerName: name,
    });
    return Response.json({
      reply: final.reply,
      agentName: final.agentName,
      escalated: final.escalated,
      assignedTo: final.assignedTo?.name ?? null,
    });
  } catch (err) {
    return handleError(err);
  }
}
