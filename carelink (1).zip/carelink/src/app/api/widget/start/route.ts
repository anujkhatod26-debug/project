import { handleError } from "@/lib/api";
import { widgetStartSchema } from "@/lib/validation";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { createAdminClient } from "@/lib/supabase/admin";
import { createConversation, findOrCreateCustomer } from "@/lib/conversations";

export const runtime = "nodejs";

/** Public website chat: a visitor starts a conversation with an organization. */
export async function POST(req: Request) {
  try {
    rateLimit(`widget-start:${clientIp(req)}`, 5, 60_000);
    const body = widgetStartSchema.parse(await req.json());
    const db = createAdminClient();

    const { data: org } = await db.from("organizations").select("id, name").eq("slug", body.orgSlug).maybeSingle();
    if (!org) return Response.json({ error: "Unknown support workspace" }, { status: 404 });

    const { data: channel } = await db
      .from("channel_integrations")
      .select("enabled")
      .eq("organization_id", org.id)
      .eq("channel", "web_chat")
      .maybeSingle();
    if (channel && !channel.enabled) return Response.json({ error: "Website chat is turned off" }, { status: 403 });

    const customer = await findOrCreateCustomer(db, org.id, { name: body.name, email: body.email });
    const convo = await createConversation(db, org.id, customer.id, "web_chat");
    return Response.json({ conversationId: convo.id, token: convo.public_token, orgName: org.name, customerName: customer.name });
  } catch (err) {
    return handleError(err);
  }
}
