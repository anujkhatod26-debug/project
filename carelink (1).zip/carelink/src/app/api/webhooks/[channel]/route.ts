import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { parseInbound, sendOutbound, verifyEmailSecret, verifyMetaSignature } from "@/lib/channels/adapters";
import { missingEnv } from "@/lib/channels/requirements";
import { addCustomerMessage, createConversation } from "@/lib/conversations";
import { runAgentWorkflow } from "@/lib/agents/orchestrator";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import type { Channel } from "@/types";

export const runtime = "nodejs";
export const maxDuration = 60;

const EXTERNAL: Channel[] = ["email", "whatsapp", "instagram", "messenger"];
const ACCOUNT_FIELD: Record<string, string> = {
  whatsapp: "phone_number_id",
  instagram: "account_id",
  messenger: "page_id",
  email: "support_address",
};

type Ctx = { params: Promise<{ channel: string }> };

/** Meta webhook verification handshake. */
export async function GET(req: Request, { params }: Ctx) {
  const { channel } = await params;
  const url = new URL(req.url);
  const token = channel === "whatsapp" ? process.env.WHATSAPP_VERIFY_TOKEN : process.env.META_VERIFY_TOKEN;
  if (url.searchParams.get("hub.mode") === "subscribe" && token && url.searchParams.get("hub.verify_token") === token) {
    return new Response(url.searchParams.get("hub.challenge") ?? "", { status: 200 });
  }
  return new Response("Forbidden", { status: 403 });
}

/** Inbound messages from external channels. Only active once the channel's credentials are configured. */
export async function POST(req: Request, { params }: Ctx) {
  const { channel: ch } = await params;
  const channel = ch as Channel;
  if (!EXTERNAL.includes(channel)) return NextResponse.json({ error: "Unknown channel" }, { status: 404 });

  const missing = missingEnv(channel);
  if (missing.length) {
    return NextResponse.json({ error: `${channel} is not configured`, missing }, { status: 503 });
  }

  try {
    rateLimit(`webhook:${channel}:${clientIp(req)}`, 120, 60_000);
  } catch {
    return NextResponse.json({ error: "Rate limited" }, { status: 429 });
  }

  const raw = await req.text();
  const authorised =
    channel === "email" ? verifyEmailSecret(req.headers.get("x-carelink-secret")) : verifyMetaSignature(raw, req.headers.get("x-hub-signature-256"));
  if (!authorised) return NextResponse.json({ error: "Invalid signature" }, { status: 401 });

  let body: unknown;
  try {
    body = JSON.parse(raw);
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const db = createAdminClient();
  const inbound = parseInbound(channel, body);

  for (const msg of inbound) {
    const { data: integrations } = await db
      .from("channel_integrations")
      .select("organization_id, config, enabled")
      .eq("channel", channel)
      .eq("enabled", true);
    const integ = (integrations ?? []).find(
      (i) => String((i.config as Record<string, string>)?.[ACCOUNT_FIELD[channel]!] ?? "").toLowerCase() === msg.accountId.toLowerCase()
    );
    if (!integ) continue;
    const orgId = integ.organization_id as string;

    // Customer: match by external id stored in phone/email
    const matchCol = channel === "email" ? "email" : "phone";
    const { data: existing } = await db
      .from("customers")
      .select("id, name")
      .eq("organization_id", orgId)
      .eq(matchCol, msg.externalUserId)
      .maybeSingle();
    const customer =
      existing ??
      (
        await db
          .from("customers")
          .insert({
            organization_id: orgId,
            name: msg.name,
            email: msg.email ?? null,
            phone: channel === "email" ? null : msg.externalUserId,
            primary_channel: channel,
          })
          .select("id, name")
          .single()
      ).data;
    if (!customer) continue;

    const { data: openConvo } = await db
      .from("conversations")
      .select("id, status")
      .eq("customer_id", customer.id)
      .eq("channel", channel)
      .neq("status", "resolved")
      .order("last_message_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    const convo = openConvo ?? { ...(await createConversation(db, orgId, customer.id, channel)), status: "open" };

    const saved = await addCustomerMessage(db, orgId, convo.id, msg.text, customer.name);
    if (convo.status === "escalated") continue; // human is handling it

    const final = await runAgentWorkflow({ db, orgId, conversationId: convo.id, customerMessageId: saved.id, customerName: customer.name });
    try {
      await sendOutbound(channel, { config: integ.config as Record<string, string>, to: msg.externalUserId, text: final.reply });
    } catch (err) {
      await db.from("messages").insert({
        organization_id: orgId,
        conversation_id: convo.id,
        sender: "system",
        author_name: "CareLink",
        content: `Delivery failed: ${err instanceof Error ? err.message : String(err)}`,
      });
    }
  }

  return NextResponse.json({ ok: true, processed: inbound.length });
}
