import { requireApiUser } from "@/lib/auth";
import { handleError } from "@/lib/api";
import { chatSchema } from "@/lib/validation";
import { rateLimit } from "@/lib/rate-limit";
import { addCustomerMessage, createConversation, findOrCreateCustomer, ndjsonStream } from "@/lib/conversations";
import { runAgentWorkflow } from "@/lib/agents/orchestrator";

export const runtime = "nodejs";
export const maxDuration = 60;

/**
 * Live AI chat used inside the dashboard (Agent Workflow page).
 * The signed-in staff member plays the customer. Streams every agent step as NDJSON.
 */
export async function POST(req: Request) {
  try {
    const { supabase, profile, user } = await requireApiUser();
    rateLimit(`chat:${user.id}`, 20, 60_000);
    const body = chatSchema.parse(await req.json());
    const orgId = profile.organization_id;

    let conversationId = body.conversationId;
    let customerName = body.customerName ?? "Website Visitor";

    if (conversationId) {
      const { data: convo } = await supabase
        .from("conversations")
        .select("id, status, escalated, customers(name)")
        .eq("id", conversationId)
        .single();
      if (!convo) return Response.json({ error: "Conversation not found" }, { status: 404 });
      customerName = (convo.customers as unknown as { name: string } | null)?.name ?? customerName;

      // A human has taken over: store the message but let the human answer.
      if (convo.status === "escalated") {
        const msg = await addCustomerMessage(supabase, orgId, conversationId, body.message, customerName);
        return ndjsonStream(async (send) => {
          send({
            type: "final",
            runId: null,
            final: {
              conversationId,
              messageId: msg.id,
              reply: null,
              humanMode: true,
              agentName: "Human support",
              escalated: true,
              escalationReasons: ["Conversation is with a human representative; AI agents are paused."],
            },
          });
        });
      }
    } else {
      const customer = body.customerId
        ? { id: body.customerId, name: customerName }
        : await findOrCreateCustomer(supabase, orgId, { name: customerName, email: body.customerEmail ?? null });
      customerName = customer.name;
      conversationId = (await createConversation(supabase, orgId, customer.id)).id;
    }

    const msg = await addCustomerMessage(supabase, orgId, conversationId!, body.message, customerName);

    return ndjsonStream(async (send) => {
      send({ type: "conversation", conversationId, customerMessageId: msg.id });
      await runAgentWorkflow({
        db: supabase,
        orgId,
        conversationId: conversationId!,
        customerMessageId: msg.id,
        customerName,
        onEvent: send,
      });
    });
  } catch (err) {
    return handleError(err);
  }
}
