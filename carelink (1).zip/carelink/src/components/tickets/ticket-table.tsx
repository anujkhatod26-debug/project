"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ui/dialog";
import { Select } from "@/components/ui/input";
import { DemoBadge } from "@/components/ui/badge";
import { Table, Td, Th } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { TicketDialog, type Option } from "./ticket-dialog";
import { api } from "@/lib/fetcher";
import { PRIORITIES, TICKET_STATUSES } from "@/lib/constants";
import { cn, formatDate, titleCase } from "@/lib/utils";
import type { Ticket } from "@/types";

const PRIORITY_CLS: Record<string, string> = {
  low: "text-slate-300",
  medium: "text-electric-400",
  high: "text-amber-300",
  urgent: "text-rose-300",
};
const STATUS_CLS: Record<string, string> = {
  open: "text-electric-400",
  in_progress: "text-violet-300",
  pending: "text-amber-300",
  resolved: "text-emerald-300",
  escalated: "text-rose-300",
};

function InlineSelect({ value, options, onChange, className }: { value: string; options: { v: string; l: string }[]; onChange: (v: string) => void; className?: string }) {
  return (
    <Select value={value} onChange={(e) => onChange(e.target.value)} className={cn("h-8 w-auto min-w-[110px] rounded-lg border-transparent bg-white/[0.04] px-2 text-xs", className)}>
      {options.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
    </Select>
  );
}

export function TicketTable({ tickets, team, customers, canDelete, highlight }: { tickets: Ticket[]; team: Option[]; customers: Option[]; canDelete: boolean; highlight?: string }) {
  const router = useRouter();
  const toast = useToast();
  const [rows, setRows] = useState(tickets);
  useEffect(() => {
    setRows(tickets);
  }, [tickets]);

  async function update(id: string, body: Record<string, unknown>) {
    const prev = rows;
    setRows((r) => r.map((t) => (t.id === id ? { ...t, ...body } : t)));
    try {
      await api(`/api/tickets/${id}`, { method: "PATCH", json: body });
      router.refresh();
    } catch (e) {
      setRows(prev);
      toast({ tone: "error", title: "Update failed", description: (e as Error).message });
    }
  }

  async function remove(id: string) {
    try {
      await api(`/api/tickets/${id}`, { method: "DELETE" });
      setRows((r) => r.filter((t) => t.id !== id));
      toast({ tone: "success", title: "Ticket deleted" });
      router.refresh();
    } catch (e) {
      toast({ tone: "error", title: "Delete failed", description: (e as Error).message });
    }
  }

  return (
    <Table>
      <thead>
        <tr>
          <Th>Ticket</Th>
          <Th>Customer</Th>
          <Th>Issue</Th>
          <Th>Category</Th>
          <Th>Priority</Th>
          <Th>Assigned</Th>
          <Th>Status</Th>
          <Th>Created</Th>
          <Th>Updated</Th>
          <Th></Th>
        </tr>
      </thead>
      <tbody>
        {rows.map((t) => (
          <tr key={t.id} id={`t-${t.id}`} className={cn("hover:bg-white/[0.02]", highlight === t.id && "bg-electric-500/[0.08]")}>
            <Td className="whitespace-nowrap">
              <span className="font-mono text-xs text-electric-400">{t.ticket_number}</span>
              {t.is_demo && <span className="ml-1.5"><DemoBadge /></span>}
            </Td>
            <Td className="whitespace-nowrap">
              {t.customers ? <Link className="hover:text-electric-400" href={`/customers/${t.customers.id}`}>{t.customers.name}</Link> : <span className="text-slate-500">—</span>}
            </Td>
            <Td className="max-w-[260px]">
              <p className="truncate text-slate-100" title={t.title}>{t.title}</p>
              {t.description && <p className="truncate text-[11px] text-slate-500" title={t.description}>{t.description}</p>}
              {t.conversation_id && <Link href={`/inbox?c=${t.conversation_id}`} className="text-[11px] text-electric-400 hover:underline">Conversation →</Link>}
            </Td>
            <Td className="text-xs text-slate-400">{titleCase(t.category)}</Td>
            <Td>
              <InlineSelect className={PRIORITY_CLS[t.priority]} value={t.priority} options={PRIORITIES.map((p) => ({ v: p, l: titleCase(p) }))} onChange={(v) => update(t.id, { priority: v })} />
            </Td>
            <Td>
              <InlineSelect value={t.assigned_to ?? ""} options={[{ v: "", l: "Unassigned" }, ...team.map((m) => ({ v: m.id, l: m.name }))]} onChange={(v) => update(t.id, { assigned_to: v || null })} />
            </Td>
            <Td>
              <InlineSelect className={STATUS_CLS[t.status]} value={t.status} options={TICKET_STATUSES.map((s) => ({ v: s, l: titleCase(s) }))} onChange={(v) => update(t.id, { status: v })} />
            </Td>
            <Td className="whitespace-nowrap text-xs text-slate-400">{formatDate(t.created_at)}</Td>
            <Td className="whitespace-nowrap text-xs text-slate-400">{formatDate(t.updated_at)}</Td>
            <Td>
              <div className="flex justify-end gap-1">
                <TicketDialog ticket={t} team={team} customers={customers} trigger="icon" />
                {canDelete && (
                  <ConfirmDialog
                    title={`Delete ${t.ticket_number}?`}
                    description="This permanently removes the ticket. The linked conversation is kept."
                    onConfirm={() => remove(t.id)}
                    trigger={<Button variant="ghost" size="icon" aria-label="Delete ticket"><Trash2 className="text-rose-400" /></Button>}
                  />
                )}
              </div>
            </Td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}
