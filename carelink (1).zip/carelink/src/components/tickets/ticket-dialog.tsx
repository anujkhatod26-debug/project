"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Pencil, Plus, TicketPlus } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/fetcher";
import { PRIORITIES, TICKET_STATUSES } from "@/lib/constants";
import { titleCase } from "@/lib/utils";
import type { Priority, Ticket, TicketStatus } from "@/types";

export interface Option {
  id: string;
  name: string;
}

export function TicketDialog({
  ticket,
  team,
  customers,
  defaults,
  trigger,
  onSaved,
}: {
  ticket?: Ticket;
  team: Option[];
  customers?: Option[];
  defaults?: Partial<{ conversation_id: string; customer_id: string; title: string; description: string; priority: Priority; category: string }>;
  trigger?: "button" | "icon" | "chat";
  onSaved?: (t: Ticket) => void;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const toast = useToast();
  const [form, setForm] = useState({
    title: ticket?.title ?? defaults?.title ?? "",
    description: ticket?.description ?? defaults?.description ?? "",
    category: ticket?.category ?? defaults?.category ?? "general",
    priority: (ticket?.priority ?? defaults?.priority ?? "medium") as Priority,
    status: (ticket?.status ?? "open") as TicketStatus,
    assigned_to: ticket?.assigned_to ?? "",
    customer_id: ticket?.customer_id ?? defaults?.customer_id ?? "",
  });
  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const body = {
        title: form.title,
        description: form.description,
        category: form.category.trim().toLowerCase().replace(/\s+/g, "_") || "general",
        priority: form.priority,
        status: form.status,
        assigned_to: form.assigned_to || null,
        customer_id: form.customer_id || null,
        ...(ticket ? {} : { conversation_id: defaults?.conversation_id ?? null }),
      };
      const saved = ticket
        ? await api<Ticket>(`/api/tickets/${ticket.id}`, { method: "PATCH", json: body })
        : await api<Ticket>("/api/tickets", { method: "POST", json: body });
      toast({ tone: "success", title: ticket ? "Ticket updated" : `Ticket ${saved.ticket_number} created` });
      setOpen(false);
      onSaved?.(saved);
      router.refresh();
    } catch (err) {
      toast({ tone: "error", title: "Could not save ticket", description: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (o && !ticket && defaults) setForm((f) => ({ ...f, title: defaults.title ?? f.title, description: defaults.description ?? f.description, priority: defaults.priority ?? f.priority, category: defaults.category ?? f.category }));
      }}
    >
      <DialogTrigger asChild>
        {trigger === "icon" ? (
          <Button variant="ghost" size="icon" aria-label="Edit ticket"><Pencil /></Button>
        ) : trigger === "chat" ? (
          <Button variant="secondary" size="sm"><TicketPlus /> Create ticket</Button>
        ) : ticket ? (
          <Button variant="secondary" size="sm"><Pencil /> Edit</Button>
        ) : (
          <Button><Plus /> New ticket</Button>
        )}
      </DialogTrigger>
      <DialogContent title={ticket ? `Edit ${ticket.ticket_number}` : "Create ticket"} className="max-w-xl">
        <form onSubmit={save} className="space-y-4">
          <Field label="Issue title"><Input required maxLength={200} value={form.title} onChange={(e) => set("title", e.target.value)} /></Field>
          <Field label="Description"><Textarea rows={4} value={form.description} onChange={(e) => set("description", e.target.value)} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Category"><Input value={form.category} onChange={(e) => set("category", e.target.value)} placeholder="payment_failure" /></Field>
            <Field label="Priority">
              <Select value={form.priority} onChange={(e) => set("priority", e.target.value as Priority)}>
                {PRIORITIES.map((p) => <option key={p} value={p}>{titleCase(p)}</option>)}
              </Select>
            </Field>
            <Field label="Status">
              <Select value={form.status} onChange={(e) => set("status", e.target.value as TicketStatus)}>
                {TICKET_STATUSES.map((s) => <option key={s} value={s}>{titleCase(s)}</option>)}
              </Select>
            </Field>
            <Field label="Assigned agent">
              <Select value={form.assigned_to} onChange={(e) => set("assigned_to", e.target.value)}>
                <option value="">Unassigned</option>
                {team.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
              </Select>
            </Field>
            {customers && !defaults?.conversation_id && (
              <div className="col-span-2">
                <Field label="Customer">
                  <Select value={form.customer_id} onChange={(e) => set("customer_id", e.target.value)}>
                    <option value="">No customer</option>
                    {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </Select>
                </Field>
              </div>
            )}
          </div>
          <div className="flex justify-end gap-2">
            <Button type="submit" loading={busy}>{ticket ? "Save changes" : "Create ticket"}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
