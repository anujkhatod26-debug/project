"use client";
import { useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Input, Select } from "@/components/ui/input";
import { PRIORITIES, TICKET_STATUSES } from "@/lib/constants";
import { titleCase } from "@/lib/utils";
import type { Option } from "./ticket-dialog";

export function TicketFilters({ team }: { team: Option[] }) {
  const sp = useSearchParams();
  const router = useRouter();
  const path = usePathname();
  const [q, setQ] = useState(sp.get("q") ?? "");
  const set = (k: string, v: string) => {
    const n = new URLSearchParams(sp.toString());
    if (v) n.set(k, v);
    else n.delete(k);
    n.delete("t");
    router.replace(`${path}?${n.toString()}`, { scroll: false });
  };
  useEffect(() => {
    const t = setTimeout(() => {
      if ((sp.get("q") ?? "") !== q) set("q", q);
    }, 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  return (
    <div className="flex flex-col gap-2 lg:flex-row">
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by ticket ID, title or description" className="lg:max-w-sm" />
      <Select value={sp.get("status") ?? ""} onChange={(e) => set("status", e.target.value)} className="lg:w-40">
        <option value="">All status</option>
        {TICKET_STATUSES.map((s) => <option key={s} value={s}>{titleCase(s)}</option>)}
      </Select>
      <Select value={sp.get("priority") ?? ""} onChange={(e) => set("priority", e.target.value)} className="lg:w-40">
        <option value="">Any priority</option>
        {PRIORITIES.map((s) => <option key={s} value={s}>{titleCase(s)}</option>)}
      </Select>
      <Select value={sp.get("assigned") ?? ""} onChange={(e) => set("assigned", e.target.value)} className="lg:w-48">
        <option value="">Anyone</option>
        <option value="none">Unassigned</option>
        {team.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
      </Select>
    </div>
  );
}
