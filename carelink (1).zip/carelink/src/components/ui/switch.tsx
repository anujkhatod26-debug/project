"use client";
import * as S from "@radix-ui/react-switch";
import { cn } from "@/lib/utils";

export function Switch({ className, ...props }: S.SwitchProps) {
  return (
    <S.Root
      className={cn(
        "relative h-6 w-11 shrink-0 cursor-pointer rounded-full border border-white/10 bg-white/10 transition data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-electric-600 data-[state=checked]:to-violet-600 disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      {...props}
    >
      <S.Thumb className="block h-5 w-5 translate-x-0.5 rounded-full bg-white shadow transition data-[state=checked]:translate-x-[22px]" />
    </S.Root>
  );
}
