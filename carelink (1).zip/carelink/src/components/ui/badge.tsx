import { cn, titleCase } from "@/lib/utils";

const tones: Record<string, string> = {
  blue: "bg-electric-500/15 text-electric-400 ring-electric-500/30",
  violet: "bg-violet-500/15 text-violet-300 ring-violet-500/30",
  green: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  amber: "bg-amber-500/15 text-amber-300 ring-amber-500/30",
  red: "bg-rose-500/15 text-rose-300 ring-rose-500/30",
  slate: "bg-slate-500/15 text-slate-300 ring-slate-500/30",
  cyan: "bg-cyan-500/15 text-cyan-300 ring-cyan-500/30",
  pink: "bg-pink-500/15 text-pink-300 ring-pink-500/30",
};

export type Tone = keyof typeof tones;

export function Badge({ tone = "slate", className, children }: { tone?: Tone; className?: string; children: React.ReactNode }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset", tones[tone], className)}>
      {children}
    </span>
  );
}

const STATUS_TONE: Record<string, Tone> = {
  open: "blue",
  in_progress: "violet",
  pending: "amber",
  resolved: "green",
  escalated: "red",
  connected: "green",
  not_configured: "slate",
  pending_verification: "amber",
  error: "red",
  success: "green",
  skipped: "slate",
  available: "green",
  busy: "amber",
  away: "slate",
  offline: "slate",
  invited: "violet",
  active: "green",
};
const PRIORITY_TONE: Record<string, Tone> = { low: "slate", medium: "blue", high: "amber", urgent: "red" };
const SENTIMENT_TONE: Record<string, Tone> = { positive: "green", neutral: "slate", negative: "amber", very_negative: "red" };

export function StatusBadge({ status }: { status: string }) {
  return <Badge tone={STATUS_TONE[status] ?? "slate"}>{titleCase(status)}</Badge>;
}
export function PriorityBadge({ priority }: { priority: string }) {
  return <Badge tone={PRIORITY_TONE[priority] ?? "slate"}>{titleCase(priority)}</Badge>;
}
export function SentimentBadge({ sentiment }: { sentiment: string | null }) {
  if (!sentiment) return <span className="text-xs text-slate-500">—</span>;
  return <Badge tone={SENTIMENT_TONE[sentiment] ?? "slate"}>{titleCase(sentiment)}</Badge>;
}
export function DemoBadge() {
  return <Badge tone="violet" className="uppercase tracking-wide">Demo</Badge>;
}
