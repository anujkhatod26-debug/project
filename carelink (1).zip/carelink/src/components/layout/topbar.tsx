"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import * as DM from "@radix-ui/react-dropdown-menu";
import { Bell, LogOut, Menu, Search, Settings, User, AlertTriangle, Ticket } from "lucide-react";
import { Avatar } from "@/components/ui/misc";
import { ROLE_LABEL } from "@/lib/constants";
import { timeAgo } from "@/lib/utils";
import type { Profile } from "@/types";

export interface NotificationItem {
  id: string;
  kind: "escalation" | "ticket";
  title: string;
  href: string;
  at: string;
}

const menuCls = "glass-strong z-50 min-w-[220px] p-1.5 text-sm";
const itemCls = "flex cursor-pointer items-center gap-2 rounded-lg px-2.5 py-2 text-slate-300 outline-none data-[highlighted]:bg-white/5 data-[highlighted]:text-white";

export function Topbar({
  profile,
  orgName,
  notifications,
  onMenu,
}: {
  profile: Profile;
  orgName: string;
  notifications: NotificationItem[];
  onMenu: () => void;
}) {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [seen, setSeen] = useState(false);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-white/5 bg-navy-950/70 px-4 backdrop-blur-xl sm:px-6">
      <button className="rounded-lg p-2 text-slate-400 hover:bg-white/5 lg:hidden" onClick={onMenu} aria-label="Open menu">
        <Menu className="h-5 w-5" />
      </button>

      <form
        className="relative max-w-md flex-1"
        onSubmit={(e) => {
          e.preventDefault();
          if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`);
        }}
      >
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search customers, tickets, conversations…"
          className="h-10 w-full rounded-xl border border-white/5 bg-white/[0.03] pl-9 pr-3 text-sm text-slate-200 placeholder:text-slate-500 outline-none focus:border-electric-500/40"
        />
      </form>

      <div className="ml-auto flex items-center gap-2">
        <DM.Root onOpenChange={(o) => o && setSeen(true)}>
          <DM.Trigger className="relative rounded-xl p-2.5 text-slate-400 outline-none hover:bg-white/5 hover:text-white" aria-label="Notifications">
            <Bell className="h-5 w-5" />
            {!seen && notifications.length > 0 && (
              <span className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[9px] font-bold text-white">
                {notifications.length}
              </span>
            )}
          </DM.Trigger>
          <DM.Portal>
            <DM.Content align="end" sideOffset={8} className={`${menuCls} w-80`}>
              <p className="px-2.5 py-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Notifications</p>
              {notifications.length === 0 && <p className="px-2.5 py-4 text-center text-xs text-slate-500">You&apos;re all caught up.</p>}
              {notifications.map((n) => (
                <DM.Item key={n.id} asChild className={itemCls}>
                  <Link href={n.href}>
                    {n.kind === "escalation" ? (
                      <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />
                    ) : (
                      <Ticket className="h-4 w-4 shrink-0 text-electric-400" />
                    )}
                    <span className="flex-1 truncate">{n.title}</span>
                    <span className="text-[10px] text-slate-500">{timeAgo(n.at)}</span>
                  </Link>
                </DM.Item>
              ))}
            </DM.Content>
          </DM.Portal>
        </DM.Root>

        <DM.Root>
          <DM.Trigger className="flex items-center gap-2.5 rounded-xl p-1.5 pr-3 outline-none hover:bg-white/5">
            <Avatar name={profile.full_name || profile.email} />
            <div className="hidden text-left sm:block">
              <p className="text-sm font-medium leading-tight text-white">{profile.full_name || profile.email}</p>
              <p className="text-[11px] leading-tight text-slate-500">{ROLE_LABEL[profile.role]} · {orgName}</p>
            </div>
          </DM.Trigger>
          <DM.Portal>
            <DM.Content align="end" sideOffset={8} className={menuCls}>
              <div className="px-2.5 py-2">
                <p className="truncate text-sm text-white">{profile.email}</p>
                <p className="text-[11px] text-slate-500">{ROLE_LABEL[profile.role]}</p>
              </div>
              <DM.Separator className="my-1 h-px bg-white/5" />
              <DM.Item asChild className={itemCls}>
                <Link href="/settings?tab=profile"><User className="h-4 w-4" /> Profile</Link>
              </DM.Item>
              <DM.Item asChild className={itemCls}>
                <Link href="/settings"><Settings className="h-4 w-4" /> Settings</Link>
              </DM.Item>
              <DM.Separator className="my-1 h-px bg-white/5" />
              <form action="/auth/signout" method="post">
                <button type="submit" className={`${itemCls} w-full text-rose-300`}>
                  <LogOut className="h-4 w-4" /> Sign out
                </button>
              </form>
            </DM.Content>
          </DM.Portal>
        </DM.Root>
      </div>
    </header>
  );
}
