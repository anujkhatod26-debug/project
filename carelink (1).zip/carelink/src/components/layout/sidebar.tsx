"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Inbox,
  Bot,
  Workflow,
  Ticket,
  Users,
  BookOpen,
  BarChart3,
  UsersRound,
  Settings,
  X,
} from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { cn } from "@/lib/utils";

export const NAV = [
  { href: "/overview", label: "Overview", icon: LayoutDashboard },
  { href: "/inbox", label: "Omnichannel Inbox", icon: Inbox },
  { href: "/agents", label: "AI Agents", icon: Bot },
  { href: "/workflow", label: "Agent Workflow", icon: Workflow },
  { href: "/tickets", label: "Tickets", icon: Ticket },
  { href: "/customers", label: "Customers", icon: Users },
  { href: "/knowledge", label: "Knowledge Base", icon: BookOpen },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/team", label: "Team Management", icon: UsersRound },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar({ open, onClose, counts }: { open: boolean; onClose: () => void; counts: { inbox: number; tickets: number } }) {
  const path = usePathname();
  return (
    <>
      <div
        className={cn("fixed inset-0 z-40 bg-navy-950/70 backdrop-blur-sm lg:hidden", open ? "block" : "hidden")}
        onClick={onClose}
      />
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-white/5 bg-navy-950/90 backdrop-blur-xl transition-transform lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex h-16 items-center justify-between px-5">
          <Logo />
          <button className="rounded-lg p-1 text-slate-400 lg:hidden" onClick={onClose} aria-label="Close menu">
            <X className="h-5 w-5" />
          </button>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-4 scrollbar-thin">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = path === href || path.startsWith(href + "/");
            const badge = href === "/inbox" ? counts.inbox : href === "/tickets" ? counts.tickets : 0;
            return (
              <Link
                key={href}
                href={href}
                onClick={onClose}
                className={cn(
                  "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition",
                  active ? "bg-gradient-to-r from-electric-600/20 to-violet-600/10 text-white" : "text-slate-400 hover:bg-white/[0.04] hover:text-slate-100"
                )}
              >
                {active && <span className="absolute left-0 top-2 bottom-2 w-0.5 rounded-full bg-electric-400" />}
                <Icon className={cn("h-[18px] w-[18px]", active ? "text-electric-400" : "text-slate-500 group-hover:text-slate-300")} />
                <span className="flex-1">{label}</span>
                {badge > 0 && (
                  <span className="rounded-full bg-electric-500/20 px-1.5 text-[10px] font-semibold text-electric-400">{badge}</span>
                )}
              </Link>
            );
          })}
        </nav>
        <div className="m-3 rounded-2xl border border-white/5 bg-gradient-to-br from-electric-600/15 to-violet-600/10 p-4">
          <p className="text-xs font-medium text-white">Try the live AI chat</p>
          <p className="mt-1 text-[11px] text-slate-400">Send a message and watch all seven agents work.</p>
          <Link href="/workflow" className="mt-3 inline-block text-xs font-medium text-electric-400 hover:underline">
            Open Agent Workflow →
          </Link>
        </div>
      </aside>
    </>
  );
}
