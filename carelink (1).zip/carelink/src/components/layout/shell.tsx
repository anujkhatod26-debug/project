"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { FlaskConical } from "lucide-react";
import { Sidebar } from "./sidebar";
import { Topbar, type NotificationItem } from "./topbar";
import { RealtimeRefresher } from "./realtime";
import type { Profile } from "@/types";

export function DashboardShell({
  children,
  profile,
  orgName,
  orgId,
  notifications,
  counts,
  hasDemo,
  aiConfigured,
  theme,
}: {
  children: React.ReactNode;
  profile: Profile;
  orgName: string;
  orgId: string;
  notifications: NotificationItem[];
  counts: { inbox: number; tickets: number };
  hasDemo: boolean;
  aiConfigured: boolean;
  theme: string;
}) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);
  return (
    <div className="min-h-screen">
      <Sidebar open={open} onClose={() => setOpen(false)} counts={counts} />
      <div className="lg:pl-64">
        <Topbar profile={profile} orgName={orgName} notifications={notifications} onMenu={() => setOpen(true)} />
        {hasDemo && (
          <div className="flex items-center gap-2 border-b border-violet-500/20 bg-violet-500/10 px-6 py-2 text-xs text-violet-200">
            <FlaskConical className="h-3.5 w-3.5" />
            <span>
              <strong>Demo mode:</strong> sample records marked <em>Demo</em> are included in this workspace. New chats you send are processed live by the AI agents.
            </span>
            {profile.role === "admin" && (
              <Link href="/settings?tab=demo" className="ml-auto underline-offset-2 hover:underline">Manage demo data</Link>
            )}
          </div>
        )}
        {!aiConfigured && (
          <div className="border-b border-amber-500/20 bg-amber-500/10 px-6 py-2 text-xs text-amber-200">
            AI is not configured: set <code>ANTHROPIC_API_KEY</code> on the server. Until then, new customer messages are routed to humans and no AI replies are generated.
          </div>
        )}
        <main className="p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
      <RealtimeRefresher orgId={orgId} />
    </div>
  );
}
