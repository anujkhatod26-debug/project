"use client";
import { useEffect, useRef } from "react";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

/**
 * Listens to Supabase Realtime for changes in this organization and refreshes the
 * current server-rendered page (debounced). Skipped on the live workflow page, which
 * manages its own state.
 */
export function RealtimeRefresher({ orgId }: { orgId: string }) {
  const router = useRouter();
  const path = usePathname();
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (path.startsWith("/workflow")) return;
    const supabase = createClient();
    const refresh = () => {
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => router.refresh(), 800);
    };
    const channel = supabase.channel(`org-${orgId}`);
    for (const table of ["messages", "conversations", "tickets"]) {
      channel.on("postgres_changes", { event: "*", schema: "public", table, filter: `organization_id=eq.${orgId}` }, refresh);
    }
    channel.subscribe();
    return () => {
      if (timer.current) clearTimeout(timer.current);
      supabase.removeChannel(channel);
    };
  }, [orgId, path, router]);

  return null;
}
