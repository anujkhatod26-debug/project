"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/fetcher";

export function AgentToggle({ agentKey, enabled, canEdit }: { agentKey: string; enabled: boolean; canEdit: boolean }) {
  const [on, setOn] = useState(enabled);
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const router = useRouter();
  return (
    <Switch
      checked={on}
      disabled={!canEdit || busy}
      title={canEdit ? undefined : "Only admins can change agents"}
      onCheckedChange={async (v) => {
        setOn(v);
        setBusy(true);
        try {
          await api(`/api/agents/${agentKey}`, { method: "PATCH", json: { enabled: v } });
          toast({ tone: "success", title: v ? "Agent enabled" : "Agent disabled" });
          router.refresh();
        } catch (e) {
          setOn(!v);
          toast({ tone: "error", title: "Could not update agent", description: (e as Error).message });
        } finally {
          setBusy(false);
        }
      }}
    />
  );
}
