"use client";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Select } from "@/components/ui/input";
import { AGENT_META, AGENT_ORDER } from "@/lib/constants";

export function LogFilter() {
  const sp = useSearchParams();
  const router = useRouter();
  const path = usePathname();
  const set = (k: string, v: string) => {
    const n = new URLSearchParams(sp.toString());
    if (v) n.set(k, v);
    else n.delete(k);
    router.replace(`${path}?${n.toString()}`, { scroll: false });
  };
  return (
    <div className="flex gap-2">
      <Select value={sp.get("agent") ?? ""} onChange={(e) => set("agent", e.target.value)} className="h-9 w-52 text-xs">
        <option value="">All agents</option>
        {AGENT_ORDER.map((k) => <option key={k} value={k}>{AGENT_META[k].name}</option>)}
      </Select>
      <Select value={sp.get("status") ?? ""} onChange={(e) => set("status", e.target.value)} className="h-9 w-36 text-xs">
        <option value="">Any status</option>
        <option value="success">Success</option>
        <option value="error">Error</option>
        <option value="skipped">Skipped</option>
      </Select>
    </div>
  );
}
