"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Trash2, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDialog, Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Field, Input, Select } from "@/components/ui/input";
import { Avatar, Table, Td, Th } from "@/components/ui/misc";
import { DemoBadge, StatusBadge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/fetcher";
import { ROLES, ROLE_LABEL } from "@/lib/constants";
import { formatDate } from "@/lib/utils";
import type { TeamMember, UserRole } from "@/types";

export function InviteDialog() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", role: "support_agent" as UserRole });
  const router = useRouter();
  const toast = useToast();
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><UserPlus /> Add team member</Button></DialogTrigger>
      <DialogContent title="Add a team member" description="They join this workspace with the chosen role when they register with this email. No email is sent automatically; share the sign-up link with them.">
        <form
          className="space-y-4"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            try {
              await api("/api/team", { method: "POST", json: form });
              toast({ tone: "success", title: "Team member added", description: `Ask ${form.name} to register at ${window.location.origin}/register using ${form.email}.` });
              setOpen(false);
              setForm({ name: "", email: "", role: "support_agent" });
              router.refresh();
            } catch (err) {
              toast({ tone: "error", title: "Could not add", description: (err as Error).message });
            } finally {
              setBusy(false);
            }
          }}
        >
          <Field label="Name"><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Email"><Input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
          <Field label="Role">
            <Select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as UserRole })}>
              {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
            </Select>
          </Field>
          <div className="flex justify-end"><Button type="submit" loading={busy}>Add member</Button></div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function TeamTable({ members, me, isAdmin, load }: { members: TeamMember[]; me: string; isAdmin: boolean; load: Record<string, number> }) {
  const router = useRouter();
  const toast = useToast();

  async function update(id: string, body: Record<string, unknown>) {
    try {
      await api(`/api/team/${id}`, { method: "PATCH", json: body });
      toast({ tone: "success", title: "Updated" });
      router.refresh();
    } catch (e) {
      toast({ tone: "error", title: "Update failed", description: (e as Error).message });
    }
  }

  return (
    <Table>
      <thead>
        <tr><Th>Member</Th><Th>Role</Th><Th>Availability</Th><Th>Status</Th><Th className="text-center">Active conversations</Th><Th>Added</Th><Th></Th></tr>
      </thead>
      <tbody>
        {members.map((m) => {
          const self = m.profile_id === me;
          return (
            <tr key={m.id} className="hover:bg-white/[0.02]">
              <Td>
                <div className="flex items-center gap-3">
                  <Avatar name={m.name} />
                  <div>
                    <p className="flex items-center gap-2 text-sm font-medium text-white">{m.name}{self && <span className="text-[10px] text-slate-500">(you)</span>}{m.is_demo && <DemoBadge />}</p>
                    <p className="text-xs text-slate-500">{m.email}</p>
                  </div>
                </div>
              </Td>
              <Td>
                {isAdmin && !self ? (
                  <Select value={m.role} onChange={(e) => update(m.id, { role: e.target.value })} className="h-8 w-44 text-xs">
                    {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                  </Select>
                ) : (
                  <span className="text-sm text-slate-300">{ROLE_LABEL[m.role]}</span>
                )}
              </Td>
              <Td>
                {isAdmin || self ? (
                  <Select value={m.availability} onChange={(e) => update(m.id, { availability: e.target.value })} className="h-8 w-32 text-xs">
                    {["available", "busy", "away", "offline"].map((a) => <option key={a} value={a}>{a[0]!.toUpperCase() + a.slice(1)}</option>)}
                  </Select>
                ) : (
                  <StatusBadge status={m.availability} />
                )}
              </Td>
              <Td><StatusBadge status={m.invite_status} /></Td>
              <Td className="text-center">{load[m.id] ?? 0}</Td>
              <Td className="text-xs text-slate-400">{formatDate(m.created_at, false)}</Td>
              <Td>
                {isAdmin && !self && (
                  <ConfirmDialog
                    title={`Remove ${m.name}?`}
                    description="They lose access to this workspace. Their past messages are kept."
                    confirmLabel="Remove"
                    onConfirm={async () => {
                      try {
                        await api(`/api/team/${m.id}`, { method: "DELETE" });
                        toast({ tone: "success", title: "Member removed" });
                        router.refresh();
                      } catch (e) {
                        toast({ tone: "error", title: "Remove failed", description: (e as Error).message });
                      }
                    }}
                    trigger={<Button variant="ghost" size="icon" aria-label="Remove"><Trash2 className="text-rose-400" /></Button>}
                  />
                )}
              </Td>
            </tr>
          );
        })}
      </tbody>
    </Table>
  );
}
