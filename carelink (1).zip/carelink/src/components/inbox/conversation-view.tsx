"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, ExternalLink, RotateCcw, Send, UserRound, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, Textarea } from "@/components/ui/input";
import { Badge, PriorityBadge, SentimentBadge, StatusBadge, DemoBadge } from "@/components/ui/badge";
import { Avatar } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { TicketDialog, type Option } from "@/components/tickets/ticket-dialog";
import { api } from "@/lib/fetcher";
import { AGENT_META, CHANNEL_META, PRIORITIES } from "@/lib/constants";
import { cn, formatDate, titleCase } from "@/lib/utils";
import type { AgentKey, Channel, Conversation, Message, Priority } from "@/types";

export function ConversationView({
  conversation,
  messages,
  team,
  tickets,
}: {
  conversation: Conversation & { customers: { id: string; name: string; email: string | null } | null };
  messages: Message[];
  team: Option[];
  tickets: { id: string; ticket_number: string; status: string; title: string }[];
}) {
  const router = useRouter();
  const toast = useToast();
  const [reply, setReply] = useState("");
  const [sending, setSending] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const c = conversation;

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  async function patch(body: Record<string, unknown>, label: string) {
    setBusy(label);
    try {
      await api(`/api/conversations/${c.id}`, { method: "PATCH", json: body });
      toast({ tone: "success", title: label });
      router.refresh();
    } catch (e) {
      toast({ tone: "error", title: "Update failed", description: (e as Error).message });
    } finally {
      setBusy(null);
    }
  }

  async function sendReply(e: React.FormEvent) {
    e.preventDefault();
    if (!reply.trim()) return;
    setSending(true);
    try {
      const r = await api<{ delivery?: { delivered: boolean; error?: string } }>(`/api/conversations/${c.id}/messages`, { method: "POST", json: { content: reply } });
      if (r.delivery && !r.delivery.delivered) toast({ tone: "error", title: "Saved, but not delivered", description: r.delivery.error });
      setReply("");
      router.refresh();
    } catch (e) {
      toast({ tone: "error", title: "Reply failed", description: (e as Error).message });
    } finally {
      setSending(false);
    }
  }

  async function handoff() {
    setBusy("handoff");
    try {
      const r = await api<{ assignedTo: { name: string } | null }>(`/api/conversations/${c.id}/handoff`, { method: "POST" });
      toast({ tone: "success", title: "Escalated to human support", description: r.assignedTo ? `Assigned to ${r.assignedTo.name}` : "Added to the escalation queue" });
      router.refresh();
    } catch (e) {
      toast({ tone: "error", title: "Handoff failed", description: (e as Error).message });
    } finally {
      setBusy(null);
    }
  }

  const lastCustomer = [...messages].reverse().find((m) => m.sender === "customer");

  return (
    <div className="flex h-full min-h-0 flex-col xl:flex-row">
      {/* Messages */}
      <div className="flex min-h-0 flex-1 flex-col">
        <div className="flex flex-wrap items-center gap-2 border-b border-white/5 p-4">
          <Avatar name={c.customers?.name} />
          <div className="mr-auto min-w-0">
            <div className="flex items-center gap-2">
              <p className="truncate text-sm font-semibold text-white">{c.customers?.name ?? "Customer"}</p>
              {c.is_demo && <DemoBadge />}
            </div>
            <p className="truncate text-[11px] text-slate-500">{c.subject ?? "Conversation"}</p>
          </div>
          <Badge tone="slate">{CHANNEL_META[c.channel as Channel]?.label}</Badge>
          <StatusBadge status={c.status} />
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-4 scrollbar-thin">
          {messages.map((m) => (
            <div key={m.id} className={cn("flex", m.sender === "customer" ? "justify-start" : "justify-end")}>
              <div className="max-w-[80%]">
                <p className={cn("mb-1 text-[11px] text-slate-500", m.sender !== "customer" && "text-right")}>
                  {m.sender === "ai" ? AGENT_META[m.agent_key as AgentKey]?.name ?? "AI" : m.author_name ?? titleCase(m.sender)}
                  {m.sender === "human" && " (human)"} · {formatDate(m.created_at)}
                </p>
                <div
                  className={cn(
                    "whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed",
                    m.sender === "customer" && "rounded-bl-md border border-white/5 bg-white/[0.05] text-slate-100",
                    m.sender === "ai" && "rounded-br-md bg-gradient-to-br from-electric-600/80 to-violet-600/80 text-white",
                    m.sender === "human" && "rounded-br-md bg-emerald-600/80 text-white",
                    m.sender === "system" && "rounded-br-md border border-amber-500/20 bg-amber-500/10 text-amber-100"
                  )}
                >
                  {m.content}
                </div>
              </div>
            </div>
          ))}
          <div ref={bottom} />
        </div>

        <form onSubmit={sendReply} className="border-t border-white/5 p-4">
          <Textarea
            rows={2}
            value={reply}
            onChange={(e) => setReply(e.target.value)}
            placeholder={c.channel === "web_chat" ? "Reply as a human agent. The customer sees it in the chat widget." : `Reply (sending through ${CHANNEL_META[c.channel as Channel]?.label} requires the channel to be connected)`}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) sendReply(e as unknown as React.FormEvent);
            }}
          />
          <div className="mt-2 flex items-center justify-between">
            <p className="text-[11px] text-slate-500">Ctrl + Enter to send</p>
            <Button type="submit" size="sm" loading={sending} disabled={!reply.trim()}><Send /> Send reply</Button>
          </div>
        </form>
      </div>

      {/* Side panel */}
      <aside className="w-full shrink-0 space-y-5 overflow-y-auto border-t border-white/5 p-4 scrollbar-thin xl:w-80 xl:border-l xl:border-t-0">
        <section>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Customer</p>
          <Link href={`/customers/${c.customer_id}`} className="block rounded-xl bg-white/5 p-3 hover:bg-white/10">
            <p className="text-sm text-white">{c.customers?.name}</p>
            <p className="text-xs text-slate-400">{c.customers?.email ?? "No email"}</p>
          </Link>
        </section>

        <section className="space-y-2">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">AI analysis</p>
          <div className="flex flex-wrap gap-1.5">
            {c.intent && <Badge tone="blue">Intent: {titleCase(c.intent)}</Badge>}
            {c.category && <Badge tone="slate">{titleCase(c.category)}</Badge>}
            <SentimentBadge sentiment={c.sentiment} />
            <PriorityBadge priority={c.priority} />
            {c.current_agent && <Badge tone="violet">{AGENT_META[c.current_agent as AgentKey]?.short}</Badge>}
          </div>
          {c.handoff_summary && (
            <div className="rounded-xl border border-rose-500/20 bg-rose-500/[0.06] p-3">
              <p className="mb-1 flex items-center gap-1.5 text-xs font-medium text-rose-300"><AlertTriangle className="h-3.5 w-3.5" /> Handoff summary</p>
              <p className="whitespace-pre-wrap text-xs text-slate-300">{c.handoff_summary}</p>
            </div>
          )}
        </section>

        <section className="space-y-2">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Manage</p>
          <label className="block text-xs text-slate-400">Assigned to</label>
          <Select value={c.assigned_to ?? ""} disabled={busy !== null} onChange={(e) => patch({ assigned_to: e.target.value || null }, "Assignment updated")}>
            <option value="">Unassigned</option>
            {team.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </Select>
          <label className="block text-xs text-slate-400">Priority</label>
          <Select value={c.priority} disabled={busy !== null} onChange={(e) => patch({ priority: e.target.value as Priority }, "Priority updated")}>
            {PRIORITIES.map((p) => <option key={p} value={p}>{titleCase(p)}</option>)}
          </Select>
          <div className="grid grid-cols-2 gap-2 pt-1">
            {c.status !== "resolved" ? (
              <Button size="sm" variant="secondary" loading={busy === "Conversation resolved"} onClick={() => patch({ status: "resolved" }, "Conversation resolved")}>
                <CheckCircle2 /> Resolve
              </Button>
            ) : (
              <Button size="sm" variant="secondary" loading={busy === "Conversation reopened"} onClick={() => patch({ status: "open" }, "Conversation reopened")}>
                <RotateCcw /> Reopen
              </Button>
            )}
            {c.status !== "escalated" ? (
              <Button size="sm" variant="secondary" loading={busy === "handoff"} onClick={handoff}><UserRound /> Escalate</Button>
            ) : (
              <Button size="sm" variant="secondary" loading={busy === "Returned to AI"} onClick={() => patch({ status: "open" }, "Returned to AI")}>
                <RotateCcw /> Back to AI
              </Button>
            )}
            <TicketDialog
              team={team}
              trigger="chat"
              defaults={{
                conversation_id: c.id,
                title: c.subject ?? lastCustomer?.content.slice(0, 120) ?? "Support request",
                description: c.handoff_summary ?? lastCustomer?.content ?? "",
                priority: c.priority,
                category: c.category ?? "general",
              }}
            />
            {c.channel === "web_chat" && (
              <Button size="sm" variant="ghost" asChild>
                <Link href={`/workflow?c=${c.id}`}><ExternalLink /> Workflow</Link>
              </Button>
            )}
          </div>
        </section>

        <section>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Tickets</p>
          {tickets.length === 0 ? (
            <p className="text-xs text-slate-500">No tickets linked.</p>
          ) : (
            <ul className="space-y-1.5">
              {tickets.map((t) => (
                <li key={t.id}>
                  <Link href={`/tickets?t=${t.id}`} className="flex items-center gap-2 rounded-lg bg-white/5 px-2.5 py-2 text-xs hover:bg-white/10">
                    <span className="font-mono text-electric-400">{t.ticket_number}</span>
                    <span className="flex-1 truncate text-slate-300">{t.title}</span>
                    <StatusBadge status={t.status} />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </aside>
    </div>
  );
}
