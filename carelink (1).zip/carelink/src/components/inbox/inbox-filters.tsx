"use client";
import { useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Search } from "lucide-react";
import { Select } from "@/components/ui/input";
import { CHANNEL_META, CONVERSATION_STATUSES, PRIORITIES } from "@/lib/constants";
import { titleCase } from "@/lib/utils";
import type { Channel } from "@/types";

export function InboxFilters() {
  const sp = useSearchParams();
  const router = useRouter();
  const path = usePathname();
  const [q, setQ] = useState(sp.get("q") ?? "");

  const set = (k: string, v: string) => {
    const n = new URLSearchParams(sp.toString());
    if (v) n.set(k, v);
    else n.delete(k);
    router.replace(`${path}?${n.toString()}`, { scroll: false });
  };

  useEffect(() => {
    const t = setTimeout(() => {
      if ((sp.get("q") ?? "") !== q) set("q", q);
    }, 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  return (
    <div className="space-y-2">
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search conversations"
          className="h-9 w-full rounded-xl border border-white/10 bg-navy-950/60 pl-9 pr-3 text-sm outline-none focus:border-electric-500/50"
        />
      </div>
      <div className="grid grid-cols-3 gap-2">
        <Select value={sp.get("status") ?? ""} onChange={(e) => set("status", e.target.value)} className="h-9 px-2 text-xs">
          <option value="">Status</option>
          {CONVERSATION_STATUSES.map((s) => <option key={s} value={s}>{titleCase(s)}</option>)}
        </Select>
        <Select value={sp.get("priority") ?? ""} onChange={(e) => set("priority", e.target.value)} className="h-9 px-2 text-xs">
          <option value="">Priority</option>
          {PRIORITIES.map((s) => <option key={s} value={s}>{titleCase(s)}</option>)}
        </Select>
        <Select value={sp.get("channel") ?? ""} onChange={(e) => set("channel", e.target.value)} className="h-9 px-2 text-xs">
          <option value="">Channel</option>
          {(Object.keys(CHANNEL_META) as Channel[]).map((c) => <option key={c} value={c}>{CHANNEL_META[c].label}</option>)}
        </Select>
      </div>
    </div>
  );
}
