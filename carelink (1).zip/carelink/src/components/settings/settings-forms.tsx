"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader } from "@/components/ui/card";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/fetcher";
import type { OrgSettings, Profile } from "@/types";

function useSaver() {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const save = async (url: string, json: unknown, msg = "Saved") => {
    setBusy(true);
    try {
      await api(url, { method: "PATCH", json });
      toast({ tone: "success", title: msg });
      router.refresh();
      return true;
    } catch (e) {
      toast({ tone: "error", title: "Could not save", description: (e as Error).message });
      return false;
    } finally {
      setBusy(false);
    }
  };
  return { busy, save };
}

export function ProfileForm({ profile }: { profile: Profile }) {
  const { busy, save } = useSaver();
  const [name, setName] = useState(profile.full_name);
  const [avatar, setAvatar] = useState(profile.avatar_url ?? "");
  return (
    <Card>
      <CardHeader title="Profile" description="How you appear to teammates and customers in human replies." />
      <form
        className="grid max-w-xl gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          save("/api/settings/profile", { full_name: name, avatar_url: avatar || null }, "Profile updated");
        }}
      >
        <Field label="Full name"><Input value={name} onChange={(e) => setName(e.target.value)} required /></Field>
        <Field label="Email"><Input value={profile.email} disabled /></Field>
        <Field label="Avatar URL (optional)"><Input value={avatar} onChange={(e) => setAvatar(e.target.value)} placeholder="https://…" /></Field>
        <div><Button type="submit" loading={busy}>Save profile</Button></div>
      </form>
    </Card>
  );
}

export function NotificationsForm({ prefs }: { prefs: Record<string, boolean> }) {
  const { busy, save } = useSaver();
  const [p, setP] = useState({ email_escalations: true, new_tickets: true, daily_digest: false, ...prefs });
  const rows: [keyof typeof p, string, string][] = [
    ["email_escalations", "Escalations", "When a conversation is handed to a human"],
    ["new_tickets", "New tickets", "When a ticket is created or assigned to you"],
    ["daily_digest", "Daily digest", "Summary of yesterday's support activity"],
  ];
  return (
    <Card>
      <CardHeader title="Notification preferences" description="In-app notifications always appear in the bell menu. Email delivery needs an email provider configured (see API configuration)." />
      <div className="max-w-xl space-y-3">
        {rows.map(([k, title, desc]) => (
          <div key={k} className="flex items-center justify-between rounded-xl bg-white/[0.03] px-4 py-3">
            <div><p className="text-sm text-white">{title}</p><p className="text-xs text-slate-500">{desc}</p></div>
            <Switch checked={p[k]} onCheckedChange={(v) => setP({ ...p, [k]: v })} />
          </div>
        ))}
        <Button loading={busy} onClick={() => save("/api/settings/profile", { notification_prefs: p }, "Preferences saved")}>Save preferences</Button>
      </div>
    </Card>
  );
}

export function ThemeForm({ theme }: { theme: string }) {
  const { busy, save } = useSaver();
  const [t, setT] = useState(theme);
  const options = [
    { v: "dark", l: "Aurora (default)", d: "Navy with blue and purple glow" },
    { v: "midnight", l: "Midnight", d: "Flat navy, no background gradients" },
  ];
  return (
    <Card>
      <CardHeader title="Theme" />
      <div className="grid max-w-xl gap-3 sm:grid-cols-2">
        {options.map((o) => (
          <button
            key={o.v}
            onClick={() => setT(o.v)}
            className={`rounded-2xl border p-4 text-left transition ${t === o.v ? "border-electric-500/60 bg-electric-500/10" : "border-white/10 bg-white/[0.02] hover:bg-white/5"}`}
          >
            <div className={`mb-3 h-16 rounded-xl ${o.v === "dark" ? "bg-gradient-to-br from-electric-600/40 via-navy-800 to-violet-600/40" : "bg-navy-900"}`} />
            <p className="flex items-center gap-2 text-sm text-white">{o.l}{t === o.v && <Check className="h-4 w-4 text-electric-400" />}</p>
            <p className="text-xs text-slate-500">{o.d}</p>
          </button>
        ))}
      </div>
      <Button className="mt-4" loading={busy} onClick={() => save("/api/settings/profile", { theme: t }, "Theme saved")}>Apply theme</Button>
    </Card>
  );
}

export function AiConfigForm({ name, settings, isAdmin, models, aiConfigured }: { name: string; settings: OrgSettings; isAdmin: boolean; models: { main: string; fast: string }; aiConfigured: boolean }) {
  const { busy, save } = useSaver();
  const [s, setS] = useState(settings);
  const [org, setOrg] = useState(name);
  return (
    <Card>
      <CardHeader title="AI configuration" description="Controls how the agents write and when they hand off to humans." />
      <form
        className="grid max-w-2xl gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          save("/api/settings/org", { name: org, settings: s }, "AI settings saved");
        }}
      >
        <Field label="Organization name" hint="Agents introduce your company with this name."><Input value={org} onChange={(e) => setOrg(e.target.value)} disabled={!isAdmin} /></Field>
        <Field label="Company description" hint="One or two sentences about what you sell or do. Helps the agents answer general questions.">
          <Textarea rows={3} value={s.company_description} onChange={(e) => setS({ ...s, company_description: e.target.value })} disabled={!isAdmin} />
        </Field>
        <Field label="Tone of voice"><Input value={s.tone} onChange={(e) => setS({ ...s, tone: e.target.value })} disabled={!isAdmin} /></Field>
        <Field label={`Escalation confidence threshold: ${s.confidence_threshold.toFixed(2)}`} hint="If a specialist agent is less confident than this, the conversation goes to a human.">
          <input type="range" min={0.3} max={0.95} step={0.05} value={s.confidence_threshold} onChange={(e) => setS({ ...s, confidence_threshold: Number(e.target.value) })} disabled={!isAdmin} className="w-full accent-electric-500" />
        </Field>
        <div className="flex items-center justify-between rounded-xl bg-white/[0.03] px-4 py-3">
          <div><p className="text-sm text-white">Auto-escalate frustrated customers</p><p className="text-xs text-slate-500">Follow the Sentiment Agent&apos;s escalation recommendation.</p></div>
          <Switch checked={s.auto_escalate_negative} onCheckedChange={(v) => setS({ ...s, auto_escalate_negative: v })} disabled={!isAdmin} />
        </div>
        <div className="grid grid-cols-2 gap-3 rounded-xl bg-white/[0.03] p-4 text-xs">
          <div><p className="text-slate-500">Response model</p><p className="font-mono text-slate-200">{models.main}</p></div>
          <div><p className="text-slate-500">Classification model</p><p className="font-mono text-slate-200">{models.fast}</p></div>
          <div className="col-span-2"><p className="text-slate-500">API key</p><p className={aiConfigured ? "text-emerald-300" : "text-amber-300"}>{aiConfigured ? "ANTHROPIC_API_KEY is set on the server" : "ANTHROPIC_API_KEY is missing"}</p></div>
        </div>
        {isAdmin ? <div><Button type="submit" loading={busy}>Save AI settings</Button></div> : <p className="text-xs text-slate-500">Only admins can change AI settings.</p>}
      </form>
    </Card>
  );
}

export function CopyField({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Field label={label}>
      <div className="flex gap-2">
        <Input readOnly value={value} className="font-mono text-xs" />
        <Button
          type="button"
          variant="secondary"
          size="icon"
          aria-label="Copy"
          onClick={() => {
            navigator.clipboard?.writeText(value).catch(() => {});
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
          }}
        >
          {copied ? <Check /> : <Copy />}
        </Button>
      </div>
    </Field>
  );
}

export function ChannelCard({
  channel,
  label,
  status,
  enabled,
  config,
  fields,
  envVars,
  webhookUrl,
  isAdmin,
  docs,
}: {
  channel: string;
  label: string;
  status: string;
  enabled: boolean;
  config: Record<string, string>;
  fields: { key: string; label: string; placeholder?: string }[];
  envVars: { name: string; set: boolean }[];
  webhookUrl: string | null;
  isAdmin: boolean;
  docs: string;
}) {
  const { busy, save } = useSaver();
  const [cfg, setCfg] = useState<Record<string, string>>(config ?? {});
  const [on, setOn] = useState(enabled);
  const missing = envVars.filter((e) => !e.set);
  const statusLabel = status === "connected" ? "Connected" : status === "pending_verification" ? "Waiting for credentials" : "Not configured";
  const statusColor = status === "connected" ? "text-emerald-300" : status === "pending_verification" ? "text-amber-300" : "text-slate-400";

  return (
    <Card>
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-base font-semibold text-white">{label}</h3>
          <p className={`text-xs ${statusColor}`}>{statusLabel}</p>
        </div>
        <Switch
          checked={on}
          disabled={!isAdmin || busy || (missing.length > 0 && !on)}
          title={missing.length ? "Add the required server credentials first" : undefined}
          onCheckedChange={async (v) => {
            const ok = await save(`/api/settings/channels/${channel}`, { enabled: v }, v ? `${label} enabled` : `${label} disabled`);
            if (ok) setOn(v);
          }}
        />
      </div>
      <p className="mt-2 text-xs text-slate-400">{docs}</p>
      {envVars.length > 0 && (
        <div className="mt-3 rounded-xl bg-white/[0.03] p-3">
          <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Server credentials (.env)</p>
          <ul className="space-y-1 text-xs">
            {envVars.map((e) => (
              <li key={e.name} className="flex justify-between"><code className="text-slate-300">{e.name}</code><span className={e.set ? "text-emerald-300" : "text-rose-300"}>{e.set ? "set" : "missing"}</span></li>
            ))}
          </ul>
        </div>
      )}
      {webhookUrl && <div className="mt-3"><CopyField label="Webhook URL" value={webhookUrl} /></div>}
      {fields.length > 0 && (
        <form
          className="mt-3 space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            save(`/api/settings/channels/${channel}`, { config: cfg }, "Channel settings saved");
          }}
        >
          {fields.map((f) => (
            <Field key={f.key} label={f.label}>
              <Input value={cfg[f.key] ?? ""} onChange={(e) => setCfg({ ...cfg, [f.key]: e.target.value })} placeholder={f.placeholder} disabled={!isAdmin} />
            </Field>
          ))}
          {isAdmin && <Button size="sm" variant="secondary" type="submit" loading={busy}>Save settings</Button>}
        </form>
      )}
    </Card>
  );
}

export function SelectTab({ tabs, active }: { tabs: { id: string; label: string }[]; active: string }) {
  const router = useRouter();
  return (
    <Select value={active} onChange={(e) => router.replace(`/settings?tab=${e.target.value}`)} className="md:hidden">
      {tabs.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
    </Select>
  );
}
