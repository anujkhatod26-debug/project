"use client";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { FileUp, UploadCloud } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";

export function UploadDialog() {
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("general");
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const toast = useToast();

  async function upload(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("title", title || file.name.replace(/\.[^.]+$/, ""));
      fd.append("category", category);
      const res = await fetch("/api/knowledge/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Upload failed");
      toast({ tone: "success", title: "Document indexed", description: `${data.characters.toLocaleString()} characters of text are now searchable by the agents.` });
      setOpen(false);
      setFile(null);
      setTitle("");
      router.refresh();
    } catch (err) {
      toast({ tone: "error", title: "Upload failed", description: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button variant="secondary"><UploadCloud /> Upload document</Button></DialogTrigger>
      <DialogContent title="Upload a document" description="PDF, TXT, MD or CSV up to 10 MB. The file is stored in Supabase Storage and its text is indexed for search.">
        <form onSubmit={upload} className="space-y-4">
          <button
            type="button"
            onClick={() => input.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              const f = e.dataTransfer.files?.[0];
              if (f) setFile(f);
            }}
            className="flex w-full flex-col items-center justify-center rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-4 py-8 text-center hover:border-electric-500/50"
          >
            <FileUp className="h-7 w-7 text-electric-400" />
            <p className="mt-2 text-sm text-slate-200">{file ? file.name : "Click or drop a file here"}</p>
            {file && <p className="text-xs text-slate-500">{(file.size / 1024).toFixed(0)} KB</p>}
          </button>
          <input ref={input} type="file" accept=".pdf,.txt,.md,.markdown,.csv,application/pdf,text/plain" className="hidden" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          <Field label="Title"><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Defaults to the file name" /></Field>
          <Field label="Category"><Input value={category} onChange={(e) => setCategory(e.target.value)} /></Field>
          <div className="flex justify-end"><Button type="submit" loading={busy} disabled={!file}>Upload & index</Button></div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
