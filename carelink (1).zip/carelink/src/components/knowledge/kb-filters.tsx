"use client";
import { useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Input, Select } from "@/components/ui/input";
import { titleCase } from "@/lib/utils";

export function KbFilters({ categories }: { categories: string[] }) {
  const sp = useSearchParams();
  const router = useRouter();
  const path = usePathname();
  const [q, setQ] = useState(sp.get("q") ?? "");
  const set = (k: string, v: string) => {
    const n = new URLSearchParams(sp.toString());
    if (v) n.set(k, v);
    else n.delete(k);
    router.replace(`${path}?${n.toString()}`, { scroll: false });
  };
  useEffect(() => {
    const t = setTimeout(() => {
      if ((sp.get("q") ?? "") !== q) set("q", q);
    }, 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);
  return (
    <div className="flex flex-col gap-2 sm:flex-row">
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search knowledge (same search the agents use)" className="sm:max-w-md" />
      <Select value={sp.get("category") ?? ""} onChange={(e) => set("category", e.target.value)} className="sm:w-44">
        <option value="">All categories</option>
        {categories.map((c) => <option key={c} value={c}>{titleCase(c)}</option>)}
      </Select>
      <Select value={sp.get("type") ?? ""} onChange={(e) => set("type", e.target.value)} className="sm:w-36">
        <option value="">FAQs & docs</option>
        <option value="faq">FAQs</option>
        <option value="document">Documents</option>
      </Select>
    </div>
  );
}
