"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ChevronDown, Download, FileText, HelpCircle, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ui/dialog";
import { Badge, DemoBadge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/toast";
import { ArticleDialog } from "./article-dialog";
import { api } from "@/lib/fetcher";
import { cn, formatDate, titleCase } from "@/lib/utils";
import type { KnowledgeArticle } from "@/types";

export function ArticleList({ articles, canEdit }: { articles: KnowledgeArticle[]; canEdit: boolean }) {
  const [open, setOpen] = useState<string | null>(null);
  const router = useRouter();
  const toast = useToast();

  return (
    <ul className="divide-y divide-white/5">
      {articles.map((a) => (
        <li key={a.id} className="px-5 py-4">
          <div className="flex items-start gap-3">
            <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/5">
              {a.type === "document" ? <FileText className="h-4 w-4 text-violet-300" /> : <HelpCircle className="h-4 w-4 text-electric-400" />}
            </div>
            <button className="min-w-0 flex-1 text-left" onClick={() => setOpen(open === a.id ? null : a.id)}>
              <div className="flex flex-wrap items-center gap-2">
                <p className="font-medium text-white">{a.title}</p>
                <Badge tone="slate">{titleCase(a.category)}</Badge>
                <Badge tone={a.type === "document" ? "violet" : "blue"}>{a.type === "document" ? "Document" : "FAQ"}</Badge>
                {a.is_demo && <DemoBadge />}
                <ChevronDown className={cn("h-4 w-4 text-slate-500 transition", open === a.id && "rotate-180")} />
              </div>
              <p className={cn("mt-1 whitespace-pre-wrap text-sm text-slate-400", open === a.id ? "" : "line-clamp-2")}>
                {open === a.id ? a.content.slice(0, 6000) + (a.content.length > 6000 ? "\n…" : "") : a.content}
              </p>
              <p className="mt-1.5 text-[11px] text-slate-500">
                {a.tags.length > 0 && <>Tags: {a.tags.join(", ")} · </>}
                {a.file_name && <>{a.file_name} · </>}
                Updated {formatDate(a.updated_at)}
              </p>
            </button>
            <div className="flex shrink-0 gap-1">
              {a.file_path && (
                <Button variant="ghost" size="icon" asChild aria-label="Download original">
                  <a href={`/api/knowledge/${a.id}/file`} target="_blank" rel="noreferrer"><Download /></a>
                </Button>
              )}
              {canEdit && a.type === "faq" && <ArticleDialog article={a} />}
              {canEdit && (
                <ConfirmDialog
                  title="Delete this article?"
                  description={`"${a.title}" will be removed${a.file_path ? " along with its stored file" : ""}. Agents will stop using it immediately.`}
                  onConfirm={async () => {
                    try {
                      await api(`/api/knowledge/${a.id}`, { method: "DELETE" });
                      toast({ tone: "success", title: "Article deleted" });
                      router.refresh();
                    } catch (e) {
                      toast({ tone: "error", title: "Delete failed", description: (e as Error).message });
                    }
                  }}
                  trigger={<Button variant="ghost" size="icon" aria-label="Delete"><Trash2 className="text-rose-400" /></Button>}
                />
              )}
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}
