"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Pencil, Plus } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/fetcher";
import type { KnowledgeArticle } from "@/types";

export function ArticleDialog({ article }: { article?: KnowledgeArticle }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const toast = useToast();
  const [form, setForm] = useState({
    title: article?.title ?? "",
    category: article?.category ?? "general",
    tags: article?.tags.join(", ") ?? "",
    content: article?.content ?? "",
  });

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const body = {
        title: form.title,
        category: form.category.trim().toLowerCase() || "general",
        tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean),
        content: form.content,
      };
      if (article) await api(`/api/knowledge/${article.id}`, { method: "PATCH", json: body });
      else await api("/api/knowledge", { method: "POST", json: body });
      toast({ tone: "success", title: article ? "Article updated" : "FAQ added", description: "Agents will use it on the next message." });
      setOpen(false);
      if (!article) setForm({ title: "", category: "general", tags: "", content: "" });
      router.refresh();
    } catch (err) {
      toast({ tone: "error", title: "Could not save", description: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {article ? <Button variant="ghost" size="icon" aria-label="Edit"><Pencil /></Button> : <Button><Plus /> New FAQ</Button>}
      </DialogTrigger>
      <DialogContent title={article ? "Edit article" : "New FAQ entry"} description="Write facts and policies the AI agents may quote. Agents never invent policies that aren't here." className="max-w-2xl">
        <form onSubmit={save} className="space-y-4">
          <Field label="Question / title"><Input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="What is your refund policy?" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Category"><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="billing" /></Field>
            <Field label="Tags (comma separated)"><Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="refund, returns" /></Field>
          </div>
          <Field label="Answer / content"><Textarea required rows={10} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} /></Field>
          <div className="flex justify-end"><Button type="submit" loading={busy}>Save</Button></div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
