"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { FlaskConical, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/fetcher";

export function LoadDemoButton({ label = "Load demo data", variant = "default" }: { label?: string; variant?: "default" | "secondary" }) {
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const toast = useToast();
  return (
    <Button
      variant={variant}
      loading={busy}
      onClick={async () => {
        setBusy(true);
        try {
          const r = await api<{ counts: Record<string, number> }>("/api/demo", { method: "POST" });
          toast({ tone: "success", title: "Demo data loaded", description: `${r.counts.conversations} conversations, ${r.counts.tickets} tickets, ${r.counts.knowledge_articles} KB articles` });
          router.refresh();
        } catch (e) {
          toast({ tone: "error", title: "Could not load demo data", description: (e as Error).message });
        } finally {
          setBusy(false);
        }
      }}
    >
      <FlaskConical /> {label}
    </Button>
  );
}

export function ClearDemoButton() {
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const toast = useToast();
  return (
    <Button
      variant="secondary"
      loading={busy}
      onClick={async () => {
        if (!confirm("Remove all demo records? Your real data is not affected.")) return;
        setBusy(true);
        try {
          await api("/api/demo", { method: "DELETE" });
          toast({ tone: "success", title: "Demo data removed" });
          router.refresh();
        } catch (e) {
          toast({ tone: "error", title: "Could not remove demo data", description: (e as Error).message });
        } finally {
          setBusy(false);
        }
      }}
    >
      <Trash2 /> Remove demo data
    </Button>
  );
}
