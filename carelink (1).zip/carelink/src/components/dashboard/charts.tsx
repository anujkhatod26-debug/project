"use client";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { titleCase } from "@/lib/utils";

const AXIS = { stroke: "rgba(148,163,184,0.35)", fontSize: 11, tickLine: false, axisLine: false } as const;
const GRID = <CartesianGrid stroke="rgba(148,163,184,0.08)" vertical={false} />;
const TIP = { contentStyle: { fontSize: 12 }, labelStyle: { color: "#e2e8f0" }, cursor: { fill: "rgba(59,130,246,0.06)" } };

const shortDate = (d: string) => new Date(d + "T00:00:00").toLocaleDateString("en-IN", { day: "2-digit", month: "short" });

export function ActivityChart({ data }: { data: { date: string; conversations: number; aiResolved: number; escalated: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <AreaChart data={data} margin={{ left: -20, right: 8, top: 8 }}>
        <defs>
          <linearGradient id="gConv" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.45} />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="gAi" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.4} />
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0} />
          </linearGradient>
        </defs>
        {GRID}
        <XAxis dataKey="date" tickFormatter={shortDate} {...AXIS} minTickGap={20} />
        <YAxis allowDecimals={false} {...AXIS} />
        <Tooltip {...TIP} labelFormatter={(l) => shortDate(String(l))} />
        <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
        <Area type="monotone" dataKey="conversations" name="Conversations" stroke="#3b82f6" strokeWidth={2} fill="url(#gConv)" />
        <Area type="monotone" dataKey="aiResolved" name="AI resolved" stroke="#8b5cf6" strokeWidth={2} fill="url(#gAi)" />
        <Area type="monotone" dataKey="escalated" name="Escalated" stroke="#fb7185" strokeWidth={1.5} fill="transparent" />
      </AreaChart>
    </ResponsiveContainer>
  );
}

const STATUS_COLORS: Record<string, string> = {
  open: "#3b82f6",
  in_progress: "#8b5cf6",
  pending: "#f59e0b",
  resolved: "#10b981",
  escalated: "#f43f5e",
};

export function StatusDonut({ data }: { data: { status: string; count: number }[] }) {
  const total = data.reduce((a, b) => a + b.count, 0);
  if (total === 0) return <p className="py-16 text-center text-xs text-slate-500">No tickets in this period.</p>;
  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row">
      <div className="relative h-48 w-48 shrink-0">
        <ResponsiveContainer>
          <PieChart>
            <Pie data={data.filter((d) => d.count > 0)} dataKey="count" nameKey="status" innerRadius={58} outerRadius={84} paddingAngle={3} stroke="none">
              {data.filter((d) => d.count > 0).map((d) => (
                <Cell key={d.status} fill={STATUS_COLORS[d.status] ?? "#64748b"} />
              ))}
            </Pie>
            <Tooltip {...TIP} formatter={(v, n) => [v, titleCase(String(n))]} />
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-2xl font-semibold text-white">{total}</span>
          <span className="text-[11px] text-slate-500">tickets</span>
        </div>
      </div>
      <ul className="w-full space-y-2 text-sm">
        {data.map((d) => (
          <li key={d.status} className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: STATUS_COLORS[d.status] }} />
            <span className="flex-1 text-slate-300">{titleCase(d.status)}</span>
            <span className="font-medium text-white">{d.count}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function AgentPerformanceChart({ data }: { data: { name: string; tasks: number; successRate: number | null }[] }) {
  const rows = data.map((d) => ({ ...d, short: d.name.replace(" Agent", "").replace("Query ", ""), success: d.successRate == null ? 0 : Math.round(d.successRate * 100) }));
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={rows} margin={{ left: -20, right: 8, top: 8 }}>
        {GRID}
        <XAxis dataKey="short" {...AXIS} interval={0} angle={-20} textAnchor="end" height={50} />
        <YAxis yAxisId="l" allowDecimals={false} {...AXIS} />
        <YAxis yAxisId="r" orientation="right" domain={[0, 100]} {...AXIS} unit="%" />
        <Tooltip {...TIP} />
        <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
        <Bar yAxisId="l" dataKey="tasks" name="Tasks handled" fill="#3b82f6" radius={[6, 6, 0, 0]} />
        <Bar yAxisId="r" dataKey="success" name="Success %" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function TrendLineChart({ data, xKey }: { data: Record<string, string | number>[]; xKey: string }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart data={data} margin={{ left: -20, right: 8, top: 8 }}>
        {GRID}
        <XAxis dataKey={xKey} tickFormatter={(v) => shortDate(String(v))} {...AXIS} minTickGap={16} />
        <YAxis allowDecimals={false} {...AXIS} />
        <Tooltip {...TIP} labelFormatter={(l) => (xKey === "week" ? "Week of " : "") + shortDate(String(l))} />
        <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
        <Line type="monotone" dataKey="conversations" name="Conversations" stroke="#3b82f6" strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="aiResolved" name="AI resolved" stroke="#8b5cf6" strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="escalated" name="Human escalated" stroke="#fb7185" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function HorizontalBars({ data, color = "#3b82f6" }: { data: { label: string; value: number }[]; color?: string }) {
  if (data.length === 0) return <p className="py-16 text-center text-xs text-slate-500">No data in this period.</p>;
  return (
    <ResponsiveContainer width="100%" height={Math.max(160, data.length * 38)}>
      <BarChart data={data} layout="vertical" margin={{ left: 10, right: 16 }}>
        <XAxis type="number" allowDecimals={false} {...AXIS} />
        <YAxis type="category" dataKey="label" width={130} {...AXIS} tick={{ fill: "#cbd5e1", fontSize: 11 }} />
        <Tooltip {...TIP} />
        <Bar dataKey="value" name="Count" fill={color} radius={[0, 6, 6, 0]} barSize={18} />
      </BarChart>
    </ResponsiveContainer>
  );
}
