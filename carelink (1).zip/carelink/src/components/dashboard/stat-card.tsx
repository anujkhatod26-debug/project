import type { LucideIcon } from "lucide-react";

export function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  accent = "#3b82f6",
  index = 0,
}: {
  label: string;
  value: string;
  sub?: string;
  icon: LucideIcon;
  accent?: string;
  index?: number;
}) {
  return (
    <div className="glass relative animate-[fadeUp_0.4s_ease-out_both] overflow-hidden p-4" style={{ animationDelay: `${index * 40}ms` }}>
      <div className="absolute -right-6 -top-6 h-20 w-20 rounded-full opacity-20 blur-2xl" style={{ background: accent }} />
      <div className="flex items-center justify-between">
        <p className="text-xs text-slate-400">{label}</p>
        <div className="rounded-lg p-1.5" style={{ background: `${accent}22` }}>
          <Icon className="h-4 w-4" style={{ color: accent }} />
        </div>
      </div>
      <p className="mt-2 font-display text-2xl font-semibold text-white">{value}</p>
      {sub && <p className="mt-0.5 text-[11px] text-slate-500">{sub}</p>}
    </div>
  );
}
