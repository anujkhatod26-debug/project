"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Pencil } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/fetcher";
import type { Customer } from "@/types";

export function CustomerDialog({ customer }: { customer?: Customer }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    name: customer?.name ?? "",
    email: customer?.email ?? "",
    phone: customer?.phone ?? "",
    notes: customer?.notes ?? "",
  });
  const router = useRouter();
  const toast = useToast();

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const body = { name: form.name, email: form.email || null, phone: form.phone || null, notes: form.notes || null };
      if (customer) await api(`/api/customers/${customer.id}`, { method: "PATCH", json: body });
      else await api("/api/customers", { method: "POST", json: body });
      toast({ tone: "success", title: customer ? "Customer updated" : "Customer added" });
      setOpen(false);
      router.refresh();
    } catch (err) {
      toast({ tone: "error", title: "Could not save", description: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {customer ? <Button variant="secondary" size="sm"><Pencil /> Edit</Button> : <Button><Plus /> Add customer</Button>}
      </DialogTrigger>
      <DialogContent title={customer ? "Edit customer" : "Add customer"}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Name"><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Email"><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
          <Field label="Phone"><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
          <Field label="Internal notes"><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
          <div className="flex justify-end"><Button type="submit" loading={busy}>Save</Button></div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
