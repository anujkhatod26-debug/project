"use client";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Input, Select } from "@/components/ui/input";

export function CustomerFilters() {
  const router = useRouter();
  const path = usePathname();
  const sp = useSearchParams();
  const [q, setQ] = useState(sp.get("q") ?? "");

  const push = (k: string, v: string) => {
    const next = new URLSearchParams(sp.toString());
    if (v) next.set(k, v);
    else next.delete(k);
    router.replace(`${path}?${next.toString()}`);
  };

  useEffect(() => {
    const t = setTimeout(() => {
      if ((sp.get("q") ?? "") !== q) push("q", q);
    }, 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  return (
    <div className="flex flex-col gap-2 sm:flex-row">
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or email" className="sm:max-w-xs" />
      <Select value={sp.get("sentiment") ?? ""} onChange={(e) => push("sentiment", e.target.value)} className="sm:w-48">
        <option value="">All sentiments</option>
        <option value="positive">Positive</option>
        <option value="neutral">Neutral</option>
        <option value="negative">Negative</option>
        <option value="very_negative">Very negative</option>
      </Select>
    </div>
  );
}
