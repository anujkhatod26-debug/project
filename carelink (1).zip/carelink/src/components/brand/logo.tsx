import { cn } from "@/lib/utils";

export function Logo({ className, withText = true }: { className?: string; withText?: boolean }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-electric-500 to-violet-600 shadow-glow">
        <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round">
          <path d="M9 7.5a4.5 4.5 0 1 0 0 9" />
          <path d="M15 7.5a4.5 4.5 0 1 1 0 9" />
          <path d="M9 12h6" />
        </svg>
      </div>
      {withText && (
        <div className="leading-tight">
          <p className="font-display text-lg font-semibold tracking-tight text-white">CareLink</p>
        </div>
      )}
    </div>
  );
}
