"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Bot, ExternalLink, RotateCcw, Send, Sparkles, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge, PriorityBadge, SentimentBadge, StatusBadge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/toast";
import { TicketDialog, type Option } from "@/components/tickets/ticket-dialog";
import { EscalationCard, WorkflowVisual, type StepState } from "./workflow-visual";
import { AGENT_META, SAMPLE_MESSAGES } from "@/lib/constants";
import { api } from "@/lib/fetcher";
import { cn, titleCase } from "@/lib/utils";
import type { AgentKey, Message, Priority } from "@/types";

interface ChatMessage {
  id: string;
  sender: "customer" | "ai" | "human" | "system";
  author: string;
  content: string;
  at: string;
  agentKey?: string | null;
  confidence?: number | null;
  sources?: { id: string; title: string }[];
}

interface FinalInfo {
  escalated: boolean;
  escalationReasons: string[];
  assignedTo: { name: string } | null;
  intent?: string | null;
  priority?: Priority;
  sentiment?: string | null;
  agent?: string;
  confidence?: number | null;
  ticketId?: string | null;
}

function toChat(m: Message): ChatMessage {
  const meta = m.metadata as { confidence?: number; sources?: { id: string; title: string }[] };
  return {
    id: m.id,
    sender: m.sender,
    author: m.sender === "ai" ? AGENT_META[m.agent_key as AgentKey]?.name ?? "AI" : m.author_name ?? m.sender,
    content: m.content,
    at: m.created_at,
    agentKey: m.agent_key,
    confidence: meta?.confidence ?? null,
    sources: meta?.sources ?? [],
  };
}

const time = (iso: string) => new Date(iso).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });

export function LiveChat({
  team,
  initialConversation,
  initialMessages,
  aiConfigured,
}: {
  team: Option[];
  initialConversation: { id: string; status: string; customerName: string; customerEmail: string | null; priority: Priority; sentiment: string | null; intent: string | null; subject: string | null } | null;
  initialMessages: Message[];
  aiConfigured: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [conversationId, setConversationId] = useState<string | null>(initialConversation?.id ?? null);
  const [status, setStatus] = useState(initialConversation?.status ?? "open");
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages.map(toChat));
  const [customerName, setCustomerName] = useState(initialConversation?.customerName ?? "Demo Customer");
  const [customerEmail, setCustomerEmail] = useState(initialConversation?.customerEmail ?? "");
  const [input, setInput] = useState("");
  const [running, setRunning] = useState(false);
  const [steps, setSteps] = useState<Record<number, StepState>>({});
  const [activeKey, setActiveKey] = useState<string | null>(null);
  const [final, setFinal] = useState<FinalInfo | null>(null);
  const [handingOff, setHandingOff] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [messages, running]);

  function reset() {
    setConversationId(null);
    setMessages([]);
    setSteps({});
    setFinal(null);
    setActiveKey(null);
    setStatus("open");
    router.replace("/workflow");
  }

  async function send(text: string) {
    const content = text.trim();
    if (!content || running) return;
    setInput("");
    setRunning(true);
    setSteps({});
    setFinal(null);
    const tempId = `tmp-${Date.now()}`;
    setMessages((m) => [...m, { id: tempId, sender: "customer", author: customerName || "Customer", content, at: new Date().toISOString() }]);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: conversationId ?? undefined,
          customerName: conversationId ? undefined : customerName || undefined,
          customerEmail: conversationId ? undefined : customerEmail || undefined,
          message: content,
        }),
      });
      if (!res.ok || !res.body) {
        const err = await res.json().catch(() => ({}));
        throw new Error((err as { error?: string }).error ?? `Request failed (${res.status})`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.trim()) continue;
          handleEvent(JSON.parse(line));
        }
      }
      if (buffer.trim()) handleEvent(JSON.parse(buffer));
    } catch (err) {
      toast({ tone: "error", title: "Message failed", description: (err as Error).message });
      setMessages((m) => [...m, { id: `err-${Date.now()}`, sender: "system", author: "CareLink", content: `Could not process the message: ${(err as Error).message}`, at: new Date().toISOString() }]);
    } finally {
      setRunning(false);
      setActiveKey(null);
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  function handleEvent(e: any) {
    if (e.type === "conversation") {
      setConversationId(e.conversationId);
      window.history.replaceState(null, "", `/workflow?c=${e.conversationId}`);
    } else if (e.type === "step") {
      setActiveKey(e.key);
      setSteps((s) => ({ ...s, [e.step]: { step: e.step, key: e.key, title: e.title, status: e.status, detail: e.detail, output: e.output, confidence: e.confidence, latencyMs: e.latencyMs } }));
    } else if (e.type === "final") {
      const f = e.final;
      if (f.humanMode) {
        setFinal({ escalated: true, escalationReasons: f.escalationReasons, assignedTo: null });
        setMessages((m) => [...m, { id: `sys-${Date.now()}`, sender: "system", author: "CareLink", content: "Message delivered. This conversation is with a human representative, so the AI agents are paused. Reply from the Omnichannel Inbox.", at: new Date().toISOString() }]);
        return;
      }
      setFinal({
        escalated: f.escalated,
        escalationReasons: f.escalationReasons,
        assignedTo: f.assignedTo,
        intent: f.intent,
        priority: f.priority,
        sentiment: f.sentiment,
        agent: f.agentName,
        confidence: f.confidence,
        ticketId: f.ticketId,
      });
      setStatus(f.escalated ? "escalated" : "open");
      setMessages((m) => [
        ...m,
        { id: f.messageId ?? `ai-${Date.now()}`, sender: f.agent === "system" ? "system" : "ai", author: f.agentName, content: f.reply, at: new Date().toISOString(), agentKey: f.agent, confidence: f.confidence },
      ]);
    } else if (e.type === "error") {
      toast({ tone: "error", title: "Workflow error", description: e.message });
    }
  }

  async function requestHuman() {
    if (!conversationId) return;
    setHandingOff(true);
    try {
      const r = await api<{ reply: string; agentName: string; assignedTo: { name: string } | null; escalationReasons: string[]; agent: string }>(
        `/api/conversations/${conversationId}/handoff`,
        { method: "POST" }
      );
      setMessages((m) => [...m, { id: `h-${Date.now()}`, sender: r.agent === "system" ? "system" : "ai", author: r.agentName, content: r.reply, at: new Date().toISOString(), agentKey: r.agent }]);
      setFinal((f) => ({ ...(f ?? {}), escalated: true, escalationReasons: r.escalationReasons, assignedTo: r.assignedTo }));
      setStatus("escalated");
      toast({ tone: "success", title: "Transferred to human support", description: r.assignedTo ? `Assigned to ${r.assignedTo.name}` : "No one is available right now; it's in the escalation queue." });
    } catch (err) {
      toast({ tone: "error", title: "Handoff failed", description: (err as Error).message });
    } finally {
      setHandingOff(false);
    }
  }

  const lastCustomer = [...messages].reverse().find((m) => m.sender === "customer");

  return (
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      {/* ---------------- Chat */}
      <Card className="flex h-[calc(100vh-11rem)] min-h-[560px] flex-col p-0">
        <div className="flex flex-wrap items-center gap-2 border-b border-white/5 p-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-electric-500/15"><Bot className="h-5 w-5 text-electric-400" /></div>
          <div className="mr-auto">
            <p className="text-sm font-semibold text-white">Live AI Chat</p>
            <p className="text-[11px] text-slate-500">{conversationId ? `Conversation with ${customerName}` : "You are the customer. Messages run through all agents."}</p>
          </div>
          {conversationId && <StatusBadge status={status} />}
          {conversationId && (
            <TicketDialog
              team={team}
              trigger="chat"
              defaults={{
                conversation_id: conversationId,
                title: lastCustomer?.content.slice(0, 120) ?? "Support request",
                description: messages.map((m) => `${m.author}: ${m.content}`).join("\n").slice(0, 4000),
                priority: final?.priority ?? "medium",
                category: final?.intent ?? "general",
              }}
            />
          )}
          {conversationId && status !== "escalated" && (
            <Button size="sm" variant="secondary" onClick={requestHuman} loading={handingOff}><UserRound /> Request human</Button>
          )}
          {conversationId && (
            <Button size="sm" variant="ghost" onClick={() => router.push(`/inbox?c=${conversationId}`)}><ExternalLink /> Inbox</Button>
          )}
          <Button size="sm" variant="ghost" onClick={reset} disabled={running}><RotateCcw /> New</Button>
        </div>

        {!conversationId && (
          <div className="grid grid-cols-2 gap-2 border-b border-white/5 p-4">
            <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Customer name" />
            <Input type="email" value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} placeholder="Customer email (optional)" />
          </div>
        )}

        <div ref={scroller} className="flex-1 space-y-4 overflow-y-auto p-4 scrollbar-thin">
          {messages.length === 0 && (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <Sparkles className="h-8 w-8 text-electric-400" />
              <p className="mt-3 font-display text-base font-semibold text-white">Try one of these customer messages</p>
              <p className="mt-1 max-w-sm text-xs text-slate-400">Each message is classified, routed to the right agent and answered by Claude. Watch every step on the right.</p>
              {!aiConfigured && <p className="mt-3 max-w-sm rounded-lg bg-amber-500/10 px-3 py-2 text-xs text-amber-200">ANTHROPIC_API_KEY is not set, so messages will be routed straight to humans.</p>}
            </div>
          )}
          <AnimatePresence initial={false}>
            {messages.map((m) => (
              <motion.div key={m.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={cn("flex", m.sender === "customer" ? "justify-end" : "justify-start")}>
                <div className={cn("max-w-[85%]", m.sender === "customer" && "text-right")}>
                  <div className={cn("mb-1 flex items-center gap-1.5 text-[11px] text-slate-500", m.sender === "customer" && "justify-end")}>
                    {m.sender === "ai" && <span className="h-1.5 w-1.5 rounded-full" style={{ background: AGENT_META[m.agentKey as AgentKey]?.color ?? "#60a5fa" }} />}
                    <span className="font-medium text-slate-300">{m.author}</span>
                    <span>· {time(m.at)}</span>
                    {typeof m.confidence === "number" && <span>· {Math.round(m.confidence * 100)}% confident</span>}
                  </div>
                  <div
                    className={cn(
                      "inline-block whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-left text-sm leading-relaxed",
                      m.sender === "customer" && "rounded-br-md bg-gradient-to-br from-electric-600 to-violet-600 text-white",
                      m.sender === "ai" && "rounded-bl-md border border-white/5 bg-white/[0.04] text-slate-100",
                      m.sender === "human" && "rounded-bl-md border border-emerald-500/20 bg-emerald-500/10 text-slate-100",
                      m.sender === "system" && "rounded-bl-md border border-amber-500/20 bg-amber-500/10 text-amber-100"
                    )}
                  >
                    {m.content}
                  </div>
                  {m.sources && m.sources.length > 0 && (
                    <p className="mt-1 text-[11px] text-slate-500">Sources: {m.sources.map((s) => s.title).join(", ")}</p>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {running && (
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <div className="flex gap-1 rounded-2xl rounded-bl-md border border-white/5 bg-white/[0.04] px-4 py-3">
                {[0, 1, 2].map((i) => <span key={i} className="h-1.5 w-1.5 animate-pulseDot rounded-full bg-electric-400" style={{ animationDelay: `${i * 0.2}s` }} />)}
              </div>
              <span>{activeKey ? `${titleCase(AGENT_META[activeKey as AgentKey]?.short ?? activeKey)} is working…` : "Agents are thinking…"}</span>
            </div>
          )}
        </div>

        <div className="border-t border-white/5 p-4">
          <div className="mb-3 flex flex-wrap gap-1.5">
            {SAMPLE_MESSAGES.map((s) => (
              <button key={s} disabled={running} onClick={() => send(s)} className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs text-slate-300 transition hover:border-electric-500/40 hover:text-white disabled:opacity-40">
                {s}
              </button>
            ))}
          </div>
          <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex gap-2">
            <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type a customer message…" maxLength={4000} disabled={running} />
            <Button type="submit" loading={running} disabled={!input.trim()} aria-label="Send"><Send /></Button>
          </form>
        </div>
      </Card>

      {/* ---------------- Workflow */}
      <Card className="h-[calc(100vh-11rem)] min-h-[560px] overflow-y-auto scrollbar-thin">
        <CardHeader
          title="Agent workflow"
          description={running ? "Processing live…" : Object.keys(steps).length ? "Last run. Click a step to inspect the agent's JSON output." : "Send a message to watch the agents process it."}
          action={running ? <Badge tone="blue"><span className="h-1.5 w-1.5 animate-pulseDot rounded-full bg-electric-400" /> Live</Badge> : null}
        />
        {final && (
          <div className="mb-4 space-y-3">
            <div className="flex flex-wrap gap-2 text-xs">
              {final.agent && <Badge tone="violet">Answered by {final.agent}</Badge>}
              {final.intent && <Badge tone="blue">Intent: {titleCase(final.intent)}</Badge>}
              {final.priority && <PriorityBadge priority={final.priority} />}
              <SentimentBadge sentiment={final.sentiment ?? null} />
            </div>
            <EscalationCard escalated={final.escalated} reasons={final.escalationReasons ?? []} assignedTo={final.assignedTo?.name ?? null} />
          </div>
        )}
        <WorkflowVisual steps={steps} activeKey={activeKey} running={running} />
      </Card>
    </div>
  );
}
