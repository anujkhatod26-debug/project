"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AlertTriangle,
  BookOpen,
  Brain,
  CheckCircle2,
  ChevronDown,
  CircleDashed,
  Gauge,
  GitBranch,
  HeartPulse,
  Headphones,
  Loader2,
  MessageSquare,
  Receipt,
  Save,
  Send,
  ShieldCheck,
  SkipForward,
  UserRound,
  Wrench,
  XCircle,
} from "lucide-react";
import { cn, formatDuration } from "@/lib/utils";
import { AGENT_META } from "@/lib/constants";
import type { AgentKey } from "@/types";

export type StepStatus = "idle" | "running" | "success" | "error" | "skipped";

export interface StepState {
  step: number;
  key: string;
  title: string;
  status: StepStatus;
  detail?: string;
  output?: unknown;
  confidence?: number | null;
  latencyMs?: number;
}

export const STEP_TEMPLATE: { step: number; key: string; title: string; agentHint?: string }[] = [
  { step: 1, key: "receive", title: "Customer sends a message" },
  { step: 2, key: "understanding", title: AGENT_META.understanding.name },
  { step: 3, key: "sentiment", title: AGENT_META.sentiment.name },
  { step: 4, key: "routing", title: AGENT_META.routing.name },
  { step: 5, key: "knowledge", title: "Knowledge base retrieval" },
  { step: 6, key: "specialist", title: "Specialist agent response", agentHint: "Support · Technical · Billing" },
  { step: 7, key: "check", title: "Confidence & escalation check" },
  { step: 8, key: "handoff", title: AGENT_META.handoff.name },
  { step: 9, key: "save", title: "Save to Supabase" },
  { step: 10, key: "respond", title: "Response shown to customer" },
];

const ICONS: Record<string, React.ElementType> = {
  receive: MessageSquare,
  understanding: Brain,
  sentiment: HeartPulse,
  routing: GitBranch,
  knowledge: BookOpen,
  support: Headphones,
  technical: Wrench,
  billing: Receipt,
  specialist: Headphones,
  check: ShieldCheck,
  handoff: UserRound,
  save: Save,
  respond: Send,
};

function color(key: string) {
  return (AGENT_META as Record<string, { color: string }>)[key]?.color ?? "#60a5fa";
}

function StatusIcon({ status }: { status: StepStatus }) {
  if (status === "running") return <Loader2 className="h-4 w-4 animate-spin text-electric-400" />;
  if (status === "success") return <CheckCircle2 className="h-4 w-4 text-emerald-400" />;
  if (status === "error") return <XCircle className="h-4 w-4 text-rose-400" />;
  if (status === "skipped") return <SkipForward className="h-4 w-4 text-slate-500" />;
  return <CircleDashed className="h-4 w-4 text-slate-600" />;
}

function ConfidenceBar({ value }: { value: number }) {
  const pct = Math.round(value * 100);
  const c = value >= 0.75 ? "#10b981" : value >= 0.5 ? "#f59e0b" : "#f43f5e";
  return (
    <div className="flex items-center gap-2">
      <Gauge className="h-3 w-3 text-slate-500" />
      <div className="h-1.5 w-24 overflow-hidden rounded-full bg-white/10">
        <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} className="h-full rounded-full" style={{ background: c }} />
      </div>
      <span className="text-[11px] tabular-nums text-slate-400">{pct}%</span>
    </div>
  );
}

/** Pulls the 2-4 most useful fields from an agent output for a compact summary line. */
function summarize(key: string, output: unknown): [string, string][] {
  if (!output || typeof output !== "object") return [];
  const o = output as Record<string, unknown>;
  const pick = (...ks: string[]) => ks.filter((k) => o[k] !== undefined && o[k] !== "").map((k) => [k, typeof o[k] === "object" ? JSON.stringify(o[k]) : String(o[k])] as [string, string]);
  switch (key) {
    case "understanding":
      return pick("intent", "category", "priority", "summary");
    case "sentiment":
      return pick("sentiment", "emotion", "frustration_score", "escalation_recommended");
    case "routing":
      return pick("target", "escalate", "reason");
    case "support":
    case "technical":
    case "billing":
      return pick("resolved", "needs_human", "reason");
    case "handoff":
      return pick("assigned_to", "priority", "reason");
    case "check":
      return pick("escalate", "threshold");
    default:
      return [];
  }
}

export function WorkflowVisual({
  steps,
  activeKey,
  running,
}: {
  steps: Record<number, StepState>;
  activeKey: string | null;
  running: boolean;
}) {
  const [openStep, setOpenStep] = useState<number | null>(null);

  return (
    <div className="relative">
      <div className="absolute bottom-4 left-[19px] top-4 w-px bg-gradient-to-b from-electric-500/40 via-violet-500/30 to-transparent" />
      <ol className="space-y-2">
        {STEP_TEMPLATE.map((tpl) => {
          const s = steps[tpl.step];
          const status: StepStatus = s?.status ?? "idle";
          const key = s?.key ?? tpl.key;
          const Icon = ICONS[key] ?? CircleDashed;
          const title = s?.title ?? tpl.title;
          const isActive = running && status === "running";
          const summary = summarize(key, s?.output);
          const expanded = openStep === tpl.step;

          return (
            <li key={tpl.step} className="relative pl-12">
              <motion.div
                animate={isActive ? { scale: [1, 1.12, 1] } : { scale: 1 }}
                transition={isActive ? { repeat: Infinity, duration: 1.2 } : {}}
                className={cn(
                  "absolute left-0 top-2 flex h-10 w-10 items-center justify-center rounded-xl ring-1 transition",
                  status === "idle" ? "bg-navy-900 ring-white/10" : "bg-navy-800 ring-white/15"
                )}
                style={status !== "idle" && status !== "skipped" ? { boxShadow: `0 0 18px -4px ${color(key)}`, borderColor: color(key) } : undefined}
              >
                <Icon className="h-[18px] w-[18px]" style={{ color: status === "idle" || status === "skipped" ? "#475569" : color(key) }} />
              </motion.div>

              <button
                type="button"
                onClick={() => setOpenStep(expanded ? null : tpl.step)}
                disabled={!s}
                className={cn(
                  "w-full rounded-xl border px-3.5 py-2.5 text-left transition",
                  isActive ? "border-electric-500/40 bg-electric-500/[0.07]" : "border-white/5 bg-white/[0.02] hover:bg-white/[0.04]",
                  status === "error" && "border-rose-500/30",
                  activeKey === key && !running && status === "success" && "border-emerald-500/20"
                )}
              >
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-semibold tabular-nums text-slate-500">STEP {tpl.step}</span>
                  <span className={cn("flex-1 truncate text-sm font-medium", status === "idle" ? "text-slate-500" : "text-slate-100")}>{title}</span>
                  {s?.latencyMs != null && <span className="text-[10px] tabular-nums text-slate-500">{formatDuration(s.latencyMs)}</span>}
                  <StatusIcon status={status} />
                  {s?.output != null && <ChevronDown className={cn("h-3.5 w-3.5 text-slate-500 transition", expanded && "rotate-180")} />}
                </div>
                {tpl.step === 6 && !s && <p className="mt-0.5 text-[11px] text-slate-600">{tpl.agentHint}</p>}
                {s?.detail && <p className={cn("mt-1 text-xs", status === "error" ? "text-rose-300" : "text-slate-400")}>{s.detail}</p>}
                {summary.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {summary.map(([k, v]) => (
                      <span key={k} className="max-w-full truncate rounded-md bg-white/5 px-1.5 py-0.5 text-[11px] text-slate-300">
                        <span className="text-slate-500">{k.replace(/_/g, " ")}:</span> {v}
                      </span>
                    ))}
                  </div>
                )}
                {typeof s?.confidence === "number" && <div className="mt-2"><ConfidenceBar value={s.confidence} /></div>}
              </button>

              <AnimatePresence>
                {expanded && s?.output != null && (
                  <motion.pre
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="mt-1 max-h-72 overflow-auto rounded-xl bg-navy-950/80 p-3 text-[11px] leading-relaxed text-slate-300 scrollbar-thin"
                  >
                    {JSON.stringify(s.output, null, 2)}
                  </motion.pre>
                )}
              </AnimatePresence>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

export function EscalationCard({ escalated, reasons, assignedTo }: { escalated: boolean | null; reasons: string[]; assignedTo: string | null }) {
  if (escalated === null) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "rounded-xl border p-3.5",
        escalated ? "border-rose-500/30 bg-rose-500/[0.07]" : "border-emerald-500/25 bg-emerald-500/[0.06]"
      )}
    >
      <div className="flex items-center gap-2">
        {escalated ? <AlertTriangle className="h-4 w-4 text-rose-400" /> : <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
        <p className="text-sm font-medium text-white">{escalated ? "Escalated to human support" : "Handled by AI, no escalation needed"}</p>
      </div>
      {escalated && (
        <>
          <p className="mt-1.5 text-xs text-slate-300">Assigned to: <span className="text-white">{assignedTo ?? "Unassigned (no one available)"}</span></p>
          <ul className="mt-1.5 list-disc space-y-0.5 pl-5 text-xs text-slate-400">
            {reasons.map((r) => <li key={r}>{r}</li>)}
          </ul>
        </>
      )}
    </motion.div>
  );
}

export function agentShort(key: string | null) {
  if (!key) return "—";
  return AGENT_META[key as AgentKey]?.short ?? key;
}
