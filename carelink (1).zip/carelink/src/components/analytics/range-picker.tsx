"use client";
import { useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const PRESETS = [
  { v: "7", l: "7 days" },
  { v: "14", l: "14 days" },
  { v: "30", l: "30 days" },
  { v: "90", l: "90 days" },
];

export function RangePicker() {
  const sp = useSearchParams();
  const router = useRouter();
  const path = usePathname();
  const [from, setFrom] = useState(sp.get("from") ?? "");
  const [to, setTo] = useState(sp.get("to") ?? "");
  const active = sp.get("from") ? "custom" : sp.get("range") ?? "14";

  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="flex rounded-xl border border-white/10 bg-white/[0.03] p-1">
        {PRESETS.map((p) => (
          <button
            key={p.v}
            onClick={() => router.replace(`${path}?range=${p.v}`)}
            className={cn("rounded-lg px-3 py-1.5 text-xs transition", active === p.v ? "bg-electric-500/20 text-white" : "text-slate-400 hover:text-white")}
          >
            {p.l}
          </button>
        ))}
      </div>
      <form
        className="flex items-center gap-1.5"
        onSubmit={(e) => {
          e.preventDefault();
          if (from && to) router.replace(`${path}?from=${from}&to=${to}`);
        }}
      >
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="h-9 w-36 text-xs" />
        <span className="text-xs text-slate-500">to</span>
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="h-9 w-36 text-xs" />
        <Button size="sm" variant="secondary" type="submit" disabled={!from || !to}>Apply</Button>
      </form>
    </div>
  );
}
