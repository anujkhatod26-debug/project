import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: {
          950: "#050816",
          900: "#0a1029",
          800: "#0f1838",
          700: "#16224b",
          600: "#1f2d5e",
        },
        electric: {
          DEFAULT: "#3b82f6",
          400: "#60a5fa",
          500: "#3b82f6",
          600: "#2563eb",
        },
        violet: { glow: "#8b5cf6" },
        border: "rgba(148, 163, 184, 0.12)",
      },
      fontFamily: {
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui"],
        display: ["var(--font-display)", "ui-sans-serif", "system-ui"],
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(59,130,246,0.25), 0 8px 30px -8px rgba(59,130,246,0.45)",
        card: "0 1px 0 0 rgba(255,255,255,0.04) inset, 0 20px 40px -24px rgba(0,0,0,0.6)",
      },
      keyframes: {
        pulseDot: { "0%,100%": { opacity: "0.3" }, "50%": { opacity: "1" } },
      },
      animation: { pulseDot: "pulseDot 1.2s ease-in-out infinite" },
    },
  },
  plugins: [],
};
export default config;
