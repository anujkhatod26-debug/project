/* eslint-disable @typescript-eslint/no-explicit-any */
import http from "http";
export const calls: { agent: string; user: string }[] = [];
export let behaviour: { badJsonOnce?: boolean; frustrated?: boolean; lowConfidence?: boolean; fail?: string } = {};
export function setBehaviour(b: typeof behaviour) { behaviour = b; }
function agentOf(system: string) {
  if (system.includes("Query Understanding Agent")) return "understanding";
  if (system.includes("Sentiment Analysis Agent")) return "sentiment";
  if (system.includes("Routing Agent")) return "routing";
  if (system.includes("Human Handoff Agent")) return "handoff";
  if (system.includes("Billing Agent")) return "billing";
  if (system.includes("Technical Support Agent")) return "technical";
  return "support";
}
let badSent = false;
export function start(port: number) {
  return new Promise<http.Server>((resolve) => {
    const srv = http.createServer((req, res) => {
      let body = "";
      req.on("data", (c) => (body += c));
      req.on("end", () => {
        const j = JSON.parse(body);
        const system = typeof j.system === "string" ? j.system : JSON.stringify(j.system);
        const agent = agentOf(system);
        const user = j.messages[0].content as string;
        calls.push({ agent, user });
        if (behaviour.fail === agent) { res.writeHead(500, { "content-type": "application/json" }); res.end(JSON.stringify({ type: "error", error: { type: "api_error", message: "boom" } })); return; }
        const msg = user.match(/<customer_message>\n([\s\S]*?)\n<\/customer_message>/)?.[1] ?? "";
        const billing = /payment|refund|deducted|invoice/i.test(msg);
        const tech = /log ?in|password/i.test(msg);
        let out: any;
        if (agent === "understanding") out = { intent: billing ? (/refund/i.test(msg) ? "refund" : "billing") : tech ? "account" : /waiting/i.test(msg) ? "complaint" : "general", category: billing ? "payment_failure" : tech ? "login_issue" : "delayed_response", sentiment: "negative", priority: "high", confidence: 0.93, summary: `Customer says: ${msg.slice(0, 60)}`, entities: {}, language: "English" };
        if (agent === "sentiment") out = { sentiment: behaviour.frustrated ? "very_negative" : "negative", emotion: behaviour.frustrated ? "angry" : "worried", frustration_score: behaviour.frustrated ? 0.9 : 0.4, priority: behaviour.frustrated ? "urgent" : "high", escalation_recommended: !!behaviour.frustrated, reason: "test", confidence: 0.88 };
        if (agent === "routing") out = { target: billing ? "billing" : tech ? "technical" : "support", escalate: false, reason: "matched intent", confidence: 0.9 };
        if (["support", "technical", "billing"].includes(agent)) {
          const ids = [...user.matchAll(/article id="([^"]+)"/g)].map((m) => m[1]);
          out = { reply: `[${agent}] Here is help for: ${msg}`, confidence: behaviour.lowConfidence ? 0.3 : 0.86, resolved: !behaviour.lowConfidence, needs_human: false, reason: "kb matched", used_article_ids: [...ids, "not-a-real-id"] };
        }
        if (agent === "handoff") out = { summary: "Customer needs a human.", reason: "escalation", priority: "urgent", customer_message: "A team member will take over shortly.", suggested_next_steps: ["Check order"], ticket_title: "Escalated customer issue" };
        let text = "```json\n" + JSON.stringify(out) + "\n```";
        if (behaviour.badJsonOnce && !badSent && agent === "understanding") { badSent = true; text = "Sure! Here's my analysis: intent is billing."; }
        res.writeHead(200, { "content-type": "application/json" });
        res.end(JSON.stringify({ id: "msg_test", type: "message", role: "assistant", model: j.model, content: [{ type: "text", text }], stop_reason: "end_turn", stop_sequence: null, usage: { input_tokens: 10, output_tokens: 20 } }));
      });
    });
    srv.listen(port, () => resolve(srv));
  });
}
