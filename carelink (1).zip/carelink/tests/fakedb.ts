/* eslint-disable @typescript-eslint/no-explicit-any */
import { randomUUID } from "crypto";
export type Row = Record<string, any>;
export function makeDb(tables: Record<string, Row[]>) {
  const T = (n: string) => (tables[n] ??= []);
  function builder(table: string) {
    let filters: ((r: Row) => boolean)[] = [];
    let op: "select" | "insert" | "update" | "delete" = "select";
    let payload: any = null;
    let order: [string, boolean] | null = null;
    let lim: number | null = null;
    let mode: "many" | "single" | "maybe" = "many";
    let inserted: Row[] = [];
    let selectCols = "*";
    const b: any = {
      select(cols = "*") { selectCols = cols; return b; },
      insert(rows: any) { op = "insert"; payload = Array.isArray(rows) ? rows : [rows]; return b; },
      update(p: any) { op = "update"; payload = p; return b; },
      delete() { op = "delete"; return b; },
      eq(c: string, v: any) { filters.push((r) => r[c] === v); return b; },
      neq(c: string, v: any) { filters.push((r) => r[c] !== v); return b; },
      in(c: string, vs: any[]) { filters.push((r) => vs.includes(r[c])); return b; },
      order(c: string, o?: { ascending?: boolean }) { order = [c, o?.ascending !== false]; return b; },
      limit(n: number) { lim = n; return b; },
      single() { mode = "single"; return b; },
      maybeSingle() { mode = "maybe"; return b; },
      then(res: any, rej: any) { return Promise.resolve().then(run).then(res, rej); },
    };
    const join = (r: Row) => {
      const out = { ...r };
      if (selectCols.includes("customers(") && r.customer_id) out.customers = T("customers").find((c) => c.id === r.customer_id) ?? null;
      return out;
    };
    function run() {
      let data: any;
      if (op === "insert") {
        inserted = payload.map((p: Row) => ({ id: randomUUID(), created_at: new Date().toISOString(), ...p }));
        T(table).push(...inserted);
        data = inserted;
      } else {
        let rows = T(table).filter((r) => filters.every((f) => f(r)));
        if (op === "update") { rows.forEach((r) => Object.assign(r, payload)); data = rows; }
        else if (op === "delete") { tables[table] = T(table).filter((r) => !rows.includes(r)); data = null; }
        else {
          if (order) { const [c, asc] = order; rows = [...rows].sort((a, z) => (a[c] > z[c] ? 1 : -1) * (asc ? 1 : -1)); }
          if (lim != null) rows = rows.slice(0, lim);
          data = rows.map(join);
        }
      }
      if (mode !== "many") {
        const first = Array.isArray(data) ? data[0] : data;
        if (!first && mode === "single") return { data: null, error: { message: "not found" } };
        return { data: first ?? null, error: null };
      }
      return { data, error: null };
    }
    return b;
  }
  return {
    from: builder,
    rpc: async (fn: string, args: any) => {
      const kb = T("knowledge_articles").filter((k) => k.organization_id === args.org);
      const words: string[] = fn === "search_knowledge" ? args.query.split(" ") : args.words;
      const hits = kb
        .map((k) => ({ ...k, rank: words.filter((w) => (k.title + " " + k.content).toLowerCase().includes(w)).length }))
        .filter((k) => (fn === "search_knowledge" ? k.rank === words.length : k.rank > 0));
      return { data: hits, error: null };
    },
    tables,
  };
}
